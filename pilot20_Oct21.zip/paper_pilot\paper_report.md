# Benchmark+ : evaluation report

Generated 2026-10-21 15:25 | profile `pilot` | LLM `deepseek-flash` | embeddings `BAAI/bge-small-en-v1.5` | seed 42

Definitions: README sections 13 (mutations), 14.2 (metrics), 29-32 (databases, union, this report). `AUC` = how well a classifier tells the set from real queries (0.5 = cannot; lower = more realistic). `*_js` = Jensen-Shannon divergence in bits of the distribution of graph shapes / fine templates / entity types against the real queries (0 = identical, 1 = disjoint). `entropy` = spread of shapes (1 = even). The **union** is the three methods' questions with near-duplicates removed; its mutated versions and evaluation results are those of the method each question came from.

## medrag (medical)

### 1. Real user queries

1,165 real medical queries. Mean 18.6 words, 1.63 sentences, 4.62 entities per query; 335 distinct graph shapes (entropy 0.86). Commonest shapes: `what|S1|N1-3|D0-1|E0` 5.9%, `what|S1|N4-6|D2|E0` 5.3%, `how|S1|N1-3|D0-1|E0` 3.9%, `AUX|S1|N1-3|D0-1|E0` 2.7%, `what|S1|N1-3|D0-1|E1` 2.6%.

### 2. Benchmarks: how realistic and how varied

| scope | n | mean_words | n_sentences | auc_vs_real | shape_js | template_js | entity_type_js | distinct_templates | template_entropy | distinct_shapes | shape_entropy | ents_per_query | real_shape_coverage | shape_in_real |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ragas | 20 | 20.350 | 1.000 | 0.988 | 0.857 | 1.000 | 0.064 | 20 | 1.000 | 14 | 0.951 | 4.850 | 0.063 | 0.800 |
| ares | 20 | 19.600 | 1.000 | 0.908 | 0.904 | 1.000 | 0.045 | 20 | 1.000 | 18 | 0.988 | 5.200 | 0.037 | 0.600 |
| datamorgana | 20 | 18.100 | 1.000 | 0.769 | 0.819 | 1.000 | 0.065 | 20 | 1.000 | 16 | 0.971 | 3.900 | 0.112 | 0.800 |
| union | 60 | 19.350 | 1.000 | 0.914 | 0.762 | 1.000 | 0.039 | 60 | 1.000 | 39 | 0.967 | 4.650 | 0.165 | 0.733 |

Entity overlap: distinct real entities 3,607; distinct benchmark entities 259; benchmark entities also in real 0.185; real entities found in corpus 0.060; benchmark entities found in corpus 0.703.

Union: 60 questions from {'ragas': 20, 'ares': 20, 'datamorgana': 20} -> 60 after removing 0 near-duplicates (cosine >= 0.9); kept by method {'ragas': 20, 'ares': 20, 'datamorgana': 20}.

### 3. Mutations (applied to the union)

Checks passed (kept) and rejected. `by_fallback` = how many of the kept ones come from a fallback instead of the full operator (`mutation.fill_all`, README 13.12; they are included in `kept`):

| rag | method | mutation | kept | rejected | kept_rate | by_fallback | commonest_rejection |
|---|---|---|---|---|---|---|---|
| medrag | ragas | m1 | 20 | 0 | 1.000 | 2 |  |
| medrag | ragas | m2 | 20 | 0 | 1.000 | 0 |  |
| medrag | ragas | m3 | 20 | 0 | 1.000 | 0 |  |
| medrag | ares | m1 | 20 | 0 | 1.000 | 7 |  |
| medrag | ares | m2 | 20 | 0 | 1.000 | 0 |  |
| medrag | ares | m3 | 20 | 0 | 1.000 | 1 |  |
| medrag | datamorgana | m1 | 20 | 0 | 1.000 | 1 |  |
| medrag | datamorgana | m2 | 20 | 0 | 1.000 | 0 |  |
| medrag | datamorgana | m3 | 20 | 0 | 1.000 | 0 |  |

Realism of the mutated versions alone and pooled with the originals (Benchmark+):

| set | n | mean_words | n_sentences | auc_vs_real | shape_js | template_js | entity_type_js | template_entropy | shape_entropy | starts_lowercase | has_first_person | starts_with_verb |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Benchmark | 60 | 19.350 | 1.000 | 0.914 | 0.762 | 1.000 | 0.039 | 1.000 | 0.967 | 0.117 | 0.133 | 0.000 |
| M1 Elaborate (versions alone) | 60 | 36.117 | 2.050 | 0.952 | 0.856 | 1.000 | 0.038 | 1.000 | 0.983 | 0.083 | 0.133 | 0.000 |
| M2 Colloquial (versions alone) | 60 | 23.033 | 1.550 | 0.934 | 0.818 | 1.000 | 0.040 | 1.000 | 0.980 | 0.383 | 0.517 | 0.150 |
| M3 Premise (versions alone) | 60 | 36.600 | 2.000 | 0.966 | 0.909 | 1.000 | 0.014 | 1.000 | 0.949 | 0.033 | 0.683 | 0.067 |
| Benchmark + M1 | 120 | 27.733 | 1.525 | 0.909 | 0.729 | 1.000 | 0.037 | 1.000 | 0.974 | 0.100 | 0.133 | 0.000 |
| Benchmark + M2 | 120 | 21.192 | 1.275 | 0.876 | 0.739 | 1.000 | 0.038 | 0.996 | 0.958 | 0.250 | 0.325 | 0.075 |
| Benchmark + M3 | 120 | 27.975 | 1.500 | 0.898 | 0.747 | 1.000 | 0.017 | 1.000 | 0.964 | 0.075 | 0.408 | 0.033 |
| Benchmark + M1 + M2 + M3 | 240 | 28.775 | 1.650 | 0.914 | 0.712 | 1.000 | 0.023 | 0.998 | 0.959 | 0.154 | 0.367 | 0.054 |


## 4. Hallucinations and accuracy

Benchmark+ = the questions plus their mutated versions (N, 2N, 4N questions; README 14.7). `hallucination_rate` is the main metric (README 14.2); the interval resamples original questions. Rows for `union` pool the questions of the three methods that are in the union.

| rag | method | benchmark_plus | questions | added_questions | correct | wrong | abstained | refused | accuracy | hallucinated | hallucination_rate | rate_ci_low | rate_ci_high | hallucinated_in_added |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | ares | Benchmark | 20 | 0 | 15 | 4 | 1 | 0 | 0.750 | 4 | 0.200 | 0.050 | 0.350 | 0 |
| medrag | ares | Benchmark + M1 | 40 | 20 | 32 | 7 | 1 | 0 | 0.800 | 8 | 0.200 | 0.075 | 0.325 | 4 |
| medrag | ares | Benchmark + M2 | 40 | 20 | 34 | 5 | 1 | 0 | 0.850 | 5 | 0.125 | 0.050 | 0.225 | 1 |
| medrag | ares | Benchmark + M3 | 40 | 20 | 32 | 4 | 4 | 7 | 0.800 | 5 | 0.125 | 0.050 | 0.225 | 1 |
| medrag | ares | Benchmark + M1 + M2 + M3 | 80 | 60 | 68 | 8 | 4 | 7 | 0.850 | 10 | 0.125 | 0.050 | 0.200 | 6 |
| medrag | ares | Reference: Benchmark + same question again | 40 | 20 | 32 | 6 | 2 | 0 | 0.800 | 7 | 0.175 | 0.050 | 0.325 | 3 |
| medrag | ares | Reference: Benchmark + off-topic filler | 40 | 20 | 32 | 4 | 4 | 3 | 0.800 | 6 | 0.150 | 0.050 | 0.300 | 2 |
| medrag | datamorgana | Benchmark | 20 | 0 | 19 | 1 | 0 | 0 | 0.950 | 5 | 0.250 | 0.050 | 0.450 | 0 |
| medrag | datamorgana | Benchmark + M1 | 40 | 20 | 35 | 4 | 1 | 1 | 0.875 | 10 | 0.250 | 0.100 | 0.400 | 5 |
| medrag | datamorgana | Benchmark + M2 | 40 | 20 | 34 | 4 | 2 | 2 | 0.850 | 8 | 0.200 | 0.075 | 0.325 | 3 |
| medrag | datamorgana | Benchmark + M3 | 40 | 20 | 34 | 4 | 2 | 2 | 0.850 | 9 | 0.225 | 0.125 | 0.325 | 4 |
| medrag | datamorgana | Benchmark + M1 + M2 + M3 | 80 | 60 | 65 | 10 | 5 | 5 | 0.812 | 17 | 0.212 | 0.113 | 0.325 | 12 |
| medrag | datamorgana | Reference: Benchmark + same question again | 40 | 20 | 38 | 1 | 1 | 1 | 0.950 | 9 | 0.225 | 0.075 | 0.375 | 4 |
| medrag | datamorgana | Reference: Benchmark + off-topic filler | 40 | 20 | 31 | 3 | 6 | 5 | 0.775 | 10 | 0.250 | 0.125 | 0.400 | 5 |
| medrag | ragas | Benchmark | 20 | 0 | 18 | 2 | 0 | 0 | 0.900 | 2 | 0.100 | 0.000 | 0.250 | 0 |
| medrag | ragas | Benchmark + M1 | 40 | 20 | 35 | 5 | 0 | 0 | 0.875 | 5 | 0.125 | 0.000 | 0.275 | 3 |
| medrag | ragas | Benchmark + M2 | 40 | 20 | 35 | 5 | 0 | 0 | 0.875 | 5 | 0.125 | 0.000 | 0.275 | 3 |
| medrag | ragas | Benchmark + M3 | 40 | 20 | 37 | 3 | 0 | 0 | 0.925 | 3 | 0.075 | 0.000 | 0.200 | 1 |
| medrag | ragas | Benchmark + M1 + M2 + M3 | 80 | 60 | 71 | 9 | 0 | 0 | 0.887 | 9 | 0.113 | 0.013 | 0.237 | 7 |
| medrag | ragas | Reference: Benchmark + same question again | 40 | 20 | 35 | 5 | 0 | 0 | 0.875 | 5 | 0.125 | 0.000 | 0.275 | 3 |
| medrag | ragas | Reference: Benchmark + off-topic filler | 40 | 20 | 36 | 3 | 1 | 1 | 0.900 | 3 | 0.075 | 0.000 | 0.200 | 1 |
| medrag | union | Benchmark | 60 | 0 | 52 | 7 | 1 | 0 | 0.867 | 11 | 0.183 | 0.083 | 0.283 | 0 |
| medrag | union | Benchmark + M1 | 120 | 60 | 102 | 16 | 2 | 1 | 0.850 | 23 | 0.192 | 0.117 | 0.275 | 12 |
| medrag | union | Benchmark + M2 | 120 | 60 | 103 | 14 | 3 | 2 | 0.858 | 18 | 0.150 | 0.083 | 0.217 | 7 |
| medrag | union | Benchmark + M3 | 120 | 60 | 103 | 11 | 6 | 9 | 0.858 | 17 | 0.142 | 0.091 | 0.200 | 6 |
| medrag | union | Benchmark + M1 + M2 + M3 | 240 | 180 | 204 | 27 | 9 | 12 | 0.850 | 36 | 0.150 | 0.100 | 0.208 | 25 |
| medrag | union | Reference: Benchmark + same question again | 120 | 60 | 105 | 12 | 3 | 1 | 0.875 | 21 | 0.175 | 0.092 | 0.267 | 10 |
| medrag | union | Reference: Benchmark + off-topic filler | 120 | 60 | 99 | 10 | 11 | 9 | 0.825 | 19 | 0.158 | 0.092 | 0.233 | 8 |

### Does each mutation expose more? (paired against the unchanged question)

`diff` = condition rate - benchmark rate on the SAME questions; the two Control rows are the noise floor and the off-topic-filler reference (README 14.1, 16).

(Union only here; all methods are in `hallucination_paired.csv`. `m_union` is the derived condition: a question fails if it fails in the benchmark or in any of M1, M2, M3.)

| rag | metric | condition | n_pairs | baseline_rate | condition_rate | diff | diff_ci_low | diff_ci_high | newly_failing | newly_passing | q_value |
|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | hallucinated | m1 | 60 | 0.183 | 0.200 | 0.017 | -0.100 | 0.133 | 7 | 6 | 1.000 |
| medrag | hallucinated | m2 | 60 | 0.183 | 0.117 | -0.067 | -0.183 | 0.034 | 4 | 8 | 0.930 |
| medrag | hallucinated | m3 | 60 | 0.183 | 0.100 | -0.083 | -0.217 | 0.050 | 5 | 10 | 0.930 |
| medrag | hallucinated | m_union | 60 | 0.183 | 0.400 | 0.217 | 0.117 | 0.333 | 13 | 0 | 0.003 |
| medrag | hallucinated | c_rerun | 60 | 0.183 | 0.167 | -0.017 | -0.100 | 0.067 | 3 | 4 | 1.000 |
| medrag | hallucinated | c_pad | 60 | 0.183 | 0.133 | -0.050 | -0.167 | 0.067 | 5 | 8 | 1.000 |
| medrag | failed | m1 | 60 | 0.133 | 0.167 | 0.033 | -0.050 | 0.133 | 5 | 3 | 1.000 |
| medrag | failed | m2 | 60 | 0.133 | 0.150 | 0.017 | -0.083 | 0.117 | 5 | 4 | 1.000 |
| medrag | failed | m3 | 60 | 0.133 | 0.150 | 0.017 | -0.100 | 0.150 | 8 | 7 | 1.000 |
| medrag | failed | m_union | 60 | 0.133 | 0.383 | 0.250 | 0.150 | 0.367 | 15 | 0 | 0.001 |
| medrag | failed | c_rerun | 60 | 0.133 | 0.117 | -0.017 | -0.083 | 0.033 | 1 | 2 | 1.000 |
| medrag | failed | c_pad | 60 | 0.133 | 0.217 | 0.083 | -0.050 | 0.217 | 10 | 5 | 0.836 |
| medrag | refused | m1 | 60 | 0.000 | 0.017 | 0.017 | 0.000 | 0.067 | 1 | 0 | 1.000 |
| medrag | refused | m2 | 60 | 0.000 | 0.033 | 0.033 | 0.000 | 0.083 | 2 | 0 | 0.783 |
| medrag | refused | m3 | 60 | 0.000 | 0.150 | 0.150 | 0.067 | 0.250 | 9 | 0 | 0.016 |
| medrag | refused | m_union | 60 | 0.000 | 0.183 | 0.183 | 0.083 | 0.284 | 11 | 0 | 0.005 |
| medrag | refused | c_rerun | 60 | 0.000 | 0.017 | 0.017 | 0.000 | 0.050 | 1 | 0 | 1.000 |
| medrag | refused | c_pad | 60 | 0.000 | 0.150 | 0.150 | 0.067 | 0.233 | 9 | 0 | 0.016 |

### Which questions change status? (hallucinated)

| rag | method | outcome | condition | questions | fine_to_fine | fine_to_FAIL | FAIL_to_fine | FAIL_to_FAIL | benchmark_fails | condition_fails | net_change | p_mcnemar | q_value |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | union | hallucinated | Benchmark + M1 only | 60 | 42 | 7 | 6 | 5 | 11 | 12 | 1 | 1.000 | 1.000 |
| medrag | union | hallucinated | Benchmark + M2 only | 60 | 45 | 4 | 8 | 3 | 11 | 7 | -4 | 0.388 | 1.000 |
| medrag | union | hallucinated | Benchmark + M3 only | 60 | 44 | 5 | 10 | 1 | 11 | 6 | -5 | 0.302 | 1.000 |
| medrag | union | hallucinated | Control: same question again | 60 | 46 | 3 | 4 | 7 | 11 | 10 | -1 | 1.000 | 1.000 |
| medrag | union | hallucinated | Control: off-topic filler | 60 | 44 | 5 | 8 | 3 | 11 | 8 | -3 | 0.581 | 1.000 |

### The three mutations together (union, hallucinated)

| rag | method | outcome | questions | benchmark_fails | fine_in_benchmark__fails_in_at_least_one | fine_in_benchmark__fails_in_all_three | fails_in_benchmark__fine_in_at_least_one | fails_in_benchmark__fine_in_all_three | fails_in_benchmark__fails_in_at_least_one | fails_in_benchmark__fails_in_all_three | fine_everywhere | fails_somewhere |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | union | hallucinated | 60 | 11 | 13 | 1 | 10 | 6 | 5 | 1 | 36 | 24 |

### Refusals: "Cannot be answered from given information." (README 14.10)

The RAG is told to give exactly this answer when its documents lack the information. `refused` counts such answers per condition. `became_refused` = answered the original question but refuses this version (for M3: the patient information added to the question makes it unanswerable from the documents); `stopped_refusing` = the reverse; `refused_in_both` = the documents never held the answer. `abstained_by_judge` also counts declines in other words (refused <= abstained_by_judge). A refusal is a failure to answer, never a hallucination.

| rag | method | condition | total | refused | refused_rate | abstained_by_judge | became_refused | stopped_refusing | refused_in_both |
|---|---|---|---|---|---|---|---|---|---|
| medrag | union | Benchmark (unchanged) | 60 | 0 | 0.000 | 1 |  |  |  |
| medrag | union | Benchmark + M1 only | 60 | 1 | 0.017 | 1 | 1.000 | 0.000 | 0.000 |
| medrag | union | Benchmark + M2 only | 60 | 2 | 0.033 | 2 | 2.000 | 0.000 | 0.000 |
| medrag | union | Benchmark + M3 only | 60 | 9 | 0.150 | 5 | 9.000 | 0.000 | 0.000 |
| medrag | union | Benchmark + M1/M2/M3 combined (any separate run) | 60 | 11 | 0.183 | 8 | 11.000 | 0.000 | 0.000 |
| medrag | union | Control: same question again | 60 | 1 | 0.017 | 2 | 1.000 | 0.000 | 0.000 |
| medrag | union | Control: off-topic filler | 60 | 9 | 0.150 | 10 | 9.000 | 0.000 | 0.000 |

(All methods: `refusals.csv`.)

## 5. The story table

One row per question set. Realism columns: lower AUC / JS is closer to real queries. Hallucination columns: from the pooled Benchmark+ definition (the `+M` rows contain the originals AND the mutated versions).

### medrag

| row | n | mean_words | n_sentences | ents_per_query | distinct_shapes | shape_entropy | auc_vs_real | shape_js | template_js | entity_type_js | questions | accuracy | hallucination_rate | ci_low | ci_high |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Real queries | 1165 | 18.585 | 1.630 | 4.620 | 335 | 0.862 |  |  |  |  |  |  |  |  |  |
| RAGAS | 20 | 20.350 | 1.000 | 4.850 | 14 | 0.951 | 0.988 | 0.857 | 1.000 | 0.064 | 20 | 0.900 | 0.100 | 0.000 | 0.250 |
| ARES | 20 | 19.600 | 1.000 | 5.200 | 18 | 0.988 | 0.908 | 0.904 | 1.000 | 0.045 | 20 | 0.750 | 0.200 | 0.050 | 0.350 |
| DataMorgana | 20 | 18.100 | 1.000 | 3.900 | 16 | 0.971 | 0.769 | 0.819 | 1.000 | 0.065 | 20 | 0.950 | 0.250 | 0.050 | 0.450 |
| Union | 60 | 19.350 | 1.000 | 4.650 | 39 | 0.967 | 0.914 | 0.762 | 1.000 | 0.039 | 60 | 0.867 | 0.183 | 0.083 | 0.283 |
| Union + M1 | 120 | 27.733 | 1.525 | 6.508 | 79 | 0.974 | 0.909 | 0.729 | 1.000 | 0.037 | 120 | 0.850 | 0.192 | 0.117 | 0.275 |
| Union + M2 | 120 | 21.192 | 1.275 | 4.800 | 70 | 0.958 | 0.876 | 0.739 | 1.000 | 0.038 | 120 | 0.858 | 0.150 | 0.083 | 0.217 |
| Union + M3 | 120 | 27.975 | 1.500 | 6.458 | 77 | 0.964 | 0.898 | 0.747 | 1.000 | 0.017 | 120 | 0.858 | 0.142 | 0.091 | 0.200 |
| Union + M1 + M2 + M3 (Benchmark+) | 240 | 28.775 | 1.650 | 6.558 | 121 | 0.959 | 0.914 | 0.712 | 1.000 | 0.023 | 240 | 0.850 | 0.150 | 0.100 | 0.208 |

## 6. Cost and provenance

LLM calls and tokens of the LAST run of each stage (a resumed run only counts its own part):

| rag | stage | method | accepted | attempts | acceptance_rate | llm_calls_last_run | prompt_tokens | completion_tokens | model |
|---|---|---|---|---|---|---|---|---|---|
| medrag | generation | ragas | 20 | 20.000 | 1.000 | 20 | 8073 | 750 | deepseek-flash |
| medrag | generation | ares | 20 | 43.000 | 0.465 | 29 | 17664 | 627 | deepseek-flash |
| medrag | generation | datamorgana | 20 | 30.000 | 0.667 | 30 | 24063 | 4235 | deepseek-flash |
| medrag | mutation | ragas | 20 |  |  | 132 | 53665 | 3744 | deepseek-flash |
| medrag | mutation | ares | 20 |  |  | 171 | 47712 | 4853 | deepseek-flash |
| medrag | mutation | datamorgana | 20 |  |  | 121 | 48465 | 3065 | deepseek-flash |

Hand-audit sheet for assumption A4 (README 13.2): `audit_sheet_mutations.csv` (180 mutated questions; fill the last five columns and report the shares).

## Files

All in `C:\Users\tuo94543\Documents\GitHub\Trust_2027\results\paper_pilot`: `audit_sheet_mutations.csv`, `hallucination_any_of_three.csv`, `hallucination_benchmark_plus.csv`, `hallucination_paired.csv`, `hallucination_per_condition.csv`, `hallucination_transitions.csv`, `mutation_validity.csv`, `paper_tables.tex`, `provenance.csv`, `realism_all.csv`, `refusals.csv`, `story_medrag.csv`, `templates_top.csv`
