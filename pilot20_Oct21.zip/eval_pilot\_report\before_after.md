# Benchmark before vs after mutation

Every number compares the SAME questions: the original benchmark question and its mutated version. `*` marks a change whose 95% paired-bootstrap interval excludes 0 (intervals are in `before_after_deltas.csv`). `pp` = percentage points.

**Accuracy** = share of answers judged correct. For mutations 3 and 1+2+3 the correct behaviour can be to reject a false claim or flag an unsupported detail, so `accuracy (answer items)` restricts to questions whose correct behaviour is to answer; that column is comparable with the baseline. **Hallucination** = unfaithful answer or an answer that asserts a wrong / adopted-false claim (declining to answer is not counted).

## 1. Accuracy and hallucination, all RAGs and methods pooled

| condition | n | accuracy | Δ accuracy | accuracy (answer items) | hallucination | Δ hallucination | unfaithful | abstained | refused | mean faithfulness |
|---|---|---|---|---|---|---|---|---|---|---|
| Benchmark (unchanged) | 60 | 86.7% |  | 86.7% | 18.3% |  | 6.7% | 1.7% | 0.0% | 0.973 |
| Benchmark + M1 only | 60 | 83.3% | -3.3 pp | 83.3% | 20.0% | +1.7 pp | 6.7% | 1.7% | 1.7% | 0.975 |
| Benchmark + M2 only | 60 | 85.0% | -1.7 pp | 85.0% | 11.7% | -6.7 pp | 5.0% | 3.3% | 3.3% | 0.982 |
| Benchmark + M3 only | 60 | 85.0% | -1.7 pp | 81.2% | 10.0% | -8.3 pp | 3.3% | 8.3% | 15.0% | 0.994 |
| Benchmark + M1/M2/M3 combined (any separate run) | 60 | 61.7% | -25.0 pp* | 61.7% | 40.0% | +21.7 pp* | 15.0% | 13.3% | 18.3% | 0.952 |
| Control: same question again | 60 | 88.3% | +1.7 pp | 88.3% | 16.7% | -1.7 pp | 8.3% | 3.3% | 1.7% | 0.971 |
| Control: off-topic filler | 60 | 78.3% | -8.3 pp | 78.3% | 13.3% | -5.0 pp | 10.0% | 16.7% | 15.0% | 0.979 |

## 2a. Accuracy per RAG and method

| rag | method | Benchmark (unchanged) | Benchmark + M1 only | Benchmark + M2 only | Benchmark + M3 only | Benchmark + M1/M2/M3 combined (any separate run) | Control: same question again | Control: off-topic filler |
|---|---|---|---|---|---|---|---|---|
| medrag | ares | 75.0% | 85.0% | 95.0% | 85.0% | 60.0% | 85.0% | 85.0% |
| medrag | datamorgana | 95.0% | 80.0% | 75.0% | 75.0% | 45.0% | 95.0% | 60.0% |
| medrag | ragas | 90.0% | 85.0% | 85.0% | 95.0% | 80.0% | 85.0% | 90.0% |

## 2b. Hallucination per RAG and method

| rag | method | Benchmark (unchanged) | Benchmark + M1 only | Benchmark + M2 only | Benchmark + M3 only | Benchmark + M1/M2/M3 combined (any separate run) | Control: same question again | Control: off-topic filler |
|---|---|---|---|---|---|---|---|---|
| medrag | ares | 20.0% | 20.0% | 5.0% | 5.0% | 40.0% | 15.0% | 10.0% |
| medrag | datamorgana | 25.0% | 25.0% | 15.0% | 20.0% | 60.0% | 20.0% | 25.0% |
| medrag | ragas | 10.0% | 15.0% | 15.0% | 5.0% | 20.0% | 15.0% | 5.0% |

## 3. Structural metrics (all 25, averaged over the questions)

Means of each feature over the evaluated questions, for the benchmark and each mutated version. `Real` = the real user queries of that domain (if `data/real_queries/` exists). 'general' = LightRAG and RAPTOR; 'medical' = MedRAG. Feature definitions: `src/analysis/graph_features.py` and `lexical_features.py`.

### medical: mean of each feature (60 distinct questions)

| feature | Real | Benchmark (unchanged) | Benchmark + M1 only | Benchmark + M2 only | Benchmark + M3 only | Control: same question again | Control: off-topic filler |
|---|---|---|---|---|---|---|---|
| n_tokens | 22.325 | 21.583 | 40.883 | 26.067 | 42.017 | 21.583 | 43.117 |
| n_sentences | 1.630 | 1.000 | 2.050 | 1.550 | 2.000 | 1.000 | 3.450 |
| n_nodes | 9.855 | 10.350 | 19.517 | 11.683 | 19.450 | 10.350 | 16.850 |
| n_edges | 7.808 | 8.833 | 16.567 | 9.667 | 16.250 | 8.833 | 12.383 |
| graph_density | 0.181 | 0.111 | 0.057 | 0.093 | 0.048 | 0.111 | 0.057 |
| avg_degree | 1.363 | 1.662 | 1.636 | 1.623 | 1.645 | 1.662 | 1.450 |
| max_depth | 2.556 | 3.383 | 4.283 | 3.533 | 4.000 | 3.383 | 3.550 |
| n_components | 2.047 | 1.517 | 2.950 | 2.017 | 3.200 | 1.517 | 4.467 |
| largest_component_frac | 0.831 | 0.871 | 0.663 | 0.813 | 0.533 | 0.871 | 0.582 |
| n_entities | 0.959 | 0.500 | 0.917 | 0.550 | 1.400 | 0.500 | 0.500 |
| n_entity_types | 0.610 | 0.383 | 0.650 | 0.450 | 0.983 | 0.383 | 0.383 |
| has_wh_word | 0.600 | 0.750 | 0.833 | 0.750 | 0.817 | 0.750 | 0.750 |
| starts_with_verb | 0.150 | 0.000 | 0.000 | 0.150 | 0.067 | 0.000 | 0.000 |
| char_len | 112 | 119 | 225 | 140 | 223 | 119 | 214 |
| word_len | 18.585 | 19.350 | 36.117 | 23.033 | 36.600 | 19.350 | 38.317 |
| lexical_diversity | 0.940 | 0.908 | 0.811 | 0.915 | 0.799 | 0.908 | 0.867 |
| avg_word_len | 4.786 | 5.118 | 5.077 | 4.947 | 4.946 | 5.118 | 4.514 |
| n_question_marks | 0.536 | 0.600 | 0.800 | 0.583 | 1.000 | 0.600 | 0.600 |
| n_sentences_punct | 1.630 | 1.000 | 2.000 | 1.433 | 1.950 | 1.000 | 3.450 |
| starts_lowercase | 0.315 | 0.117 | 0.083 | 0.383 | 0.033 | 0.117 | 0.117 |
| has_typo_like_repeat | 0.019 | 0.000 | 0.000 | 0.083 | 0.017 | 0.000 | 0.000 |
| has_hedge | 0.009 | 0.000 | 0.000 | 0.067 | 0.050 | 0.000 | 0.000 |
| has_first_person | 0.287 | 0.133 | 0.133 | 0.517 | 0.683 | 0.133 | 0.800 |
| has_politeness_marker | 0.101 | 0.033 | 0.033 | 0.250 | 0.033 | 0.033 | 0.250 |
| ends_with_question_mark | 0.455 | 0.600 | 0.333 | 0.217 | 0.667 | 0.600 | 0.000 |

### medical: change from the benchmark (mutated minus original)

| feature | Benchmark + M1 only vs Benchmark | Benchmark + M2 only vs Benchmark | Benchmark + M3 only vs Benchmark | Control: same question again vs Benchmark | Control: off-topic filler vs Benchmark |
|---|---|---|---|---|---|
| n_tokens | +19.30* | +4.48* | +20.43* | +0.00 | +21.53* |
| n_sentences | +1.05* | +0.55* | +1.00* | +0.00 | +2.45* |
| n_nodes | +9.17* | +1.33* | +9.10* | +0.00 | +6.50* |
| n_edges | +7.73* | +0.83* | +7.42* | +0.00 | +3.55* |
| graph_density | -0.05* | -0.02* | -0.06* | +0.00 | -0.05* |
| avg_degree | -0.03 | -0.04 | -0.02 | +0.00 | -0.21* |
| max_depth | +0.90* | +0.15 | +0.62* | +0.00 | +0.17* |
| n_components | +1.43* | +0.50* | +1.68* | +0.00 | +2.95* |
| largest_component_frac | -0.21* | -0.06* | -0.34* | +0.00 | -0.29* |
| n_entities | +0.42* | +0.05 | +0.90* | +0.00 | +0.00 |
| n_entity_types | +0.27* | +0.07* | +0.60* | +0.00 | +0.00 |
| has_wh_word | +0.08* | +0.00 | +0.07* | +0.00 | +0.00 |
| starts_with_verb | +0.00 | +0.15* | +0.07* | +0.00 | +0.00 |
| char_len | +105.42* | +20.65* | +103.88* | +0.00 | +94.80* |
| word_len | +16.77* | +3.68* | +17.25* | +0.00 | +18.97* |
| lexical_diversity | -0.10* | +0.01 | -0.11* | +0.00 | -0.04* |
| avg_word_len | -0.04 | -0.17* | -0.17* | +0.00 | -0.60* |
| n_question_marks | +0.20* | -0.02 | +0.40* | +0.00 | +0.00 |
| n_sentences_punct | +1.00* | +0.43* | +0.95* | +0.00 | +2.45* |
| starts_lowercase | -0.03 | +0.27* | -0.08* | +0.00 | +0.00 |
| has_typo_like_repeat | +0.00 | +0.08* | +0.02 | +0.00 | +0.00 |
| has_hedge | +0.00 | +0.07* | +0.05 | +0.00 | +0.00 |
| has_first_person | +0.00 | +0.38* | +0.55* | +0.00 | +0.67* |
| has_politeness_marker | +0.00 | +0.22* | +0.00 | +0.00 | +0.22* |
| ends_with_question_mark | -0.27* | -0.38* | +0.07* | +0.00 | -0.60* |
