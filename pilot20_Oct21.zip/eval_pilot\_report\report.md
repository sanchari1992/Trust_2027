# Benchmark vs Benchmark+ : hallucination results

Profile: `pilot`. Faithfulness threshold: 1.0. All mutated results are compared with the original benchmark question by question (paired).

## All RAGs and methods pooled

| condition | n | hallucination_rate | hall_ci_low | hall_ci_high | failure_rate | unfaithful_rate | unsupported_but_correct_rate | unfaithful_and_wrong_rate | retrieval_hit_rate | abstain_rate | mean_faithfulness |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Benchmark (unchanged) | 60 | 0.183 | 0.106 | 0.299 | 0.133 | 0.067 | 0.067 | 0.000 | 0.533 | 0.017 | 0.973 |
| Benchmark + M1 only | 60 | 0.200 | 0.118 | 0.318 | 0.167 | 0.067 | 0.050 | 0.017 | 0.517 | 0.017 | 0.975 |
| Benchmark + M2 only | 60 | 0.117 | 0.058 | 0.222 | 0.150 | 0.050 | 0.000 | 0.050 | 0.517 | 0.033 | 0.982 |
| Benchmark + M3 only | 60 | 0.100 | 0.047 | 0.201 | 0.150 | 0.033 | 0.033 | 0.000 | 0.517 | 0.083 | 0.994 |
| Benchmark + M1/M2/M3 combined (any separate run) | 60 | 0.400 | 0.286 | 0.526 | 0.383 | 0.150 | 0.117 | 0.050 | 0.450 | 0.133 | 0.952 |
| Control: same question again | 60 | 0.167 | 0.093 | 0.280 | 0.117 | 0.083 | 0.083 | 0.000 | 0.533 | 0.033 | 0.971 |
| Control: off-topic filler | 60 | 0.133 | 0.069 | 0.242 | 0.217 | 0.100 | 0.083 | 0.017 | 0.400 | 0.167 | 0.979 |

## Paired change in hallucination rate vs the original benchmark (pooled)

`diff` is condition minus baseline with a 95% paired-bootstrap interval; `newly_failing` = questions the RAG handled in the benchmark but hallucinated on in the mutated version; `newly_passing` = the reverse; `q_value` = McNemar exact test, Benjamini-Hochberg corrected.

| condition | n_pairs | baseline_rate | condition_rate | diff | diff_ci_low | diff_ci_high | newly_failing | newly_passing | q_value |
|---|---|---|---|---|---|---|---|---|---|
| Benchmark + M1 only | 60 | 0.183 | 0.200 | 0.017 | -0.100 | 0.133 | 7 | 6 | 1.000 |
| Benchmark + M2 only | 60 | 0.183 | 0.117 | -0.067 | -0.183 | 0.050 | 4 | 8 | 1.000 |
| Benchmark + M3 only | 60 | 0.183 | 0.100 | -0.083 | -0.200 | 0.033 | 5 | 10 | 1.000 |
| Benchmark + M1/M2/M3 combined (any separate run) | 60 | 0.183 | 0.400 | 0.217 | 0.117 | 0.333 | 13 | 0 | 0.004 |
| Control: same question again | 60 | 0.183 | 0.167 | -0.017 | -0.100 | 0.067 | 3 | 4 | 1.000 |
| Control: off-topic filler | 60 | 0.183 | 0.133 | -0.050 | -0.167 | 0.067 | 5 | 8 | 1.000 |

## Hallucinations found: benchmark alone vs benchmark + mutations

A question counts as a hallucination found by the mutations if it was fine in the original benchmark but a mutated version made the RAG hallucinate.

| level | rag | n_questions | found_by_benchmark | found_by_benchmark_plus_mutations | extra_found_by_mutations | extra_found_by_controls | extra_found_by_mutations_beyond_controls | benchmark_rate | union_rate | fold_increase |
|---|---|---|---|---|---|---|---|---|---|---|
| rag | medrag | 60 | 11 | 24 | 13 | 6 | 9 | 0.183 | 0.400 | 2.182 |
| overall | ALL | 60 | 11 | 24 | 13 | 6 | 9 | 0.183 | 0.400 | 2.182 |

`extra_found_by_controls`: the same count for the control conditions (no useful change: a re-run, and filler padding). `extra_found_by_mutations_beyond_controls`: questions that only a mutation exposed, that neither control did. Only this last column is evidence that the mutations themselves help.

## The same change measured two other ways (pooled)

`wrong_behavior`: only answers that assert something wrong or adopt a false / unsupported claim (no faithfulness involved). `hallucinated_strict`: unfaithfulness against the retrieved context ALONE, i.e. a statement repeating what the user said is not accepted as supported. If a mutation shows a change in `hallucinated` but not in these, check it with scripts/audit_hallucinations.py.

| metric | condition | n_pairs | baseline_rate | condition_rate | diff | diff_ci_low | diff_ci_high | newly_failing | newly_passing | q_value |
|---|---|---|---|---|---|---|---|---|---|---|
| wrong_behavior | Benchmark + M1 only | 60 | 0.117 | 0.150 | 0.033 | -0.067 | 0.133 | 6 | 4 | 1.000 |
| wrong_behavior | Benchmark + M2 only | 60 | 0.117 | 0.117 | 0.000 | -0.100 | 0.100 | 5 | 5 | 1.000 |
| wrong_behavior | Benchmark + M3 only | 60 | 0.117 | 0.067 | -0.050 | -0.150 | 0.050 | 3 | 6 | 1.000 |
| wrong_behavior | Benchmark + M1/M2/M3 combined (any separate run) | 60 | 0.117 | 0.300 | 0.183 | 0.083 | 0.283 | 11 | 0 | 0.015 |
| wrong_behavior | Control: same question again | 60 | 0.117 | 0.083 | -0.033 | -0.100 | 0.033 | 1 | 3 | 1.000 |
| wrong_behavior | Control: off-topic filler | 60 | 0.117 | 0.050 | -0.067 | -0.167 | 0.017 | 2 | 6 | 1.000 |
| hallucinated_strict | Benchmark + M1 only | 60 | 0.233 | 0.200 | -0.033 | -0.150 | 0.083 | 7 | 9 | 1.000 |
| hallucinated_strict | Benchmark + M2 only | 60 | 0.233 | 0.167 | -0.067 | -0.184 | 0.050 | 5 | 9 | 0.846 |
| hallucinated_strict | Benchmark + M3 only | 60 | 0.233 | 0.117 | -0.117 | -0.250 | 0.000 | 5 | 12 | 0.673 |
| hallucinated_strict | Benchmark + M1/M2/M3 combined (any separate run) | 60 | 0.233 | 0.467 | 0.233 | 0.133 | 0.350 | 14 | 0 | 0.002 |
| hallucinated_strict | Control: same question again | 60 | 0.233 | 0.217 | -0.017 | -0.117 | 0.083 | 4 | 5 | 1.000 |
| hallucinated_strict | Control: off-topic filler | 60 | 0.233 | 0.133 | -0.100 | -0.217 | 0.017 | 4 | 10 | 0.673 |
| unsupported_but_correct | Benchmark + M1 only | 60 | 0.067 | 0.050 | -0.017 | -0.083 | 0.033 | 1 | 2 | 1.000 |
| unsupported_but_correct | Benchmark + M2 only | 60 | 0.067 | 0.000 | -0.067 | -0.133 | -0.017 | 0 | 4 | 1.000 |
| unsupported_but_correct | Benchmark + M3 only | 60 | 0.067 | 0.033 | -0.033 | -0.117 | 0.033 | 2 | 4 | 1.000 |
| unsupported_but_correct | Benchmark + M1/M2/M3 combined (any separate run) | 60 | 0.067 | 0.117 | 0.050 | 0.000 | 0.117 | 3 | 0 | 1.000 |
| unsupported_but_correct | Control: same question again | 60 | 0.067 | 0.083 | 0.017 | -0.033 | 0.083 | 2 | 1 | 1.000 |
| unsupported_but_correct | Control: off-topic filler | 60 | 0.067 | 0.083 | 0.017 | -0.083 | 0.117 | 5 | 4 | 1.000 |
| unfaithful_and_wrong | Benchmark + M1 only | 60 | 0.000 | 0.017 | 0.017 | 0.000 | 0.050 | 1 | 0 | 1.000 |
| unfaithful_and_wrong | Benchmark + M2 only | 60 | 0.000 | 0.050 | 0.050 | 0.000 | 0.117 | 3 | 0 | 1.000 |
| unfaithful_and_wrong | Benchmark + M3 only | 60 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0 | 0 | 1.000 |
| unfaithful_and_wrong | Benchmark + M1/M2/M3 combined (any separate run) | 60 | 0.000 | 0.050 | 0.050 | 0.000 | 0.117 | 3 | 0 | 1.000 |
| unfaithful_and_wrong | Control: same question again | 60 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0 | 0 | 1.000 |
| unfaithful_and_wrong | Control: off-topic filler | 60 | 0.000 | 0.017 | 0.017 | 0.000 | 0.050 | 1 | 0 | 1.000 |

## Retrieval: do mutated prompts retrieve the original source passage?

`retrieval_hit_rate`: share of answers whose retrieved passages include an original source passage of the question. `hallucination_rate_when_miss` vs `_when_hit`: whether hallucination goes with a retrieval miss. If a condition retrieves worse, its extra hallucinations are a retrieval effect (the query got diluted), not the model being fooled.

| condition | n | retrieval_hit_rate | mean_gold_recall | hallucination_rate_when_hit | hallucination_rate_when_miss | n_miss |
|---|---|---|---|---|---|---|
| Benchmark (unchanged) | 60 | 0.533 | 0.533 | 0.156 | 0.214 | 28 |
| Benchmark + M1 only | 60 | 0.517 | 0.517 | 0.161 | 0.241 | 29 |
| Benchmark + M2 only | 60 | 0.517 | 0.517 | 0.032 | 0.207 | 29 |
| Benchmark + M3 only | 60 | 0.517 | 0.517 | 0.032 | 0.172 | 29 |
| Benchmark + M1/M2/M3 combined (any separate run) | 60 | 0.450 | 0.450 | 0.259 | 0.515 | 33 |
| Control: same question again | 60 | 0.533 | 0.533 | 0.125 | 0.214 | 28 |
| Control: off-topic filler | 60 | 0.400 | 0.400 | 0.000 | 0.222 | 36 |

## Hallucination rate per RAG and method

| rag | method | baseline | m1 | m2 | m3 | m_union | c_rerun | c_pad |
|---|---|---|---|---|---|---|---|---|
| medrag | ares | 0.200 | 0.200 | 0.050 | 0.050 | 0.400 | 0.150 | 0.100 |
| medrag | datamorgana | 0.250 | 0.250 | 0.150 | 0.200 | 0.600 | 0.200 | 0.250 |
| medrag | ragas | 0.100 | 0.150 | 0.150 | 0.050 | 0.200 | 0.150 | 0.050 |

## By operator (hallucination rate; a question with two operators counts for both)

| condition | operator | n | hallucination_rate | baseline_rate_same_questions | failure_rate | mean_faithfulness |
|---|---|---|---|---|---|---|
| m1 | m1:appositive | 17 | 0.176 | 0.118 | 0.176 | 0.961 |
| m1 | m1:background | 15 | 0.267 | 0.133 | 0.200 | 0.993 |
| m1 | m1:instruction | 39 | 0.179 | 0.231 | 0.154 | 0.981 |
| m1 | m1:restate | 12 | 0.167 | 0.250 | 0.083 | 0.967 |
| m2 | m2:casual | 29 | 0.069 | 0.103 | 0.103 | 1.000 |
| m2 | m2:first_person | 19 | 0.053 | 0.316 | 0.105 | 1.000 |
| m2 | m2:imperative | 10 | 0.200 | 0.100 | 0.200 | 0.985 |
| m2 | m2:politeness | 16 | 0.125 | 0.312 | 0.188 | 0.943 |
| m2 | m2:synonyms | 10 | 0.100 | 0.100 | 0.100 | 0.933 |
| m2 | m2:typos | 36 | 0.167 | 0.167 | 0.194 | 0.989 |
| m3 | m3:correct_candidate | 15 | 0.067 | 0.267 | 0.067 | 1.000 |
| m3 | m3:false_premise | 8 | 0.250 | 0.250 | 0.000 | 0.958 |
| m3 | m3:patient_conflict | 4 | 0.000 | 0.000 | 0.000 | 1.000 |
| m3 | m3:patient_consistent | 10 | 0.100 | 0.200 | 0.400 | 1.000 |
| m3 | m3:true_premise | 7 | 0.000 | 0.286 | 0.143 | 1.000 |
| m3 | m3:unsupported_assumption | 9 | 0.222 | 0.111 | 0.222 | 1.000 |
| m3 | m3:wrong_candidate | 7 | 0.000 | 0.000 | 0.143 | 1.000 |

## Mutation 3 (user information) by kind and operator

| condition | kind | m3_operator | n | hallucination_rate | failure_rate | unfaithful_rate | refusal_rate |
|---|---|---|---|---|---|---|---|
| m3 | correct | m3:correct_candidate | 15 | 0.067 | 0.067 | 0.000 | 0.000 |
| m3 | correct | m3:patient_consistent | 10 | 0.100 | 0.400 | 0.000 | 0.300 |
| m3 | correct | m3:true_premise | 7 | 0.000 | 0.143 | 0.000 | 0.143 |
| m3 | incorrect | m3:false_premise | 8 | 0.250 | 0.000 | 0.250 | 0.000 |
| m3 | incorrect | m3:patient_conflict | 4 | 0.000 | 0.000 | 0.000 | 0.500 |
| m3 | incorrect | m3:unsupported_assumption | 9 | 0.222 | 0.222 | 0.000 | 0.222 |
| m3 | incorrect | m3:wrong_candidate | 7 | 0.000 | 0.143 | 0.000 | 0.143 |
