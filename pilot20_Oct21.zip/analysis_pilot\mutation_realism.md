# Do mutated questions look more like real queries?

AUC of a classifier separating the question set from real user queries (0.5 = indistinguishable, lower is more realistic).

| rag | method | baseline | m1 | m2 | m3 |
|---|---|---|---|---|---|
| medrag | ares | 0.908 | 0.958 | 0.784 | 0.996 |
| medrag | datamorgana | 0.769 | 0.962 | 0.883 | 0.982 |
| medrag | ragas | 0.988 | 0.992 | 0.940 | 0.998 |

## Mean over RAGs and methods

| condition | mean_auc | mean_n_sig_features | mean_words |
|---|---|---|---|
| Benchmark (unchanged) | 0.888 | 12.000 | 19.350 |
| Benchmark + M1 only | 0.971 | 16.333 | 36.117 |
| Benchmark + M2 only | 0.869 | 12.000 | 23.033 |
| Benchmark + M3 only | 0.992 | 18.000 | 36.600 |
