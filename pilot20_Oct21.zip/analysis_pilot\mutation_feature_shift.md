# Feature means: real queries vs each condition

Mutations should move the generated questions toward the real-query values (first row of each table). Conditions are pooled over RAGs and methods (weighted by number of questions).

## general

| condition | n | n_sentences | starts_with_verb | starts_lowercase | has_first_person | has_politeness_marker | has_typo_like_repeat | ends_with_question_mark | has_wh_word | n_tokens | n_entities | n_components |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| REAL QUERIES | 4000 | 2.837 | 0.366 | 0.273 | 0.306 | 0.112 | 0.122 | 0.174 | 0.530 | 54.341 | 3.014 | 3.760 |

## medical

| condition | n | n_sentences | starts_with_verb | starts_lowercase | has_first_person | has_politeness_marker | has_typo_like_repeat | ends_with_question_mark | has_wh_word | n_tokens | n_entities | n_components |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| REAL QUERIES | 1165 | 1.630 | 0.150 | 0.315 | 0.287 | 0.101 | 0.019 | 0.455 | 0.600 | 22.325 | 0.959 | 2.047 |
| Benchmark (unchanged) | 60 | 1.000 | 0.000 | 0.117 | 0.133 | 0.033 | 0.000 | 0.600 | 0.750 | 21.583 | 0.500 | 1.517 |
| Benchmark + M1 only | 60 | 2.050 | 0.000 | 0.083 | 0.133 | 0.033 | 0.000 | 0.333 | 0.833 | 40.883 | 0.917 | 2.950 |
| Benchmark + M2 only | 60 | 1.550 | 0.150 | 0.383 | 0.517 | 0.250 | 0.083 | 0.217 | 0.750 | 26.067 | 0.550 | 2.017 |
| Benchmark + M3 only | 60 | 2.000 | 0.067 | 0.033 | 0.683 | 0.033 | 0.017 | 0.667 | 0.817 | 42.017 | 1.400 | 3.200 |
