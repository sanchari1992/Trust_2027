# Examples for the paper

## medrag

### A. Simple benchmark queries (one method each)

- **ragas** `ragas-medrag-0013`: How are dietary purine bases processed after being taken into enterocytes, and what happens to the resulting uric acid?
  - reference answer: Dietary purine bases are taken into enterocytes and degraded to uric acid within those cells (they are not used to any appreciable extent for tissue nucleic acid synthesis). Most of the resulting uric acid then enters the blood and is eventually excreted in t…
- **ragas** `ragas-medrag-0006`: What must be defined about any tumor in relation to the facial nerve, and why is this important?
  - reference answer: The relationship of any tumor to the branches of the facial nerve [VII] must be defined. This is important because resection of the tumor may damage the nerve.
- **ragas** `ragas-medrag-0010`: What is the role of UCP1, also known as thermogenin, in the mitochondria-rich brown adipocytes of mammals?
  - reference answer: Based on the context, UCP1 (thermogenin) is responsible for heat production in the mitochondria-rich brown adipocytes of mammals. It forms a channel in the inner mitochondrial membrane that allows H+ to reenter the mitochondrial matrix without energy being ca…
- **ares** `ares-medrag-0016`: Nerves that carry conscious sensations from peripheral regions back to the CNS, and nerves that innervate voluntary muscles.
  - reference answer: The somatic part of the nervous system consists of nerves that carry conscious sensations from peripheral regions back to the CNS, and nerves that innervate voluntary muscles.
- **ares** `ares-medrag-0013`: They are efficiently taken up from blood by the hepatocytes via an isoform of the cotransporter and reused.
  - reference answer: Bile salts are efficiently taken up from blood by the hepatocytes via an isoform of the cotransporter and reused.
- **ares** `ares-medrag-0018`: Bariatric surgery in morbidly obese individuals with T2D has been shown to result in disease remission in most patients.
  - reference answer: Remission may not be permanent.
- **datamorgana** `datamorgana-medrag-0010`: pulmonary sinuses recoil of blood forces cusps closed prevents refilling right ventricle mechanism
  - reference answer: After ventricular contraction, the recoil of blood fills the pulmonary sinuses and forces the cusps closed, which prevents blood in the pulmonary trunk from refilling the right ventricle.
- **datamorgana** `datamorgana-medrag-0015`: I study birth defects—how does a flat sheet roll into a tube?
  - reference answer: Converting an epithelial sheet into a tube depends on contraction of specific bundles of actin filaments. With the help of myosin motor proteins, these actin bundles shorten, causing the epithelial cells to narrow at their apex, which bends the sheet into a t…
- **datamorgana** `datamorgana-medrag-0003`: which spinal vertebra marks the upper boundary of the bony canal housing the cord
  - reference answer: the first cervical vertebra (CI)

### B. Realistic queries (real users)

- Are low carbs diets goof for weight loss?
- Give brief bullet points of why supermarkets are gateways to pharmaceutical drugs, due to many/most foods in super markets leading to bad health.
- Let's discuss the topic of plastic surgery. What are the risks and benefits?

### C. Named entities and graph templates

**benchmark** `ragas-medrag-0005`: What are the two categories into which cancer-critical mutations fall, and how do oncogenes and tumor suppressor genes differ in the manner in which their mutations act?

- entities: two <CARDINAL>, cancer-critical mutations <CONCEPT>, oncogenes <CONCEPT>, tumor suppressor genes <CONCEPT>, manner <CONCEPT>, mutations <CONCEPT>
- text template: `What are the {CARDINAL} categories into which {CONCEPT} fall, and how do {CONCEPT} and {CONCEPT} differ in the {CONCEPT} in which their {CONCEPT} act?`
- graph template (`d92727b89f`): `WH:what ; NOUN[relcl>VERB[pobj>NOUN[amod>ADJ[npadvmod>NOUN]]]] | VERB[npadvmod>NOUN[nsubj>NOUN],nsubj>NOUN[conj>NOUN[compound>NOUN,compound>NOUN]],pobj>NOUN]`
- shape: `what|S1|N11+|D4+|E1`
- reference answer: Cancer-critical mutations fall into two categories: dominant and recessive. Oncogenes act in a dominant manner—a gain-of-function mutation in a single copy of the gene can drive a cell toward cancer.…
- answer entities: Cancer-critical mutations <CONCEPT>, two <CARDINAL>, Oncogenes act <CONCEPT>, dominant manner <CONCEPT>, function <CONCEPT>, single copy <CONCEPT>, gene <CONCEPT>, cell <CONCEPT>
- answer template (first sentence): `VERB[nsubj>NOUN[amod>ADJ[npadvmod>NOUN]],pobj>NOUN[amod>ADJ[conj>ADJ]]]`; shape `when|S3+|N11+|D4+|E3+`

```
|-- category (NOUN)
|   `-- [relcl] fall (VERB)
|       `-- [pobj] mutation (NOUN)
|           `-- [amod] critical (ADJ)
|               `-- [npadvmod] cancer (NOUN)
`-- differ (VERB)
    |-- [nsubj] oncogene (NOUN)
    |   `-- [conj] gene (NOUN)
    |       |-- [compound] tumor (NOUN)
    |       `-- [compound] suppressor (NOUN)
    |-- [pobj] manner (NOUN)
    `-- [npadvmod] act (NOUN)
        `-- [nsubj] mutation (NOUN)
```

**benchmark** `ares-medrag-0008`: Allopurinol is oxidized to oxypurinol, a long-lived inhibitor of XO.

- entities: Allopurinol <ORG>, oxypurinol <CONCEPT>, long-lived inhibitor <CONCEPT>, XO <ORG>
- text template: `{ORG} is oxidized to {CONCEPT}, a {CONCEPT} of {ORG}.`
- graph template (`57005587d0`): `VERB[nsubjpass>ENT:ORG,pobj>NOUN[appos>NOUN[amod>VERB[advmod>ADV],pobj>ENT:ORG]]]`
- shape: `OTHER|S1|N7-10|D4+|E2`
- reference answer: Allopurinol is oxidized to oxypurinol, a long-lived inhibitor of XO.
- answer entities: Allopurinol <ORG>, oxypurinol <CONCEPT>, long-lived inhibitor <CONCEPT>, XO <ORG>
- answer template (first sentence): `VERB[nsubjpass>ENT:ORG,pobj>NOUN[appos>NOUN[amod>VERB[advmod>ADV],pobj>ENT:ORG]]]`; shape `OTHER|S1|N7-10|D4+|E2`

```
`-- oxidize (VERB)
    |-- [nsubjpass] allopurinol <ORG>
    `-- [pobj] oxypurinol (NOUN)
        `-- [appos] inhibitor (NOUN)
            |-- [amod] live (VERB)
            |   `-- [advmod] long (ADV)
            `-- [pobj] xo <ORG>
```

**benchmark** `ares-medrag-0015`: What are the symptoms of Wernicke-Korsakoff syndrome?

- entities: symptoms <CONCEPT>, Wernicke-Korsakoff <PERSON>
- text template: `What are the {CONCEPT} of {PERSON} syndrome?`
- graph template (`e6b626e986`): `WH:what ; NOUN[pobj>NOUN[compound>ENT:PERSON]]`
- shape: `what|S1|N4-6|D3|E1`
- reference answer: The symptoms include mental confusion, gait ataxia, nystagmus, ophthalmoplegia, memory problems, and hallucinations.
- answer entities: symptoms <CONCEPT>, mental confusion <CONCEPT>, gait ataxia <PERSON>
- answer template (first sentence): `VERB[dobj>NOUN[amod>ADJ],npadvmod>ENT:PERSON[conj>NOUN[compound>NOUN,conj>NOUN],conj>PROPN[conj>PROPN]],nsubj>NOUN]`; shape `OTHER|S1|N11+|D3|E1`

```
`-- symptom (NOUN)
    `-- [pobj] syndrome (NOUN)
        `-- [compound] korsakoff <PERSON>
```

**real** `real-medical-lmsys-e5c35599b8e2443fbf0bd08c6d8e8de8`: Are low carbs diets goof for weight loss?

- entities: goof <CONCEPT>, weight loss <CONCEPT>
- text template: `Are low carbs diets {CONCEPT} for {CONCEPT}?`
- graph template (`233596151a`): `VERB[amod>ADJ[amod>ADJ],dobj>NOUN[pobj>NOUN[compound>NOUN]]]`
- shape: `AUX|S1|N4-6|D3|E0`

```
`-- diet (VERB)
    |-- [amod] carbs (ADJ)
    |   `-- [amod] low (ADJ)
    `-- [dobj] goof (NOUN)
        `-- [pobj] loss (NOUN)
            `-- [compound] weight (NOUN)
```

### D. Mutated queries

**ragas** `ragas-medrag-0014`

- original: What gives the backbone of a DNA strand its directionality, and how does this directionality affect the way information in DNA is read and copied?
  - RAG on the original: hallucinated=False, correct=True, refused=False
- Elaborate (m1; operators m1:background, m1:instruction): A single strand of DNA consists of nucleotides joined together by sugar-phosphate linkages. What gives the backbone of a DNA strand its directionality, and how does this directionality affect the way information in DNA is read and copied? Answer as precisely as you can.
  - reference answer for this prompt: The backbone of a DNA strand gets its directionality (polarity) from the asymmetric sugar-phosphate units that make up the strand. This directionality guides h… (expected: answer)
  - RAG: hallucinated=True, correct=False, refused=False; response: The individual sugar-phosphate units are asymmetric, giving the backbone a definite directionality (polarity). This directionality guides the molecular processes by which DNA information is interpreted and copied: the information is always "read" in a consistent order, just as written English text is read from left to…
- Colloquial (m2; operators m2:imperative, m2:casual): tell me what gives the backbone of a DNA strand its directionality, and how does this directionality affect the way information in DNA is read and copied
  - reference answer for this prompt: The backbone of a DNA strand gets its directionality (polarity) from the asymmetric sugar-phosphate units that make up the strand. This directionality guides h… (expected: answer)
  - RAG: hallucinated=False, correct=True, refused=False; response: The backbone's directionality comes from the asymmetric sugar-phosphate units: each sugar has a 5ʹ phosphate "knob" on one side and a 3ʹ hydroxyl "hole" on the other, so the subunits line up in the same orientation, giving the chain a 5ʹ end and a 3ʹ end (Documents [1], [2], [15]). This directionality guides how the i…
- Premise (m3; operators m3:correct_candidate; correct claim): What gives the backbone of a DNA strand its directionality, and how does this directionality affect the way information in DNA is read and copied? So asymmetric sugar-phosphate units create polarity that guides consistent reading and copying, right?
  - reference answer for this prompt: The backbone of a DNA strand gets its directionality (polarity) from the asymmetric sugar-phosphate units that make up the strand. This directionality guides h… (expected: answer)
  - RAG: hallucinated=False, correct=True, refused=False; response: Yes. The asymmetric sugar-phosphate units give the backbone a definite directionality (polarity), with distinguishable 5′ and 3′ ends, and this polarity guides the consistent reading and copying of the DNA information.

**ragas** `ragas-medrag-0006`

- original: What must be defined about any tumor in relation to the facial nerve, and why is this important?
  - RAG on the original: hallucinated=False, correct=True, refused=False
- Elaborate (m1; operators m1:appositive): What must be defined about any tumor in relation to the facial nerve (nerve formed from nuclei within the brainstem), and why is this important?
  - reference answer for this prompt: The relationship of any tumor to the branches of the facial nerve [VII] must be defined. This is important because resection of the tumor may damage the nerve. (expected: answer)
  - RAG: hallucinated=False, correct=True, refused=False; response: The relationship of any tumor to the branches of the facial nerve [VII] must be defined, because resection of the tumor may damage the nerve.
- Colloquial (m2; operators m2:imperative, m2:typos): Explain what must be defined about any tmuor in relation to the facial nerve, and why is this important.
  - reference answer for this prompt: The relationship of any tumor to the branches of the facial nerve [VII] must be defined. This is important because resection of the tumor may damage the nerve. (expected: answer)
  - RAG: hallucinated=True, correct=False, refused=False; response: The documents state that the facial nerve [VII] follows a complex course—emerging at the pons-medulla junction, entering the internal acoustic meatus, passing to the geniculate ganglion, running within the temporal bone, exiting via the stylomastoid foramen, and entering the parotid gland before dividing into terminal…
- Premise (m3; operators m3:false_premise; incorrect claim): I read somewhere that the relationship of any tumor to the branches of the facial nerve need not be defined because resection of the tumor cannot damage the nerve. What must be defined about any tumor in relation to the facial nerve, and why is this important?
  - reference answer for this prompt: That is not correct. The relationship of any tumor to the branches of the facial nerve must be defined because resection of the tumor may damage the nerve. The… (expected: reject_premise)
  - RAG: hallucinated=False, correct=True, refused=False; response: The relationship of any tumor to the branches of the facial nerve [VII] must be defined because resection of the tumor may damage the nerve.

**ragas** `ragas-medrag-0002`

- original: What does the ratio kcat/Km represent when the substrate concentration is much lower than Km?
  - RAG on the original: hallucinated=False, correct=True, refused=False
- Elaborate (m1; operators m1:background): The Michaelis–Menten equation describes the rate of an enzyme-catalyzed reaction, and at very low substrate concentrations most of the enzyme is free. What does the ratio kcat/Km represent when the substrate concentration is much lower than Km?
  - reference answer for this prompt: When the substrate concentration is much lower than Km, the ratio kcat/Km is equivalent to the rate constant for the reaction between free enzyme and free subs… (expected: answer)
  - RAG: hallucinated=False, correct=True, refused=False; response: When [S] << Km, most of the enzyme is free, so [E] ≈ [Eo] and the Michaelis–Menten equation becomes V = kcat/Km [E][S]. Thus, the ratio kcat/Km is equivalent to the rate constant for the reaction between free enzyme and free substrate.
- Colloquial (m2; operators m2:first_person, m2:casual): I was wondering about something. What does the ratio kcat/Km represent when the substrate concentration is much lower than Km
  - reference answer for this prompt: When the substrate concentration is much lower than Km, the ratio kcat/Km is equivalent to the rate constant for the reaction between free enzyme and free subs… (expected: answer)
  - RAG: hallucinated=False, correct=True, refused=False; response: When [S] << Km, the ratio kcat/Km is equivalent to the rate constant for the reaction between free enzyme and free substrate (Document [0]).
- Premise (m3; operators m3:unsupported_assumption; incorrect claim): Just so you know, the enzyme we're looking at is a monomeric enzyme with a single active site. What does the ratio kcat/Km represent when the substrate concentration is much lower than Km?
  - reference answer for this prompt: The provided information does not mention this detail, so the question cannot be answered as stated; the detail should not be treated as established. (expected: abstain)
  - RAG: hallucinated=False, correct=True, refused=False; response: The ratio kcat/Km is equivalent to the rate constant for the reaction between free enzyme and free substrate.

**ares** `ares-medrag-0004`

- original: The bonds that hold the molecules in their proper places on the template and join them together must be strong enough to resist the disordering effect of thermal motion.
  - RAG on the original: hallucinated=False, correct=False, refused=False
- Elaborate (m1; operators m1:appositive): The bonds that hold the molecules in their proper places on the template and join them together must be strong enough to resist the disordering effect of thermal motion (violent random movement of molecules buffeted by collisions).
  - reference answer for this prompt: The bonds must be strong enough to resist the disordering effect of thermal motion. (expected: answer)
  - RAG: hallucinated=True, correct=False, refused=False; response: Covalent bonds.
- Colloquial (m2; operators m2:synonyms, m2:politeness): The bonds that hold the molecules in their proper places on the template and join them together must be potent enough to resist the disordering effect of thermal motion. Thank you!
  - reference answer for this prompt: The bonds must be strong enough to resist the disordering effect of thermal motion. (expected: answer)
  - RAG: hallucinated=True, correct=False, refused=False; response: Covalent bonds.
- Premise (m3; operators m3:wrong_candidate; incorrect claim): The bonds that hold the molecules in their proper places on the template and join them together must be strong enough to resist the disordering effect of thermal motion. I'm guessing the bonds have to be weak enough that thermal motion can disorder them — is that right?
  - reference answer for this prompt: No, that is not correct. The bonds must be strong enough to resist the disordering effect of thermal motion. (expected: reject_premise)
  - RAG: hallucinated=False, correct=True, refused=False; response: No. The documents state the opposite: the bonds holding molecules in place on a template and joining them must be strong enough to resist the disordering effect of thermal motion.

**ares** `ares-medrag-0017`

- original: How can this small number of signaling pathways generate the huge diversity of cells and patterns?
  - RAG on the original: hallucinated=False, correct=True, refused=False
- Elaborate (m1; operators m1:background): Most of the known inductive events in animal development are governed by a small number of highly conserved signaling pathways, including TGFβ, Wnt, Hedgehog, Notch, and RTK pathways. How can this small number of signaling pathways generate the huge diversity of cells and patterns?
  - reference answer for this prompt: Through combinatorial control and cell memory, simple signals can generate complex patterns. (expected: answer)
  - RAG: hallucinated=True, correct=True, refused=False; response: Three mechanisms are responsible: (1) gene duplication, so pathway components come to be encoded by small families of closely related homologous genes, allowing diversity according to which family member is employed (e.g., Notch1 vs. Notch4); (2) combinatorial signaling—a cell's response to a given signal depends on o…
- Colloquial (m2; operators m2:synonyms, m2:typos): How can this little number of signaling pathwaays generate the huge diversity of cells and patterns?
  - reference answer for this prompt: Through combinatorial control and cell memory, simple signals can generate complex patterns. (expected: answer)
  - RAG: hallucinated=False, correct=True, refused=False; response: Three mechanisms are responsible: (1) gene duplication, so pathway components are encoded by small families of closely related homologous genes, allowing diversity according to which family member is used (e.g., Notch1 vs. Notch4); (2) the response to a signal depends on other signals the cell receives concurrently, s…
- Premise (m3; operators m3:patient_consistent; correct claim): I am a 38-year-old man with a history of well-controlled asthma. How can this small number of signaling pathways generate the huge diversity of cells and patterns?
  - reference answer for this prompt: Through combinatorial control and cell memory, simple signals can generate complex patterns. (expected: answer)
  - RAG: hallucinated=False, correct=True, refused=False; response: Based on the documents, the small number of signaling pathways can generate huge diversity through three mechanisms: (1) gene duplication, so pathway components are encoded by small families of closely related homologous genes, allowing diversity according to which family member is used (e.g., Notch1 vs. Notch4 in dif…

**ares** `ares-medrag-0020`

- original: The corpus callosum is formed by myelinated axons horizontally linking the two cerebral hemispheres and is divided into a rostrum, genu, body, and splenium.
  - RAG on the original: hallucinated=False, correct=True, refused=False
- Elaborate (m1; operators m1:instruction): The corpus callosum is formed by myelinated axons horizontally linking the two cerebral hemispheres and is divided into a rostrum, genu, body, and splenium. Be specific rather than general.
  - reference answer for this prompt: The corpus callosum is formed by myelinated axons horizontally linking the two cerebral hemispheres and is divided into a rostrum, genu, body, and splenium. (expected: answer)
  - RAG: hallucinated=False, correct=True, refused=False; response: The corpus callosum is formed by myelinated axons horizontally linking the two cerebral hemispheres, and it is divided into a rostrum, genu, body, and splenium.
- Colloquial (m2; operators m2:casual, m2:typos): the corpus callosum is formed by myelinated axons horizontally likning the two cdrebral hemispheres and is divided into a rostrum, genu, body, and splenium
  - reference answer for this prompt: The corpus callosum is formed by myelinated axons horizontally linking the two cerebral hemispheres and is divided into a rostrum, genu, body, and splenium. (expected: answer)
  - RAG: hallucinated=False, correct=True, refused=False; response: Yes, that is correct according to the documents. Document [0] states that the corpus callosum is formed by myelinated axons horizontally linking the two cerebral hemispheres and is divided into a rostrum, genu, body, and splenium.
- Premise (m3; operators m3:patient_conflict; incorrect claim): For context: I was born without a corpus callosum—my doctors call it agenesis. Does that change how my hemispheres connect? The corpus callosum is formed by myelinated axons horizontally linking the two cerebral hemispheres and is divided into a rostrum, genu, body, and splenium.
  - reference answer for this prompt: Cannot be answered from given information. (expected: abstain)
  - RAG: hallucinated=False, correct=True, refused=True; response: Cannot be answered from given information.

**datamorgana** `datamorgana-medrag-0005`

- original: I do public health messaging; why are thymine dimers bad?
  - RAG on the original: hallucinated=False, correct=True, refused=False
- Elaborate (m1; operators m1:appositive): I do public health messaging; why are thymine dimers (covalently joined adjacent pyrimidines, usually thymines, caused by UV radiation) bad?
  - reference answer for this prompt: Exposure to UV radiation can covalently join two adjacent pyrimidines (usually thymines), producing a dimer. These intrastrand cross-links prevent DNA pol from… (expected: answer)
  - RAG: hallucinated=True, correct=False, refused=False; response: Thymine dimers are bad because, if left uncorrected when DNA is replicated, such UV-induced damage would be expected to lead either to the deletion of one or more base pairs or to a base-pair substitution in the daughter DNA chain, and the mutations would then be propagated throughout subsequent cell generations—a hig…
- Colloquial (m2; operators m2:casual, m2:typos): hi, I do public health messaging; why are thymmine dimers bad?
  - reference answer for this prompt: Exposure to UV radiation can covalently join two adjacent pyrimidines (usually thymines), producing a dimer. These intrastrand cross-links prevent DNA pol from… (expected: answer)
  - RAG: hallucinated=True, correct=False, refused=False; response: Thymine dimers are bad because, if left uncorrected when DNA is replicated, they would be expected to lead either to the deletion of one or more base pairs or to a base-pair substitution in the daughter DNA chain; the mutations would then be propagated throughout subsequent cell generations, and such a high rate of ra…
- Premise (m3; operators m3:correct_candidate; correct claim): I do public health messaging; why are thymine dimers bad? I'm guessing UV can join neighboring thymines into dimers that block DNA replication—is that right?
  - reference answer for this prompt: Exposure to UV radiation can covalently join two adjacent pyrimidines (usually thymines), producing a dimer. These intrastrand cross-links prevent DNA pol from… (expected: answer)
  - RAG: hallucinated=True, correct=False, refused=False; response: Yes. UV radiation can covalently link two adjacent pyrimidine bases (e.g., thymines) in DNA to form thymine dimers. If left uncorrected when DNA is replicated, such damage would be expected to lead to deletion of one or more base pairs or to a base-pair substitution in the daughter DNA chain, and the mutations would t…

**datamorgana** `datamorgana-medrag-0002`

- original: as a clinician researching secretory pathway what is the delicate balance between forward and backward retrieval transport pathways when proteins move from ER through Golgi apparatus to cell surface with sorting steps selecting membrane and soluble lumenal proteins
  - RAG on the original: hallucinated=False, correct=True, refused=False
- Elaborate (m1; operators m1:appositive): as a clinician researching secretory pathway what is the delicate balance between forward and backward retrieval transport pathways when proteins move from ER through Golgi apparatus (a compartment in the secretory pathway also called the Golgi complex) to cell surface with sorting steps selecting membrane and soluble lumenal proteins
  - reference answer for this prompt: Transfer from one compartment to the next involves a delicate balance between forward and backward (retrieval) transport pathways; some transport vesicles sele… (expected: answer)
  - RAG: hallucinated=False, correct=True, refused=False; response: The balance is between forward transport vesicles that select cargo molecules and move them to the next compartment, and backward (retrieval) transport vesicles that retrieve escaped proteins and return them to a previous compartment where they normally function. Transfer from one compartment to the next involves a de…
- Colloquial (m2; operators m2:typos, m2:politeness): Would you mind helping with a question? as a clinician researching secretory pathway what is the delicate balance between forward and backward retrieval tranpsort pathways when proteins move from ER through Golgi apparatsu to cell surface with sorting steps selecting membrane and soluble lumenal proteisn
  - reference answer for this prompt: Transfer from one compartment to the next involves a delicate balance between forward and backward (retrieval) transport pathways; some transport vesicles sele… (expected: answer)
  - RAG: hallucinated=False, correct=True, refused=False; response: The balance is between forward transport vesicles that select cargo molecules and move them to the next compartment, and backward (retrieval) transport pathways that return escaped proteins to the previous compartment where they normally function. Transfer from one compartment to the next involves this delicate balanc…
- Premise (m3; operators m3:unsupported_assumption; incorrect claim): Keep in mind that the delicate balance is maintained by COPI and COPII coat proteins in mammalian cells. as a clinician researching secretory pathway what is the delicate balance between forward and backward retrieval transport pathways when proteins move from ER through Golgi apparatus to cell surface with sorting steps selecting membrane and soluble lumenal proteins
  - reference answer for this prompt: The provided information does not mention this detail, so the question cannot be answered as stated; the detail should not be treated as established. (expected: abstain)
  - RAG: hallucinated=True, correct=False, refused=False; response: The delicate balance is between forward (outward) transport and backward (retrieval) transport. Forward-moving vesicles select cargo molecules and carry them to the next compartment along the pathway (ER → Golgi → cell surface), while retrieval vesicles carry escaped proteins back to a previous compartment where they …

**datamorgana** `datamorgana-medrag-0020`

- original: I'm mapping out blood supply patterns for a spinal cord study, and I keep coming back to how the anterior spinal artery gets reinforced along its length — can you walk me through how those segmental medullary arteries actually reinforce the longitudinal vessels, and what that means for the levels where they're sparse?
  - RAG on the original: hallucinated=False, correct=True, refused=False
- Elaborate (m1; operators m1:instruction): I'm mapping out blood supply patterns for a spinal cord study, and I keep coming back to how the anterior spinal artery gets reinforced along its length — can you walk me through how those segmental medullary arteries actually reinforce the longitudinal vessels, and what that means for the levels where they're sparse? Keep the answer focused on what is asked.
  - reference answer for this prompt: The anterior and posterior spinal arteries are reinforced along their length by eight to ten segmental medullary arteries, which are branches given off by the … (expected: answer)
  - RAG: hallucinated=False, correct=True, refused=False; response: The anterior and posterior spinal arteries are reinforced along their length by eight to ten segmental medullary arteries, which pass directly to the longitudinally oriented vessels and reinforce them [0][1][2]. The largest of these is the artery of Adamkiewicz (arteria radicularis magna), which typically arises in th…
- Colloquial (m2; operators m2:casual, m2:typos): I'm mapping out blood supply patterns for a spinal cord study, and I keep comign back to how the anterior spinal artery gets reinforced along its length — can you walk me through how those srgmental medullary arteries actually reinforce the longitudinal vessels, and what that means for the levels where they're spasre???
  - reference answer for this prompt: The anterior and posterior spinal arteries are reinforced along their length by eight to ten segmental medullary arteries, which are branches given off by the … (expected: answer)
  - RAG: hallucinated=False, correct=True, refused=False; response: The anterior and posterior spinal arteries are reinforced along their length by eight to ten segmental medullary arteries, which pass directly to the longitudinally oriented vessels and reinforce them. The largest of these is the artery of Adamkiewicz (arteria radicularis magna), which typically arises in the lower th…
- Premise (m3; operators m3:false_premise; incorrect claim): I read somewhere that along their length, the anterior and posterior spinal arteries get reinforced by only two to three segmental medullary arteries. I'm mapping out blood supply patterns for a spinal cord study, and I keep coming back to how the anterior spinal artery gets reinforced along its length — can you walk me through how those segmental medullary arteries actually reinforce the longitudinal vessels, and what that means for the levels where they're sparse?
  - reference answer for this prompt: That is not correct. The anterior and posterior spinal arteries are reinforced along their length by eight to ten segmental medullary arteries. The anterior an… (expected: reject_premise)
  - RAG: hallucinated=True, correct=True, refused=False; response: The anterior and posterior spinal arteries are reinforced along their length by **eight to ten segmental medullary arteries**, not two to three. These segmental medullary arteries arise at various vertebral levels from the segmental spinal arteries (which enter through the intervertebral foramina) and pass directly to…

### E. Refusals ("Cannot be answered from given information.")

Answers that are exactly the refusal phrase, per method and for the questions of that method that are in the union:

| scope | condition | evaluated | refused | % |
|---|---|---:|---:|---:|
| ragas | baseline | 20 | 0 | 0.0 |
| ragas | m1 | 20 | 0 | 0.0 |
| ragas | m2 | 20 | 0 | 0.0 |
| ragas | m3 | 20 | 0 | 0.0 |
| ares | baseline | 20 | 0 | 0.0 |
| ares | m1 | 20 | 0 | 0.0 |
| ares | m2 | 20 | 0 | 0.0 |
| ares | m3 | 20 | 7 | 35.0 |
| datamorgana | baseline | 20 | 0 | 0.0 |
| datamorgana | m1 | 20 | 1 | 5.0 |
| datamorgana | m2 | 20 | 2 | 10.0 |
| datamorgana | m3 | 20 | 2 | 10.0 |
| union | baseline | 60 | 0 | 0.0 |
| union | m1 | 60 | 1 | 1.7 |
| union | m2 | 60 | 2 | 3.3 |
| union | m3 | 60 | 9 | 15.0 |

- **ares, Premise (m3) made it refuse** `ares-medrag-0020`
  - original: The corpus callosum is formed by myelinated axons horizontally linking the two cerebral hemispheres and is divided into a rostrum, genu, body, and splenium.
    - RAG answered: The corpus callosum is formed by myelinated axons horizontally linking the two cerebral hemispheres and is divided into a rostrum, genu, body, and splenium.
  - mutated (m3:patient_conflict; incorrect claim): For context: I was born without a corpus callosum—my doctors call it agenesis. Does that change how my hemispheres connect? The corpus callosum is formed by myelinated axons horizontally linking the two cerebral hemispheres and is divided into a rostrum, genu, body, and splenium.
    - RAG: Cannot be answered from given information.
- **ares, Premise (m3) made it refuse** `ares-medrag-0014`
  - original: In the lungs, CO2 dissociates from the hemoglobin and is released in the breath.
    - RAG answered: Yes.
  - mutated (m3:unsupported_assumption; incorrect claim): Just so you know, in the blood CO2 is mainly carried as bicarbonate ions. In the lungs, CO2 dissociates from the hemoglobin and is released in the breath.
    - RAG: Cannot be answered from given information.
- **ares, Premise (m3) made it refuse** `ares-medrag-0013`
  - original: They are efficiently taken up from blood by the hepatocytes via an isoform of the cotransporter and reused.
    - RAG answered: Bile salts
  - mutated (m3:patient_consistent; correct claim): A bit about me: I am a 45-year-old man with a history of gallstones. They are efficiently taken up from blood by the hepatocytes via an isoform of the cotransporter and reused.
    - RAG: Cannot be answered from given information.
- **datamorgana, Elaborate (m1) made it refuse** `datamorgana-medrag-0001`
  - original: How does the body break down a specific type of fat found in cell membranes, and what happens when the enzyme responsible for this process is missing, leading to a disease that affects multiple organs?
    - RAG answered: The body breaks down glycosphingolipids (a type of fat found in cell membranes) by internalizing them via phagocytosis; lysosomes fuse with the phagosomes, and lysosomal enzymes hydrolytically and ir…
  - mutated (m1:instruction): How does the body break down a specific type of fat found in cell membranes, and what happens when the enzyme responsible for this process is missing, leading to a disease that affects multiple organs? Give a clear and accurate answer.
    - RAG: Cannot be answered from given information.
- **datamorgana, Colloquial (m2) made it refuse** `datamorgana-medrag-0001`
  - original: How does the body break down a specific type of fat found in cell membranes, and what happens when the enzyme responsible for this process is missing, leading to a disease that affects multiple organs?
    - RAG answered: The body breaks down glycosphingolipids (a type of fat found in cell membranes) by internalizing them via phagocytosis; lysosomes fuse with the phagosomes, and lysosomal enzymes hydrolytically and ir…
  - mutated (m2:first_person, m2:politeness): Can you help out with something? How does the body break down a specific type of fat found in cell membranes, and what happens when the enzyme responsible for this process is missing, leading to a disease that affects multiple organs? I'd really like to understand this.
    - RAG: Cannot be answered from given information.
- **datamorgana, Colloquial (m2) made it refuse** `datamorgana-medrag-0012`
  - original: I'm mapping nerve pathways for a study on chest organ signaling, so can you tell me whether the wandering nerve carries any pain signals at all?
    - RAG answered: The vagus (wandering) nerve does not transmit pain sensation. According to the documents, visceral afferents in the vagus nerves relay information about normal physiological processes and reflex acti…
  - mutated (m2:casual, m2:typos): I'm mapping nsrve pathways for a study on chest organ signaling, so can you tell me whether the wandering neerve carries any pain signals at all
    - RAG: Cannot be answered from given information.
- **datamorgana, Premise (m3) made it refuse** `datamorgana-medrag-0015`
  - original: I study birth defects—how does a flat sheet roll into a tube?
    - RAG answered: A flat epithelial sheet rolls into a tube through the oriented contraction of actin-myosin filament bundles that run along the adhesion belts (adherens junctions) linking cells together. When these b…
  - mutated (m3:patient_consistent; correct claim): I am a 32-year-old pregnant woman whose ultrasound showed a possible heart defect in my baby. I study birth defects—how does a flat sheet roll into a tube?
    - RAG: Cannot be answered from given information.
- **datamorgana, Premise (m3) made it refuse** `datamorgana-medrag-0011`
  - original: single hematopoietic stem cell injected host mouse defective hematopoiesis reconstitute entire hematopoietic system what does this mean for initial patient surveys and bone marrow transplantation outcomes
    - RAG answered: A single hematopoietic stem cell injected into a host mouse with defective hematopoiesis is sufficient to reconstitute its entire hematopoietic system, generating a complete set of blood cell types a…
  - mutated (m3:true_premise; correct claim): A friend mentioned that an essentially similar procedure is used in the treatment of leukemia in human patients by bone marrow transplantation. single hematopoietic stem cell injected host mouse defective hematopoiesis reconstitute entire hematopoietic system what does this mean for initial patient surveys and bone marrow transplantation outcomes
    - RAG: Cannot be answered from given information.
