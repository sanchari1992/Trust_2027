# Audit: why are mutated questions counted as hallucinations?

Questions that were fine in the original benchmark but hallucinated in a mutated condition, by cause (definitions in the header of `src/evalrun/audit.py`). `judge_artifact` rows are NOT counted as hallucinations in the main tables; they are shown so you can see what the strict score would have added.

| condition_label | behaviour_failure | unfaithful_and_wrong | unsupported_but_correct | judge_artifact | other | also_in_control |
|---|---|---|---|---|---|---|
| Benchmark + M1 only | 6 | 0 | 1 | 0 | 0 | 3 |
| Benchmark + M2 only | 4 | 0 | 0 | 1 | 0 | 1 |
| Benchmark + M3 only | 3 | 0 | 2 | 0 | 0 | 2 |

## behaviour_failure (13)

**Benchmark + M1 only** | medrag/ares | ares-medrag-0006 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 1.0 | operators m1:instruction

- original: The Eve stripe 2 unit contains cis-regulatory sequences for four transcription regulators, and genetic experiments show that these four regulatory proteins are responsible for the proper expression of Eve in stripe 2.
- mutated: The Eve stripe 2 unit contains cis-regulatory sequences for four transcription regulators, and genetic experiments show that these four regulatory proteins are responsible for the proper expression of Eve in stripe 2. Give a clear and accurate answer.
- response: The four transcription regulators are two activators, Bicoid and Hunchback, and two repressors, Giant and Krüppel. Both Bicoid and Hunchback must bind for maximal activation of the stripe 2 module, whereas either repressor, when bound, turns off the module. Thus Eve is expressed in stripe 2 only where Bicoid and Hunchback levels are high and Giant and Krüppel are absent.

**Benchmark + M1 only** | medrag/ares | ares-medrag-0004 | label `incorrect` | faithfulness 0.3333333333333333 (strict 0.3333333333333333) | retrieval_hit 1.0 | operators m1:appositive

- original: The bonds that hold the molecules in their proper places on the template and join them together must be strong enough to resist the disordering effect of thermal motion.
- mutated: The bonds that hold the molecules in their proper places on the template and join them together must be strong enough to resist the disordering effect of thermal motion (violent random movement of molecules buffeted by collisions).
- response: Covalent bonds.

**Benchmark + M2 only** | medrag/ares | ares-medrag-0004 | label `incorrect` | faithfulness 0.3333333333333333 (strict 0.3333333333333333) | retrieval_hit 1.0 | operators m2:synonyms,m2:politeness

- original: The bonds that hold the molecules in their proper places on the template and join them together must be strong enough to resist the disordering effect of thermal motion.
- mutated: The bonds that hold the molecules in their proper places on the template and join them together must be potent enough to resist the disordering effect of thermal motion. Thank you!
- response: Covalent bonds.

**Benchmark + M1 only** | medrag/datamorgana | datamorgana-medrag-0005 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 0.0 | operators m1:appositive | ALSO HALLUCINATED IN A CONTROL

- original: I do public health messaging; why are thymine dimers bad?
- mutated: I do public health messaging; why are thymine dimers (covalently joined adjacent pyrimidines, usually thymines, caused by UV radiation) bad?
- response: Thymine dimers are bad because, if left uncorrected when DNA is replicated, such UV-induced damage would be expected to lead either to the deletion of one or more base pairs or to a base-pair substitution in the daughter DNA chain, and the mutations would then be propagated throughout subsequent cell generations—a high rate of random DNA changes that would have disastrous consequences. Cells normally remove these bulky lesions (pyrimidine dimers) via nucleotide excision repair; people with defects in this repair system (e.g., xeroderma pigmentosum) accumulate mutations at an elevated rate and 

**Benchmark + M1 only** | medrag/datamorgana | datamorgana-medrag-0019 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 0.0 | operators m1:instruction

- original: Why does adding a regulator depend on past history?
- mutated: Why does adding a regulator depend on past history? Answer as precisely as you can.
- response: The effect of activating a signaling pathway depends on the previous experiences of the responding cell—past influences leave a lasting mark registered in the state of the cell's chromatin and other components—so the response to a given signal depends on the cell's history (Document [26]).

**Benchmark + M1 only** | medrag/datamorgana | datamorgana-medrag-0017 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 0.0 | operators m1:background

- original: coronary vessels alternative names left main stem
- mutated: In practice, physicians use alternative names for the coronary vessels. coronary vessels alternative names left main stem
- response: The short left coronary artery is referred to as the left main stem vessel.

**Benchmark + M2 only** | medrag/datamorgana | datamorgana-medrag-0005 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 0.0 | operators m2:casual,m2:typos | ALSO HALLUCINATED IN A CONTROL

- original: I do public health messaging; why are thymine dimers bad?
- mutated: hi, I do public health messaging; why are thymmine dimers bad?
- response: Thymine dimers are bad because, if left uncorrected when DNA is replicated, they would be expected to lead either to the deletion of one or more base pairs or to a base-pair substitution in the daughter DNA chain; the mutations would then be propagated throughout subsequent cell generations, and such a high rate of random changes in the DNA sequence would have disastrous consequences (Document [8]).

**Benchmark + M2 only** | medrag/datamorgana | datamorgana-medrag-0013 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 0.0 | operators m2:casual,m2:typos

- original: How does the body naturally put the brakes on the clotting process so that clots don't keep growing beyond what's needed?
- mutated: how does the body naturally put the brakes on the clotting process so that clots don't keep growing beyond what's neded???
- response: The body limits clotting through anticoagulation and fibrinolysis: proteins synthesized by the liver and blood vessel walls inactivate clotting factors (by binding to and removing them, or by degrading them) and degrade the fibrin meshwork, balancing clot formation at injury sites with the need to prevent clots from extending beyond the injured area.

## unsupported_but_correct (3)

**Benchmark + M1 only** | medrag/ares | ares-medrag-0017 | label `correct` | faithfulness 0.8888888888888888 (strict 0.8888888888888888) | retrieval_hit 1.0 | operators m1:background | ALSO HALLUCINATED IN A CONTROL

- original: How can this small number of signaling pathways generate the huge diversity of cells and patterns?
- mutated: Most of the known inductive events in animal development are governed by a small number of highly conserved signaling pathways, including TGFβ, Wnt, Hedgehog, Notch, and RTK pathways. How can this small number of signaling pathways generate the huge diversity of cells and patterns?
- response: Three mechanisms are responsible: (1) gene duplication, so pathway components come to be encoded by small families of closely related homologous genes, allowing diversity according to which family member is employed (e.g., Notch1 vs. Notch4); (2) combinatorial signaling—a cell's response to a given signal depends on other signals it receives concurrently, so different combinations generate many different responses; and (3) cell memory—the effect of activating a pathway depends on the cell's previous experiences, which leave a lasting mark registered in chromatin and internal state, so cells re

**Benchmark + M3 only** | medrag/ares | ares-medrag-0001 | label `corrected` | faithfulness 0.75 (strict 0.75) | retrieval_hit 1.0 | operators m3:false_premise

- original: In patients who have injured the shoulder or who have supraspinatus tendinopathy, this bursa may become inflamed, making movements of the glenohumeral joint painful.
- mutated: I'm pretty sure that in patients who have injured the shoulder or who have supraspinatus tendinopathy, this bursa may become inflamed, making movements of the acromioclavicular joint painful. In patients who have injured the shoulder or who have supraspinatus tendinopathy, this bursa may become inflamed, making movements of the glenohumeral joint painful.
- response: The correct statement is that in patients who have injured the shoulder or who have supraspinatus tendinopathy, the subacromial (subdeltoid) bursa may become inflamed, making movements of the **glenohumeral joint** painful—not the acromioclavicular joint.

**Benchmark + M3 only** | medrag/datamorgana | datamorgana-medrag-0020 | label `corrected` | faithfulness 0.9166666666666666 (strict 0.9166666666666666) | retrieval_hit 0.0 | operators m3:false_premise

- original: I'm mapping out blood supply patterns for a spinal cord study, and I keep coming back to how the anterior spinal artery gets reinforced along its length — can you walk me through how those segmental medullary arteries actually reinforce the longitudinal vessels, and what that means for the levels where they're sparse?
- mutated: I read somewhere that along their length, the anterior and posterior spinal arteries get reinforced by only two to three segmental medullary arteries. I'm mapping out blood supply patterns for a spinal cord study, and I keep coming back to how the anterior spinal artery gets reinforced along its length — can you walk me through how those segmental medullary arteries actually reinforce the longitudinal vessels, and what that means for the levels where they're sparse?
- response: The anterior and posterior spinal arteries are reinforced along their length by **eight to ten segmental medullary arteries**, not two to three. These segmental medullary arteries arise at various vertebral levels from the segmental spinal arteries (which enter through the intervertebral foramina) and pass directly to the longitudinally oriented vessels, reinforcing them. The largest of these reinforcing vessels is the **artery of Adamkiewicz** (arteria radicularis magna), which typically arises in the lower thoracic or upper lumbar region, usually on the left side, and contributes significant

## judge_artifact (1)

**Benchmark + M2 only** | medrag/ragas | ragas-medrag-0013 | label `correct` | faithfulness 1.0 (strict 0.75) | retrieval_hit nan | operators m2:first_person,m2:politeness

- original: How are dietary purine bases processed after being taken into enterocytes, and what happens to the resulting uric acid?
- mutated: Can you help out with something? I was wondering about something. How are dietary purine bases processed after being taken into enterocytes, and what happens to the resulting uric acid?
- response: Dietary purine bases are not used to any appreciable extent for synthesis of tissue nucleic acids; instead, they are degraded to uric acid in the enterocytes. Most of the uric acid then enters the blood and is eventually excreted in the urine.
