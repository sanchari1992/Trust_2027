# Benchmark vs Benchmark+ : hallucination results

Profile: `paper`. Faithfulness threshold: 1.0. All mutated results are compared with the original benchmark question by question (paired).

## All RAGs and methods pooled

| condition | n | hallucination_rate | hall_ci_low | hall_ci_high | failure_rate | unfaithful_rate | unsupported_but_correct_rate | unfaithful_and_wrong_rate | retrieval_hit_rate | abstain_rate | mean_faithfulness |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Benchmark (unchanged) | 1500 | 0.116 | 0.101 | 0.133 | 0.147 | 0.043 | 0.035 | 0.007 | 0.591 | 0.066 | 0.986 |
| Benchmark + M2 only | 1500 | 0.111 | 0.096 | 0.128 | 0.186 | 0.059 | 0.041 | 0.017 | 0.539 | 0.117 | 0.984 |
| Benchmark + M3 only | 1500 | 0.173 | 0.155 | 0.193 | 0.195 | 0.067 | 0.050 | 0.017 | 0.569 | 0.072 | 0.976 |

## Paired change in hallucination rate vs the original benchmark (pooled)

`diff` is condition minus baseline with a 95% paired-bootstrap interval; `newly_failing` = questions the RAG handled in the benchmark but hallucinated on in the mutated version; `newly_passing` = the reverse; `q_value` = McNemar exact test, Benjamini-Hochberg corrected.

| condition | n_pairs | baseline_rate | condition_rate | diff | diff_ci_low | diff_ci_high | newly_failing | newly_passing | q_value |
|---|---|---|---|---|---|---|---|---|---|
| Benchmark + M2 only | 1500 | 0.116 | 0.111 | -0.005 | -0.023 | 0.012 | 87 | 95 | 0.755 |
| Benchmark + M3 only | 1500 | 0.116 | 0.173 | 0.057 | 0.034 | 0.081 | 211 | 125 | 0.000 |

## Hallucinations found: benchmark alone vs benchmark + mutations

A question counts as a hallucination found by the mutations if it was fine in the original benchmark but a mutated version made the RAG hallucinate.

| level | rag | n_questions | found_by_benchmark | found_by_benchmark_plus_mutations | extra_found_by_mutations | extra_found_by_controls | extra_found_by_mutations_beyond_controls | benchmark_rate | union_rate | fold_increase |
|---|---|---|---|---|---|---|---|---|---|---|
| rag | medrag | 1500 | 174 | 448 | 274 |  |  | 0.116 | 0.299 | 2.575 |
| overall | ALL | 1500 | 174 | 448 | 274 |  |  | 0.116 | 0.299 | 2.575 |

`extra_found_by_controls`: the same count for the control conditions (no useful change: a re-run, and filler padding). `extra_found_by_mutations_beyond_controls`: questions that only a mutation exposed, that neither control did. Only this last column is evidence that the mutations themselves help.

## The same change measured two other ways (pooled)

`wrong_behavior`: only answers that assert something wrong or adopt a false / unsupported claim (no faithfulness involved). `hallucinated_strict`: unfaithfulness against the retrieved context ALONE, i.e. a statement repeating what the user said is not accepted as supported. If a mutation shows a change in `hallucinated` but not in these, check it with scripts/audit_hallucinations.py.

| metric | condition | n_pairs | baseline_rate | condition_rate | diff | diff_ci_low | diff_ci_high | newly_failing | newly_passing | q_value |
|---|---|---|---|---|---|---|---|---|---|---|
| wrong_behavior | Benchmark + M2 only | 1500 | 0.081 | 0.069 | -0.011 | -0.025 | 0.003 | 49 | 66 | 0.150 |
| wrong_behavior | Benchmark + M3 only | 1500 | 0.081 | 0.123 | 0.043 | 0.023 | 0.063 | 159 | 95 | 0.000 |
| hallucinated_strict | Benchmark + M2 only | 1500 | 0.140 | 0.144 | 0.004 | -0.017 | 0.025 | 120 | 114 | 0.796 |
| hallucinated_strict | Benchmark + M3 only | 1500 | 0.140 | 0.211 | 0.071 | 0.047 | 0.097 | 246 | 140 | 0.000 |
| unsupported_but_correct | Benchmark + M2 only | 1500 | 0.035 | 0.041 | 0.006 | -0.005 | 0.018 | 48 | 39 | 0.435 |
| unsupported_but_correct | Benchmark + M3 only | 1500 | 0.035 | 0.050 | 0.015 | 0.000 | 0.029 | 68 | 46 | 0.107 |
| unfaithful_and_wrong | Benchmark + M2 only | 1500 | 0.007 | 0.017 | 0.010 | 0.003 | 0.017 | 22 | 7 | 0.041 |
| unfaithful_and_wrong | Benchmark + M3 only | 1500 | 0.007 | 0.017 | 0.009 | 0.002 | 0.017 | 25 | 11 | 0.072 |

## Retrieval: do mutated prompts retrieve the original source passage?

`retrieval_hit_rate`: share of answers whose retrieved passages include an original source passage of the question. `hallucination_rate_when_miss` vs `_when_hit`: whether hallucination goes with a retrieval miss. If a condition retrieves worse, its extra hallucinations are a retrieval effect (the query got diluted), not the model being fooled.

| condition | n | retrieval_hit_rate | mean_gold_recall | hallucination_rate_when_hit | hallucination_rate_when_miss | n_miss |
|---|---|---|---|---|---|---|
| Benchmark (unchanged) | 1500 | 0.591 | 0.591 | 0.106 | 0.131 | 613 |
| Benchmark + M2 only | 1500 | 0.539 | 0.539 | 0.079 | 0.148 | 691 |
| Benchmark + M3 only | 1500 | 0.569 | 0.569 | 0.156 | 0.197 | 646 |

## Hallucination rate per RAG and method

| rag | method | baseline | m2 | m3 |
|---|---|---|---|---|
| medrag | ares | 0.144 | 0.108 | 0.136 |
| medrag | datamorgana | 0.130 | 0.136 | 0.178 |
| medrag | ragas | 0.074 | 0.088 | 0.206 |

## By operator (hallucination rate; a question with two operators counts for both)

| condition | operator | n | hallucination_rate | baseline_rate_same_questions | failure_rate | mean_faithfulness |
|---|---|---|---|---|---|---|
| m2 | m2:casual | 669 | 0.105 | 0.114 | 0.176 | 0.989 |
| m2 | m2:first_person | 526 | 0.110 | 0.112 | 0.158 | 0.979 |
| m2 | m2:imperative | 336 | 0.089 | 0.083 | 0.170 | 0.987 |
| m2 | m2:politeness | 427 | 0.126 | 0.122 | 0.230 | 0.981 |
| m2 | m2:synonyms | 276 | 0.116 | 0.116 | 0.188 | 0.985 |
| m2 | m2:typos | 766 | 0.115 | 0.132 | 0.196 | 0.985 |
| m3 | m3:correct_candidate | 238 | 0.067 | 0.147 | 0.042 | 0.975 |
| m3 | m3:false_premise | 191 | 0.052 | 0.136 | 0.110 | 0.986 |
| m3 | m3:patient_conflict | 152 | 0.763 | 0.099 | 0.763 | 0.972 |
| m3 | m3:patient_consistent | 312 | 0.122 | 0.071 | 0.173 | 0.979 |
| m3 | m3:true_premise | 234 | 0.115 | 0.162 | 0.094 | 0.980 |
| m3 | m3:unsupported_assumption | 183 | 0.197 | 0.098 | 0.142 | 0.955 |
| m3 | m3:wrong_candidate | 190 | 0.089 | 0.105 | 0.232 | 0.982 |

## Mutation 3 (user information) by kind and operator

| condition | kind | m3_operator | n | hallucination_rate | failure_rate | unfaithful_rate | refusal_rate |
|---|---|---|---|---|---|---|---|
| m3 | correct | m3:correct_candidate | 238 | 0.067 | 0.042 | 0.055 | 0.017 |
| m3 | correct | m3:patient_consistent | 312 | 0.122 | 0.173 | 0.061 | 0.090 |
| m3 | correct | m3:true_premise | 234 | 0.115 | 0.094 | 0.073 | 0.043 |
| m3 | incorrect | m3:false_premise | 191 | 0.052 | 0.110 | 0.052 | 0.110 |
| m3 | incorrect | m3:patient_conflict | 152 | 0.763 | 0.763 | 0.066 | 0.211 |
| m3 | incorrect | m3:unsupported_assumption | 183 | 0.197 | 0.142 | 0.087 | 0.191 |
| m3 | incorrect | m3:wrong_candidate | 190 | 0.089 | 0.232 | 0.079 | 0.211 |
