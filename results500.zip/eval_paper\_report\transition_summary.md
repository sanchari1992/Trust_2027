# Which mutation exposes failures, which fixes some, which is consistent?

Figures: `transitions_<outcome>.png` / `.pdf` (A: newly failing vs fixed per mutation and control; B: overlap of the newly failing questions; C: how many of the three mutations break a question).
