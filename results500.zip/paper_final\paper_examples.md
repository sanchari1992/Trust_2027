# Examples for the paper

## medrag

### A. Simple benchmark queries (one method each)

- **ragas** `ragas-medrag-0052`: What are the two layers of the dura mater, and how do they differ in their attachments and functions?
  - reference answer: The dura mater is composed of two layers: the outer periosteal layer, which is adherent to the skull, and the inner meningeal layer, which lies against the underlying arachnoid mater. Although closely adherent to one another, they separate in some regions to …
- **ragas** `ragas-medrag-0164`: What is the classic manifestation of an acute gout attack, and which joint is most commonly affected in pseudogout?
  - reference answer: The classic manifestation of an acute gout attack is a painful MTP joint of the big toe (podagra). In pseudogout, the most commonly affected joint is the knee.
- **ragas** `ragas-medrag-0176`: What are the treatments for hyperthyroidism if it is not cured, and what are the common causes of hyperthyroidism?
  - reference answer: Based on the context: **Treatments if not cured:** octreotide (somatostatin analog), pegvisomant (GH receptor antagonist), or dopamine agonists (eg, cabergoline). **Common causes of hyperthyroidism:** Graves disease is the most common cause of hyperthyroidism…
- **ares** `ares-medrag-0417`: In multicellular organisms, how can hormones cause coordinated regulation of genes located on different chromosomes?
  - reference answer: Hormones can cause coordinated regulation either through the binding of the hormone receptor–hormone complex to the DNA (as with steroid hormones) or through the binding of a protein that is activated in response to a second messenger (as with glucagon).
- **ares** `ares-medrag-0048`: The affinity of ATIII for FIIA is greatly increased when ATIII is bound to heparin.
  - reference answer: The affinity of antithrombin III (ATIII) for factor IIa (FIIA) is greatly increased when ATIII is bound to heparin.
- **ares** `ares-medrag-0408`: ↑ CA-125 (> 35 units) indicates an ↑ likelihood that the ovarian tumor is malignant.
  - reference answer: Premenopausal women: ↑ CA-125 may point to benign disease such as endometriosis. Postmenopausal women: ↑ CA-125 (> 35 units) indicates an ↑ likelihood that the ovarian tumor is malignant.
- **datamorgana** `datamorgana-medrag-0315`: when do neuropores fail to fuse in neural tube defects week
  - reference answer: 4th week
- **datamorgana** `datamorgana-medrag-0244`: How many eggs seen on ultrasound signal a poor IVF response?
  - reference answer: Fewer than 4.
- **datamorgana** `datamorgana-medrag-0275`: I coordinate emergency messaging—what happens to the hip in avascular necrosis?
  - reference answer: Avascular necrosis causes loss of height of the femoral head, juxta-articular bony sclerosis, and subchondral cyst formation; supporting hip muscles may also waste from disuse and pain, while the opposite hip can remain normal.

### B. Realistic queries (real users)

- What is the proper dosage for L-acetyl Cysteine and why would I take it?
- Please make a research and suggest the list of potential herbs or probiotics that may potentially inhibit e coli klebsiella pneumoniae in gut microbiome. If possible, please include the references.
- provide me the complete pathophysiology of lung cancers

### C. Named entities and graph templates

**benchmark** `datamorgana-medrag-0419`: INSIG sterols SCAP SREBP-2 retention SER downregulation

- entities: INSIG <ORG>, SCAP SREBP-2 retention SER downregulation <CONCEPT>
- text template: `{ORG} sterols {CONCEPT}`
- graph template (`74679b83ca`): `VERB[compound>ENT:ORG,dobj>NOUN[compound>NOUN[compound>NOUN[compound>PROPN],compound>PROPN]]]`
- shape: `OTHER|S1|N7-10|D4+|E1`
- reference answer: When sterols are abundant, they bind SCAP at its sterol-sensing domain and induce binding of SCAP to INSIG proteins, causing retention of the SCAP–SREBP complex in the SER, preventing SREBP-2 activat…
- answer entities: sterols <CONCEPT>, SCAP <CONCEPT>, sterol-sensing domain <CONCEPT>, binding <CONCEPT>, SCAP <CONCEPT>, INSIG <ORG>, retention <CONCEPT>, SCAP <CONCEPT>
- answer template (first sentence): `WH:when ; VERB[acomp>ADJ,conj>VERB[advcl>VERB[advcl>VERB[conj>VERB[dobj>NOUN[compound>NOUN]],dobj>NOUN[compound>PROPN]],dobj>NOUN[pobj>PROPN[appos>NOUN[compound>PROPN,pobj>ENT:ORG]]]],dobj>NOUN[pobj>PROPN],pobj>NOUN[compound>ENT:ORG]],dobj>PROPN,nsubj>NOUN,pobj>NOUN[amod>VERB[npadvmod>NOUN]]]`; shape `when|S1|N11+|D4+|E2`

```
`-- sterol (VERB)
    |-- [compound] insig <ORG>
    `-- [dobj] downregulation (NOUN)
        `-- [compound] ser (NOUN)
            |-- [compound] scap (PROPN)
            `-- [compound] retention (NOUN)
                `-- [compound] srebp-2 (PROPN)
```

**benchmark** `ragas-medrag-0315`: What are the three categories into which potentially premalignant squamous lesions fall according to the Bethesda III System (2001)?

- entities: three <CARDINAL>, potentially premalignant squamous lesions <CONCEPT>, the Bethesda III System <ORG>, 2001 <DATE>
- text template: `What are the {CARDINAL} categories into which {CONCEPT} fall according to {ORG} ({DATE})?`
- graph template (`0005ae1765`): `WH:what ; NOUN[relcl>VERB[nsubj>NOUN[amod>ADJ,amod>ADJ[advmod>ADV]],prep>VERB[pobj>ENT:ORG]]]`
- shape: `what|S1|N7-10|D4+|E3+`
- reference answer: According to the Bethesda III System (2001), potentially premalignant squamous lesions fall into three categories: (i) atypical squamous cells (ASC), (ii) low-grade squamous intraepithelial lesions (…
- answer entities: the Bethesda III System <ORG>, 2001 <DATE>, potentially premalignant squamous lesions <CONCEPT>, three <CARDINAL>, i) atypical squamous cells <CONCEPT>, ASC <CONCEPT>, low-grade squamous intraepithelial lesions <CONCEPT>, LSIL <PERSON>
- answer template (first sentence): `VERB[nsubj>NOUN[amod>ADJ,amod>ADJ[advmod>ADV]],pobj>NOUN[appos>NOUN[amod>ADJ[amod>ADJ],appos>NOUN[amod>ADJ,amod>ADJ,appos>ENT:PERSON,nmod>NOUN[amod>ADJ]],appos>PROPN,conj>NOUN[amod>ADJ,amod>ADJ,appos>ENT:ORG,nmod>NOUN[amod>ADJ],nmod>PROPN],intj>PROPN]],prep>VERB[pobj>ENT:ORG]]`; shape `VERB|S1|N11+|D4+|E3+`

```
`-- category (NOUN)
    `-- [relcl] fall (VERB)
        |-- [nsubj] lesion (NOUN)
        |   |-- [amod] premalignant (ADJ)
        |   |   `-- [advmod] potentially (ADV)
        |   `-- [amod] squamous (ADJ)
        `-- [prep] accord (VERB)
            `-- [pobj] system <ORG>
```

**benchmark** `ares-medrag-0388`: The binding of EF-G to the ribosome and GTP hydrolysis move the mRNA three nucleotides through the ribosome.

- entities: binding <CONCEPT>, EF-G <CONCEPT>, GTP <ORG>, mRNA <CONCEPT>, three <CARDINAL>
- text template: `The {CONCEPT} of {CONCEPT} to the ribosome and {ORG} hydrolysis move the {CONCEPT} {CARDINAL} nucleotides through the ribosome.`
- graph template (`a24aa51065`): `ADJ | NOUN[appos>NOUN] | NOUN[pobj>NOUN[amod>ADJ[conj>ENT:ORG]],pobj>PROPN[compound>PROPN]]`
- shape: `OTHER|S1|N7-10|D3|E2`
- reference answer: The binding of EF-G to the ribosome and the subsequent hydrolysis of GTP lead to a rearrangement of the ribosome structure, moving the mRNA being decoded exactly three nucleotides through it.
- answer entities: binding <CONCEPT>, EF-G <CONCEPT>, subsequent hydrolysis <CONCEPT>, GTP <ORG>, rearrangement <CONCEPT>, ribosome structure <CONCEPT>, mRNA <CONCEPT>, three <CARDINAL>
- answer template (first sentence): `NOUN[acl>VERB[dobj>NOUN,xcomp>VERB[dobj>NOUN[advmod>ADV]]],conj>NOUN[amod>ADJ,pobj>NOUN[amod>ENT:ORG,pobj>NOUN[pobj>NOUN[amod>ADJ]]]],pobj>ADJ,pobj>PROPN[compound>PROPN]]`; shape `OTHER|S1|N11+|D4+|E2`

```
|-- binding (NOUN)
|   |-- [pobj] g (PROPN)
|   |   `-- [compound] ef (PROPN)
|   `-- [pobj] hydrolysis (NOUN)
|       `-- [amod] ribosome (ADJ)
|           `-- [conj] gtp <ORG>
|-- mrna (NOUN)
|   `-- [appos] nucleotide (NOUN)
`-- ribosome (ADJ)
```

**real** `real-medical-lmsys-3a8f6e4b4c104479ae217fac6a29b58a`: What is the proper dosage for L-acetyl Cysteine and why would I take it?

- entities: proper dosage <CONCEPT>, Cysteine <PERSON>
- text template: `What is the {CONCEPT} for L-acetyl {PERSON} and why would I take it?`
- graph template (`33bfe0ede8`): `WH:what ; NOUN[amod>ADJ,pobj>ENT:PERSON[compound>NOUN[compound>NOUN]]]`
- shape: `what|S1|N4-6|D3|E1`

```
`-- dosage (NOUN)
    |-- [amod] proper (ADJ)
    `-- [pobj] cysteine <PERSON>
        `-- [compound] acetyl (NOUN)
            `-- [compound] l (NOUN)
```

### D. Mutated queries

### E. Refusals ("Cannot be answered from given information.")

Answers that are exactly the refusal phrase, per method and for the questions of that method that are in the union:

| scope | condition | evaluated | refused | % |
|---|---|---:|---:|---:|
| ragas | baseline | 500 | 10 | 2.0 |
| ragas | m2 | 500 | 30 | 6.0 |
| ragas | m3 | 500 | 21 | 4.2 |
| ares | baseline | 500 | 31 | 6.2 |
| ares | m2 | 500 | 42 | 8.4 |
| ares | m3 | 500 | 72 | 14.4 |
| datamorgana | baseline | 500 | 53 | 10.6 |
| datamorgana | m2 | 500 | 94 | 18.8 |
| datamorgana | m3 | 500 | 77 | 15.4 |
| union | baseline | 1498 | 94 | 6.3 |
| union | m2 | 1498 | 166 | 11.1 |
| union | m3 | 1498 | 170 | 11.3 |

- **ragas, original question refused** `ragas-medrag-0264`: What are the key characteristics of a good screening test, and why is treatment after screening considered more effective than treatment without screening?
  - reference answer: A good screening test has high sensitivity and specificity, a high PPV, and is inexpensive, easy to administer, and safe. Treatment after screening is considered more effective than treatment without…; RAG: Cannot be answered from given information.
- **ragas, original question refused** `ragas-medrag-0355`: What is the price and publication year of "BRS Biochemistry, Molecular Biology, and Genetics" by Lieberman?
  - reference answer: The price is $54 and the publication year is 2013.; RAG: Cannot be answered from given information.
- **ragas, original question refused** `ragas-medrag-0357`: What should be done if no free fluid is present when staging ovarian malignancy, and how is this procedure performed?
  - reference answer: If no free fluid is present, peritoneal washings should be performed by instilling and recovering 50 to 100 mL of saline from the pelvic cul-de-sac, each paracolic gutter, and beneath each hemidiaphr…; RAG: Cannot be answered from given information.
- **ragas, Colloquial (m2) made it refuse** `ragas-medrag-0037`
  - original: What are the four types of noncovalent forces that govern the folding of proteins and RNAs and the binding of other molecules to macromolecules?
    - RAG answered: The four types are electrostatic attractions, hydrogen bonds, van der Waals attractions, and the hydrophobic force (hydrophobic interactions/clustering of nonpolar groups expelled from water).
  - mutated (m2:first_person, m2:imperative): I have a quick question. Explain what are the four types of noncovalent forces that govern the folding of proteins and RNAs and the binding of other molecules to macromolecules.
    - RAG: Cannot be answered from given information.
- **ragas, Colloquial (m2) made it refuse** `ragas-medrag-0481`
  - original: How is the diameter of the laryngeal airway increased during breathing?
    - RAG answered: During forced inspiration, the arytenoid cartilages are rotated laterally (mainly by the posterior crico-arytenoid muscles), abducting the vocal folds and widening the rima glottidis into a rhomboid …
  - mutated (m2:casual, m2:politeness): ok so how's the diameter of the laryngeal airway increased during breathing? Please let me know. Thanks!
    - RAG: Cannot be answered from given information.
- **ragas, Colloquial (m2) made it refuse** `ragas-medrag-0124`
  - original: What did the randomized controlled trial comparing an artificial sphincter with supportive care find regarding continence scores and quality-of-life measures at 6 months follow-up?
    - RAG answered: Significant improvements in continence scores and quality-of-life measures were seen in the artificial sphincter group but not in the control group at 6 months follow-up.
  - mutated (m2:typos, m2:politeness): Could you help with a question? What did the randimized controlled trial comparing an artificial sphincter with supportive care find regarding continence scores and quality-of-life measures at 6 months folllw-up?
    - RAG: Cannot be answered from given information.
- **ragas, Premise (m3) made it refuse** `ragas-medrag-0312`
  - original: What are the three levels of prevention described, and what does each focus on?
    - RAG answered: The three levels of prevention are: 1. **Primary (1°) prevention:** Includes measures to decrease the incidence of disease (e.g., a woman reduces dietary fat or alcohol intake to reduce her risk of d…
  - mutated (m3:patient_consistent; correct claim): For context: I am a 45-year-old man with a family history of heart disease. What are the three levels of prevention described, and what does each focus on?
    - RAG: Cannot be answered from given information.
- **ragas, Premise (m3) made it refuse** `ragas-medrag-0289`
  - original: How much does a subscription to UWorld's Qbank cost?
    - RAG answered: $249–$749
  - mutated (m3:wrong_candidate; incorrect claim): How much does a subscription to UWorld's Qbank cost? Is it true that a subscription to UWorld's Qbank costs $59–$179?
    - RAG: Cannot be answered from given information.
- **ragas, Premise (m3) made it refuse** `ragas-medrag-0319`
  - original: What is the underlying cause of bleeding into the ventricles in premature and low-birth-weight infants, and what symptoms can it present with?
    - RAG answered: Bleeding into the ventricles originates in the germinal matrix, a highly vascularized layer within the subventricular zone, due to reduced glial fiber support and impaired autoregulation of blood pre…
  - mutated (m3:patient_conflict; incorrect claim): Patient profile: I'm 68 with chronic hypertension and no premature birth history. What is the underlying cause of bleeding into the ventricles in premature and low-birth-weight infants, and what symptoms can it present with?
    - RAG: Cannot be answered from given information.
- **ares, original question refused** `ares-medrag-0443`: What is the treatment for penile squamous cell carcinoma in situ?
  - reference answer: Treat immediately with corporal aspiration, intracavernosal phenylephrine, or surgical decompression to prevent ischemia.; RAG: Cannot be answered from given information.
- **ares, original question refused** `ares-medrag-0032`: Both bones or more commonly a fracture of one bone and a dislocation of the other.
  - reference answer: Forearm injuries usually involve both bones, resulting in either fracture of both bones or more commonly a fracture of one bone and a dislocation of the other.; RAG: Cannot be answered from given information.
- **ares, original question refused** `ares-medrag-0410`: It will be present in the germline of the resulting animal and can be passed from generation to generation.
  - reference answer: If the gene randomly and stably integrates into a chromosome, it will be present in the germline of the resulting animal and can be passed from generation to generation.; RAG: Cannot be answered from given information.
- **ares, Colloquial (m2) made it refuse** `ares-medrag-0173`
  - original: What is the effect of hemin on ALAS1?
    - RAG answered: Hemin decreases the amount (and thus the activity) of ALAS1 by repressing transcription of its gene, increasing degradation of its messenger RNA, and decreasing import of the enzyme into mitochondria.
  - mutated (m2:typos, m2:politeness): Would you mind helping with a question? What is the effect of hrmin on ALAS1?
    - RAG: Cannot be answered from given information.
- **ares, Colloquial (m2) made it refuse** `ares-medrag-0258`
  - original: Stenotic (calcified) anterior interventricular (left anterior descending) artery.
    - RAG answered: Stenotic (calcified) anterior interventricular (left anterior descending) artery.
  - mutated (m2:typos, m2:politeness): Can you help out with something? Stenotic (calcified) anterior interventricular (left anteriro descending) artery.
    - RAG: Cannot be answered from given information.
- **ares, Colloquial (m2) made it refuse** `ares-medrag-0121`
  - original: **Why is the maternally derived gene immune to these effects?**
    - RAG answered: The maternally derived gene is immune because the specific methylation present from imprinting blocks the synthesis of the lncRNA but allows transcription of the protein-coding gene (Document [13]).
  - mutated (m2:first_person, m2:typos): I have a quick qusetion. **Why is the maternally derived gene immune to these effects?**
    - RAG: Cannot be answered from given information.
- **ares, Premise (m3) made it refuse** `ares-medrag-0400`
  - original: α-Agonists, which are often found in over-the-counter cold remedies, increase outlet resistance and may lead to voiding difficulty.
    - RAG answered: Yes, according to Document [0], α-agonists found in over-the-counter cold remedies increase outlet resistance and may lead to voiding difficulty.
  - mutated (m3:unsupported_assumption; incorrect claim): For context, I should say that α-agonists were first approved by the FDA in 1993. α-Agonists, which are often found in over-the-counter cold remedies, increase outlet resistance and may lead to voiding difficulty.
    - RAG: Cannot be answered from given information.
- **ares, Premise (m3) made it refuse** `ares-medrag-0498`
  - original: What are the boundaries of the posterior triangle of the neck?
    - RAG answered: The posterior triangle of the neck is bounded anteriorly by the posterior border of the sternocleidomastoid muscle, posteriorly by the anterior border of the trapezius muscle, and basally (inferiorly…
  - mutated (m3:patient_consistent; correct claim): A bit about me: I am a 45-year-old man with a history of tension headaches. What are the boundaries of the posterior triangle of the neck?
    - RAG: Cannot be answered from given information.
- **ares, Premise (m3) made it refuse** `ares-medrag-0138`
  - original: The image shows an oblique fracture of the middle third of the right clavicle.
    - RAG answered: The image shows an oblique fracture of the middle third of the right clavicle.
  - mutated (m3:true_premise; correct claim): A friend said Fig. 7.31 shows radiographs of acromioclavicular joints. The image shows an oblique fracture of the middle third of the right clavicle.
    - RAG: Cannot be answered from given information.
- **datamorgana, original question refused** `datamorgana-medrag-0116`: How do those tiny proteins grab onto our genetic material?
  - reference answer: They are positively charged due to high lysine and arginine content, so they form ionic bonds with negatively charged DNA.; RAG: Cannot be answered from given information.
- **datamorgana, original question refused** `datamorgana-medrag-0252`: public health guidance opposing hormone blood glucose regulation
  - reference answer: Glucagon, along with epinephrine, norepinephrine, cortisol, and growth hormone (counterregulatory hormones), opposes many insulin actions, mainly maintaining blood glucose via hepatic glycogenolysis …; RAG: Cannot be answered from given information.
- **datamorgana, original question refused** `datamorgana-medrag-0239`: health authority deep brain structure near fluid filled cavities anatomy overview
  - reference answer: The thalamus sits deep in the brain near the interventricular foramen, the third ventricle, the body of the lateral ventricle, the posterior limb of the internal capsule, and the midbrain; it also fo…; RAG: Cannot be answered from given information.
- **datamorgana, Colloquial (m2) made it refuse** `datamorgana-medrag-0162`
  - original: as a physician managing postoperative atelectasis what maneuvers promote maximal inspiratory pressure to expand alveoli and increase FRC
    - RAG answered: Therapy for atelectasis should be aimed at expanding the alveoli and increasing the FRC. The most important maneuvers are those that promote maximal inspiratory pressure, maintained for as long as po…
  - mutated (m2:first_person, m2:politeness): as a physician managing postoperative atelectasis what maneuvers promote maximal inspiratory pressure to expand alveoli and increase FRC I'd really like to understand this. Please let me know. Thanks!
    - RAG: Cannot be answered from given information.
- **datamorgana, Colloquial (m2) made it refuse** `datamorgana-medrag-0078`
  - original: I brief officials—what marks this disseminated infection in AIDS?
    - RAG answered: Disseminated M. avium infection in AIDS is marked by fever, weakness, and weight loss in patients who are not on HAART or chemoprophylaxis for MAC; hepatosplenomegaly and lymphadenopathy are occasion…
  - mutated (m2:casual, m2:typos): I brief officials—what marks this disseminated inefction in AIDS
    - RAG: Cannot be answered from given information.
- **datamorgana, Colloquial (m2) made it refuse** `datamorgana-medrag-0436`
  - original: low calorie high fat diet ACC synthesis
    - RAG answered: A low-calorie or high-fat, low-carbohydrate diet decreases ACC synthesis (opposite effect of excess-calorie, high-carbohydrate diets).
  - mutated (m2:typos, m2:politeness): Could you help with a question? low calorie high fat diet ACC syynthesis
    - RAG: Cannot be answered from given information.
- **datamorgana, Premise (m3) made it refuse** `datamorgana-medrag-0140`
  - original: What opens into the oral part of the pharynx?
    - RAG answered: The oropharyngeal isthmus opens into the oral part of the pharynx.
  - mutated (m3:wrong_candidate; incorrect claim): What opens into the oral part of the pharynx? So the oral vestibule opens into the oral part of the pharynx, right? Is that correct?
    - RAG: Cannot be answered from given information.
- **datamorgana, Premise (m3) made it refuse** `datamorgana-medrag-0219`
  - original: acs guideline early detection cervical neoplasia and cancer recommendations
    - RAG answered: Based on the documents, the American Cancer Society guideline for the early detection of cervical neoplasia and cancer is referenced (Document [0], citation 61: Saslow D, Runowicz CD, Solomon D, et a…
  - mutated (m3:wrong_candidate; incorrect claim): acs guideline early detection cervical neoplasia and cancer recommendations Did the American Cancer Society really put out a guideline for late detection of cervical neoplasia and cancer? Just want to confirm that's right?
    - RAG: Cannot be answered from given information.
- **datamorgana, Premise (m3) made it refuse** `datamorgana-medrag-0494`
  - original: which ape shares most genetic code with people
    - RAG answered: The chimpanzee shares the most genetic code with people.
  - mutated (m3:unsupported_assumption; incorrect claim): Just so you know, bonobos actually share more genetic code with humans than chimpanzees do. which ape shares most genetic code with people
    - RAG: Cannot be answered from given information.
