# Judge agreement: llm:gpt-6-luna (under test)  vs  llm:deepseek-flash (reference)

181 answers judged twice (refusals excluded: both judges skip them). Disagreements: `label_disagreements.csv`.

| behaviour | n | label agreement | Cohen's kappa |
|---|---|---|---|
| abstain | 12 | 1.000 | 1.000 |
| answer | 154 | 0.981 | 0.833 |
| reject_premise | 15 | 1.000 | 1.000 |
| ALL | 181 | 0.983 | 0.953 |

Faithfulness not compared: the contexts were not stored. Rerun the evaluate step with `evaluation.store_contexts: true`.

Confusion (rows: reference judge, columns: judge under test):

- answer: abstained->abstained: 1, correct->correct: 143, correct->incorrect: 3, incorrect->incorrect: 7
- reject_premise: consistent->consistent: 1, corrected->corrected: 14
- abstain: accepted_detail->accepted_detail: 2, answered_core->answered_core: 10
