# Benchmark before vs after mutation

Every number compares the SAME questions: the original benchmark question and its mutated version. `*` marks a change whose 95% paired-bootstrap interval excludes 0 (intervals are in `before_after_deltas.csv`). `pp` = percentage points.

**Accuracy** = share of answers judged correct. For mutations 3 and 1+2+3 the correct behaviour can be to reject a false claim or flag an unsupported detail, so `accuracy (answer items)` restricts to questions whose correct behaviour is to answer; that column is comparable with the baseline. **Hallucination** = unfaithful answer or an answer that asserts a wrong / adopted-false claim (declining to answer is not counted).

## 1. Accuracy and hallucination, all RAGs and methods pooled

| condition | n | accuracy | Δ accuracy | accuracy (answer items) | hallucination | Δ hallucination | unfaithful | abstained | refused | mean faithfulness |
|---|---|---|---|---|---|---|---|---|---|---|
| Benchmark (unchanged) | 1500 | 85.3% |  | 85.3% | 11.6% |  | 4.3% | 6.6% | 6.3% | 0.986 |
| Benchmark + M2 only | 1500 | 81.4% | -3.9 pp* | 81.4% | 11.1% | -0.5 pp | 5.9% | 11.7% | 11.1% | 0.984 |
| Benchmark + M3 only | 1500 | 80.5% | -4.9 pp* | 89.0% | 17.3% | +5.7 pp* | 6.7% | 7.2% | 11.3% | 0.976 |

## 2a. Accuracy per RAG and method

| rag | method | Benchmark (unchanged) | Benchmark + M2 only | Benchmark + M3 only |
|---|---|---|---|---|
| medrag | ares | 80.4% | 85.0% | 82.4% |
| medrag | datamorgana | 82.0% | 72.2% | 76.8% |
| medrag | ragas | 93.6% | 87.0% | 82.2% |

## 2b. Hallucination per RAG and method

| rag | method | Benchmark (unchanged) | Benchmark + M2 only | Benchmark + M3 only |
|---|---|---|---|---|
| medrag | ares | 14.4% | 10.8% | 13.6% |
| medrag | datamorgana | 13.0% | 13.6% | 17.8% |
| medrag | ragas | 7.4% | 8.8% | 20.6% |

## 3. Structural metrics (all 25, averaged over the questions)

Means of each feature over the evaluated questions, for the benchmark and each mutated version. `Real` = the real user queries of that domain (if `data/real_queries/` exists). 'general' = LightRAG and RAPTOR; 'medical' = MedRAG. Feature definitions: `src/analysis/graph_features.py` and `lexical_features.py`.

### medical: mean of each feature (1,500 distinct questions)

| feature | Real | Benchmark (unchanged) | Benchmark + M2 only | Benchmark + M3 only |
|---|---|---|---|---|
| n_tokens | 22.531 | 20.181 | 24.944 | 39.403 |
| n_sentences | 1.642 | 1.065 | 1.677 | 2.047 |
| n_nodes | 10.058 | 9.972 | 11.522 | 18.493 |
| n_edges | 7.963 | 8.563 | 9.561 | 15.459 |
| graph_density | 0.181 | 0.127 | 0.097 | 0.052 |
| avg_degree | 1.370 | 1.645 | 1.606 | 1.638 |
| max_depth | 2.547 | 3.439 | 3.693 | 4.021 |
| n_components | 2.095 | 1.409 | 1.961 | 3.035 |
| largest_component_frac | 0.830 | 0.903 | 0.828 | 0.565 |
| n_entities | 1.027 | 0.569 | 0.584 | 1.457 |
| n_entity_types | 0.642 | 0.465 | 0.482 | 1.107 |
| has_wh_word | 0.598 | 0.727 | 0.725 | 0.759 |
| starts_with_verb | 0.150 | 0.024 | 0.154 | 0.076 |
| char_len | 115 | 115 | 137 | 210 |
| word_len | 18.839 | 17.983 | 21.814 | 33.873 |
| lexical_diversity | 0.941 | 0.923 | 0.931 | 0.815 |
| avg_word_len | 4.786 | 5.424 | 5.220 | 5.070 |
| n_question_marks | 0.539 | 0.617 | 0.505 | 0.931 |
| n_sentences_punct | 1.664 | 1.092 | 1.547 | 1.995 |
| starts_lowercase | 0.309 | 0.150 | 0.338 | 0.055 |
| has_typo_like_repeat | 0.018 | 0.011 | 0.083 | 0.019 |
| has_hedge | 0.008 | 0.009 | 0.044 | 0.049 |
| has_first_person | 0.280 | 0.093 | 0.491 | 0.712 |
| has_politeness_marker | 0.104 | 0.021 | 0.223 | 0.034 |
| ends_with_question_mark | 0.453 | 0.610 | 0.184 | 0.764 |
| tree_depth | 4.284 | 5.393 | 5.659 | 6.340 |
| mean_dep_distance | 1.989 | 2.298 | 2.265 | 2.476 |
| n_clauses | 1.064 | 0.919 | 1.426 | 2.099 |
| fk_grade | 7.423 | 12.930 | 10.537 | 11.581 |
| flesch_ease | 60.738 | 33.301 | 45.937 | 42.504 |
| gunning_fog | 10.869 | 16.620 | 14.057 | 15.268 |
| syll_per_word | 1.600 | 1.843 | 1.724 | 1.737 |
| long_word_ratio | 0.248 | 0.332 | 0.303 | 0.294 |

### medical: change from the benchmark (mutated minus original)

| feature | Benchmark + M2 only vs Benchmark | Benchmark + M3 only vs Benchmark |
|---|---|---|
| n_tokens | +4.76* | +19.22* |
| n_sentences | +0.61* | +0.98* |
| n_nodes | +1.55* | +8.52* |
| n_edges | +1.00* | +6.90* |
| graph_density | -0.03* | -0.08* |
| avg_degree | -0.04* | -0.01 |
| max_depth | +0.25* | +0.58* |
| n_components | +0.55* | +1.63* |
| largest_component_frac | -0.08* | -0.34* |
| n_entities | +0.02* | +0.89* |
| n_entity_types | +0.02* | +0.64* |
| has_wh_word | -0.00 | +0.03* |
| starts_with_verb | +0.13* | +0.05* |
| char_len | +22.04* | +95.48* |
| word_len | +3.83* | +15.89* |
| lexical_diversity | +0.01* | -0.11* |
| avg_word_len | -0.20* | -0.35* |
| n_question_marks | -0.11* | +0.31* |
| n_sentences_punct | +0.45* | +0.90* |
| starts_lowercase | +0.19* | -0.09* |
| has_typo_like_repeat | +0.07* | +0.01* |
| has_hedge | +0.03* | +0.04* |
| has_first_person | +0.40* | +0.62* |
| has_politeness_marker | +0.20* | +0.01* |
| ends_with_question_mark | -0.43* | +0.15* |
| tree_depth | +0.27* | +0.95* |
| mean_dep_distance | -0.03* | +0.18* |
| n_clauses | +0.51* | +1.18* |
| fk_grade | -2.39* | -1.35* |
| flesch_ease | +12.64* | +9.20* |
| gunning_fog | -2.56* | -1.35* |
| syll_per_word | -0.12* | -0.11* |
| long_word_ratio | -0.03* | -0.04* |
