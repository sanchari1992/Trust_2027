# Feature means: real queries vs each condition

Mutations should move the generated questions toward the real-query values (first row of each table). Conditions are pooled over RAGs and methods (weighted by number of questions).

## medical

| condition | n | starts_with_verb | starts_lowercase | has_first_person | has_politeness_marker | has_typo_like_repeat | ends_with_question_mark | has_wh_word | n_entities | tree_depth | mean_dep_distance | n_clauses | fk_grade | flesch_ease | gunning_fog | word_len |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| REAL QUERIES | 300 | 0.150 | 0.333 | 0.307 | 0.093 | 0.020 | 0.460 | 0.607 | 0.763 | 4.347 | 1.944 | 1.220 | 7.282 | 61.430 | 10.727 | 17.850 |
| Benchmark (unchanged) | 1500 | 0.024 | 0.150 | 0.093 | 0.021 | 0.011 | 0.610 | 0.727 | 0.569 | 5.393 | 2.298 | 0.919 | 12.930 | 33.301 | 16.620 | 17.983 |
| Benchmark + M2 only | 1500 | 0.154 | 0.338 | 0.491 | 0.223 | 0.083 | 0.184 | 0.725 | 0.584 | 5.659 | 2.265 | 1.426 | 10.537 | 45.937 | 14.057 | 21.814 |
| Benchmark + M3 only | 1500 | 0.076 | 0.055 | 0.712 | 0.034 | 0.019 | 0.764 | 0.759 | 1.457 | 6.340 | 2.476 | 2.099 | 11.581 | 42.504 | 15.268 | 33.873 |
