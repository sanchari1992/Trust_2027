# Benchmark+ : evaluation report

Generated 2026-10-24 01:02 | profile `paper` | LLM `deepseek-flash` | embeddings `BAAI/bge-small-en-v1.5` | seed 42

Definitions: README sections 13 (mutations), 14.2 (metrics), 29-32 (databases, union, this report). `AUC` = how well a classifier tells the set from real queries (0.5 = cannot; lower = more realistic). `*_js` = Jensen-Shannon divergence in bits of the distribution of graph shapes / fine templates / entity types against the real queries (0 = identical, 1 = disjoint). `entropy` = spread of shapes (1 = even). The **union** is the three methods' questions with near-duplicates removed; its mutated versions and evaluation results are those of the method each question came from.

## medrag (medical)

### 1. Real user queries

865 real medical queries. Mean 18.8 words, 1.64 sentences, 4.71 entities per query; 283 distinct graph shapes (entropy 0.88). Commonest shapes: `what|S1|N4-6|D2|E0` 5.5%, `what|S1|N1-3|D0-1|E0` 5.5%, `how|S1|N1-3|D0-1|E0` 3.8%, `what|S1|N1-3|D0-1|E1` 2.7%, `AUX|S1|N1-3|D0-1|E0` 2.7%.

### 2. Benchmarks: how realistic and how varied

| scope | n | mean_words | n_sentences | auc_vs_real | shape_js | template_js | entity_type_js | distinct_templates | template_entropy | distinct_shapes | shape_entropy | ents_per_query | real_shape_coverage | shape_in_real |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ragas | 500 | 19.832 | 1.008 | 0.985 | 0.733 | 0.996 | 0.023 | 500 | 1.000 | 65 | 0.795 | 4.648 | 0.295 | 0.750 |
| ares | 500 | 18.416 | 1.166 | 0.905 | 0.539 | 0.962 | 0.013 | 490 | 0.998 | 119 | 0.866 | 4.906 | 0.481 | 0.724 |
| datamorgana | 500 | 15.700 | 1.022 | 0.876 | 0.491 | 0.979 | 0.025 | 496 | 1.000 | 128 | 0.884 | 3.420 | 0.548 | 0.774 |
| union | 1498 | 17.987 | 1.065 | 0.887 | 0.497 | 0.968 | 0.016 | 1473 | 0.998 | 204 | 0.829 | 4.326 | 0.661 | 0.749 |

Entity overlap: distinct real entities 2,873; distinct benchmark entities 4,672; benchmark entities also in real 0.087; real entities found in corpus 0.328; benchmark entities found in corpus 0.743.

Union: 1,500 questions from {'ragas': 500, 'ares': 500, 'datamorgana': 500} -> 1,498 after removing 2 near-duplicates (cosine >= 0.9); kept by method {'ragas': 499, 'ares': 499, 'datamorgana': 500}.

### 3. Mutations (applied to the union)

Checks passed (kept) and rejected. `by_fallback` = how many of the kept ones come from a fallback instead of the full operator (`mutation.fill_all`, README 13.12; they are included in `kept`):

| rag | method | mutation | kept | rejected | kept_rate | by_fallback | commonest_rejection |
|---|---|---|---|---|---|---|---|
| medrag | ragas | m1 | 0 | 0 |  | 0 |  |
| medrag | ragas | m2 | 500 | 0 | 1.000 | 0 |  |
| medrag | ragas | m3 | 500 | 0 | 1.000 | 19 |  |
| medrag | ares | m1 | 0 | 0 |  | 0 |  |
| medrag | ares | m2 | 500 | 0 | 1.000 | 0 |  |
| medrag | ares | m3 | 500 | 0 | 1.000 | 6 |  |
| medrag | datamorgana | m1 | 0 | 0 |  | 0 |  |
| medrag | datamorgana | m2 | 500 | 0 | 1.000 | 0 |  |
| medrag | datamorgana | m3 | 500 | 0 | 1.000 | 15 |  |

Realism of the mutated versions alone and pooled with the originals (Benchmark+):

| set | n | mean_words | n_sentences | auc_vs_real | shape_js | template_js | entity_type_js | template_entropy | shape_entropy | starts_lowercase | has_first_person | starts_with_verb |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Benchmark | 1498 | 17.987 | 1.065 | 0.887 | 0.497 | 0.968 | 0.016 | 0.998 | 0.829 | 0.150 | 0.093 | 0.024 |
| M2 Colloquial (versions alone) | 1498 | 21.822 | 1.678 | 0.880 | 0.572 | 0.994 | 0.018 | 1.000 | 0.878 | 0.338 | 0.492 | 0.154 |
| M3 Premise (versions alone) | 1498 | 33.874 | 2.047 | 0.980 | 0.815 | 1.000 | 0.012 | 1.000 | 0.802 | 0.055 | 0.712 | 0.076 |
| Benchmark + M2 | 2996 | 19.905 | 1.372 | 0.853 | 0.482 | 0.977 | 0.017 | 0.997 | 0.839 | 0.244 | 0.293 | 0.089 |
| Benchmark + M3 | 2996 | 25.931 | 1.556 | 0.911 | 0.531 | 0.979 | 0.011 | 0.999 | 0.841 | 0.103 | 0.403 | 0.050 |


## 4. Hallucinations and accuracy

Benchmark+ = the questions plus their mutated versions (N, 2N, 4N questions; README 14.7). `hallucination_rate` is the main metric (README 14.2); the interval resamples original questions. Rows for `union` pool the questions of the three methods that are in the union.

| rag | method | benchmark_plus | questions | added_questions | correct | wrong | abstained | refused | accuracy | hallucinated | hallucination_rate | rate_ci_low | rate_ci_high | hallucinated_in_added |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | ares | Benchmark | 500 | 0 | 402 | 65 | 33 | 31 | 0.804 | 72 | 0.144 | 0.114 | 0.178 | 0 |
| medrag | ares | Benchmark + M2 | 1000 | 500 | 827 | 96 | 77 | 73 | 0.827 | 126 | 0.126 | 0.102 | 0.150 | 54 |
| medrag | ares | Benchmark + M3 | 1000 | 500 | 814 | 109 | 77 | 103 | 0.814 | 140 | 0.140 | 0.119 | 0.162 | 68 |
| medrag | ares | Benchmark + M2 + M3 | 1500 | 1000 | 1239 | 140 | 121 | 145 | 0.826 | 194 | 0.129 | 0.111 | 0.149 | 122 |
| medrag | datamorgana | Benchmark | 500 | 0 | 410 | 35 | 55 | 53 | 0.820 | 65 | 0.130 | 0.102 | 0.162 | 0 |
| medrag | datamorgana | Benchmark + M2 | 1000 | 500 | 771 | 75 | 154 | 147 | 0.771 | 133 | 0.133 | 0.108 | 0.160 | 68 |
| medrag | datamorgana | Benchmark + M3 | 1000 | 500 | 794 | 102 | 104 | 130 | 0.794 | 154 | 0.154 | 0.132 | 0.178 | 89 |
| medrag | datamorgana | Benchmark + M2 + M3 | 1500 | 1000 | 1155 | 142 | 203 | 224 | 0.770 | 222 | 0.148 | 0.127 | 0.171 | 157 |
| medrag | ragas | Benchmark | 500 | 0 | 468 | 21 | 11 | 10 | 0.936 | 37 | 0.074 | 0.052 | 0.098 | 0 |
| medrag | ragas | Benchmark + M2 | 1000 | 500 | 903 | 54 | 43 | 40 | 0.903 | 81 | 0.081 | 0.061 | 0.101 | 44 |
| medrag | ragas | Benchmark + M3 | 1000 | 500 | 879 | 95 | 26 | 31 | 0.879 | 140 | 0.140 | 0.119 | 0.163 | 103 |
| medrag | ragas | Benchmark + M2 + M3 | 1500 | 1000 | 1314 | 128 | 58 | 61 | 0.876 | 184 | 0.123 | 0.104 | 0.143 | 147 |
| medrag | union | Benchmark | 1498 | 0 | 1279 | 120 | 99 | 94 | 0.854 | 173 | 0.115 | 0.100 | 0.131 | 0 |
| medrag | union | Benchmark + M2 | 2996 | 1498 | 2499 | 223 | 274 | 260 | 0.834 | 338 | 0.113 | 0.099 | 0.127 | 165 |
| medrag | union | Benchmark + M3 | 2996 | 1498 | 2485 | 304 | 207 | 264 | 0.829 | 432 | 0.144 | 0.133 | 0.159 | 259 |
| medrag | union | Benchmark + M2 + M3 | 4494 | 2996 | 3705 | 407 | 382 | 430 | 0.824 | 597 | 0.133 | 0.121 | 0.144 | 424 |

### Does each mutation expose more? (paired against the unchanged question)

`diff` = condition rate - benchmark rate on the SAME questions; the two Control rows are the noise floor and the off-topic-filler reference (README 14.1, 16).

(Union only here; all methods are in `hallucination_paired.csv`. `m_union` is the derived condition: a question fails if it fails in the benchmark or in any of M1, M2, M3.)

| rag | metric | condition | n_pairs | baseline_rate | condition_rate | diff | diff_ci_low | diff_ci_high | newly_failing | newly_passing | q_value |
|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | hallucinated | m2 | 1498 | 0.115 | 0.110 | -0.005 | -0.023 | 0.012 | 87 | 95 | 0.725 |
| medrag | hallucinated | m3 | 1498 | 0.115 | 0.173 | 0.057 | 0.033 | 0.080 | 211 | 125 | 0.000 |
| medrag | failed | m2 | 1498 | 0.146 | 0.186 | 0.039 | 0.021 | 0.058 | 127 | 68 | 0.000 |
| medrag | failed | m3 | 1498 | 0.146 | 0.195 | 0.049 | 0.023 | 0.073 | 216 | 143 | 0.000 |
| medrag | refused | m2 | 1498 | 0.063 | 0.111 | 0.048 | 0.034 | 0.061 | 92 | 20 | 0.000 |
| medrag | refused | m3 | 1498 | 0.063 | 0.113 | 0.051 | 0.034 | 0.067 | 119 | 43 | 0.000 |

### Which questions change status? (hallucinated)

| rag | method | outcome | condition | questions | fine_to_fine | fine_to_FAIL | FAIL_to_fine | FAIL_to_FAIL | benchmark_fails | condition_fails | net_change | p_mcnemar | q_value |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | union | hallucinated | Benchmark + M2 only | 1498 | 1238 | 87 | 95 | 78 | 173 | 165 | -8 | 0.604 | 0.801 |
| medrag | union | hallucinated | Benchmark + M3 only | 1498 | 1114 | 211 | 125 | 48 | 173 | 259 | 86 | 0.000 | 0.000 |

### The three mutations together (union, hallucinated)



### Refusals: "Cannot be answered from given information." (README 14.10)

The RAG is told to give exactly this answer when its documents lack the information. `refused` counts such answers per condition. `became_refused` = answered the original question but refuses this version (for M3: the patient information added to the question makes it unanswerable from the documents); `stopped_refusing` = the reverse; `refused_in_both` = the documents never held the answer. `abstained_by_judge` also counts declines in other words (refused <= abstained_by_judge). A refusal is a failure to answer, never a hallucination.

| rag | method | condition | total | refused | refused_rate | abstained_by_judge | became_refused | stopped_refusing | refused_in_both |
|---|---|---|---|---|---|---|---|---|---|
| medrag | union | Benchmark (unchanged) | 1498 | 94 | 0.063 | 99 |  |  |  |
| medrag | union | Benchmark + M2 only | 1498 | 166 | 0.111 | 175 | 92.000 | 20.000 | 74.000 |
| medrag | union | Benchmark + M3 only | 1498 | 170 | 0.113 | 108 | 119 | 43.000 | 51.000 |

(All methods: `refusals.csv`.)

## 5. The story table

One row per question set. Realism columns: lower AUC / JS is closer to real queries. Hallucination columns: from the pooled Benchmark+ definition (the `+M` rows contain the originals AND the mutated versions).

### medrag

| row | n | mean_words | n_sentences | ents_per_query | distinct_shapes | shape_entropy | auc_vs_real | shape_js | template_js | entity_type_js | questions | accuracy | hallucination_rate | ci_low | ci_high |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Real queries | 865 | 18.839 | 1.642 | 4.711 | 283 | 0.877 |  |  |  |  |  |  |  |  |  |
| RAGAS | 500 | 19.832 | 1.008 | 4.648 | 65 | 0.795 | 0.985 | 0.733 | 0.996 | 0.023 | 500 | 0.936 | 0.074 | 0.052 | 0.098 |
| ARES | 500 | 18.416 | 1.166 | 4.906 | 119 | 0.866 | 0.905 | 0.539 | 0.962 | 0.013 | 500 | 0.804 | 0.144 | 0.114 | 0.178 |
| DataMorgana | 500 | 15.700 | 1.022 | 3.420 | 128 | 0.884 | 0.876 | 0.491 | 0.979 | 0.025 | 500 | 0.820 | 0.130 | 0.102 | 0.162 |
| Union | 1498 | 17.987 | 1.065 | 4.326 | 204 | 0.829 | 0.887 | 0.497 | 0.968 | 0.016 | 1498 | 0.854 | 0.115 | 0.100 | 0.131 |
| Union + M2 | 2996 | 19.905 | 1.372 | 4.500 | 378 | 0.839 | 0.853 | 0.482 | 0.977 | 0.017 | 2996 | 0.834 | 0.113 | 0.099 | 0.127 |
| Union + M3 | 2996 | 25.931 | 1.556 | 6.010 | 358 | 0.841 | 0.911 | 0.531 | 0.979 | 0.011 | 2996 | 0.829 | 0.144 | 0.133 | 0.159 |

## 6. Cost and provenance

LLM calls and tokens of the LAST run of each stage (a resumed run only counts its own part):

| rag | stage | method | accepted | attempts | acceptance_rate | llm_calls_last_run | prompt_tokens | completion_tokens | model |
|---|---|---|---|---|---|---|---|---|---|
| medrag | generation | ragas | 500 | 503 | 0.994 | 1006 | 435665 | 42703 | deepseek-flash |
| medrag | generation | ares | 500 | 1,069 | 0.468 | 1570 | 952450 | 38023 | deepseek-flash |
| medrag | generation | datamorgana | 500 | 675 | 0.741 | 1350 | 1166541 | 178177 | deepseek-flash |
| medrag | mutation | ragas | 500 |  |  | 1700 | 771729 | 37727 | deepseek-flash |
| medrag | mutation | ares | 500 |  |  | 1884 | 468921 | 38865 | deepseek-flash |
| medrag | mutation | datamorgana | 500 |  |  | 1840 | 840284 | 39421 | deepseek-flash |

Hand-audit sheet for assumption A4 (README 13.2): `audit_sheet_mutations.csv` (200 mutated questions; fill the last five columns and report the shares).

## Files

All in `C:\Users\tuo94543\Documents\GitHub\Trust_2027\results\paper_final`: `audit_sheet_mutations.csv`, `hallucination_any_of_three.csv`, `hallucination_benchmark_plus.csv`, `hallucination_paired.csv`, `hallucination_per_condition.csv`, `hallucination_transitions.csv`, `mutation_validity.csv`, `paper_tables.tex`, `provenance.csv`, `realism_all.csv`, `refusals.csv`, `story_medrag.csv`, `templates_top.csv`
