# Benchmark vs Benchmark+ : one table per metric

Columns: the three benchmark-generation methods side by side under each condition. **M1** = length, **M2** = linguistic (typos, person, register, request form), **M3** = user-provided information (correct or incorrect), **M1,2,3** = all three. Every column covers the same questions as its benchmark column (only questions answered and judged in every condition are used).

## Hallucination rate

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 7.4% | 14.4% | 13.0% | 8.8% | 10.8% | 13.6% | 20.6% | 13.6% | 17.8% |
| All RAGs | 7.4% | 14.4% | 13.0% | 8.8% | 10.8% | 13.6% | 20.6% | 13.6% | 17.8% |

### Change in hallucination rate versus the same method's benchmark

| RAG | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|
| MedRAG | +1.4 pp | -3.6 pp | +0.6 pp | +13.2 pp | -0.8 pp | +4.8 pp |
| All RAGs | +1.4 pp | -3.6 pp | +0.6 pp | +13.2 pp | -0.8 pp | +4.8 pp |

## Wrong-behaviour rate (asserted wrong / adopted a false claim)

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 4.2% | 13.0% | 7.0% | 6.6% | 6.2% | 8.0% | 14.8% | 8.8% | 13.4% |
| All RAGs | 4.2% | 13.0% | 7.0% | 6.6% | 6.2% | 8.0% | 14.8% | 8.8% | 13.4% |

## Unfaithful and wrong

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 1.0% | 0.0% | 1.2% | 2.4% | 0.8% | 2.0% | 1.8% | 0.8% | 2.4% |
| All RAGs | 1.0% | 0.0% | 1.2% | 2.4% | 0.8% | 2.0% | 1.8% | 0.8% | 2.4% |

## Retrieval miss rate (original source passage not retrieved)

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 42.6% | 6.0% | 74.0% | 47.2% | 12.4% | 78.6% | 46.8% | 8.4% | 74.0% |
| All RAGs | 42.6% | 6.0% | 74.0% | 47.2% | 12.4% | 78.6% | 46.8% | 8.4% | 74.0% |

## Accuracy

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 93.6% | 80.4% | 82.0% | 87.0% | 85.0% | 72.2% | 82.2% | 82.4% | 76.8% |
| All RAGs | 93.6% | 80.4% | 82.0% | 87.0% | 85.0% | 72.2% | 82.2% | 82.4% | 76.8% |

## Accuracy on questions whose correct behaviour is to answer

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 93.6% | 80.4% | 82.0% | 87.0% | 85.0% | 72.2% | 88.7% | 90.1% | 88.3% |
| All RAGs | 93.6% | 80.4% | 82.0% | 87.0% | 85.0% | 72.2% | 88.7% | 90.1% | 88.3% |

## Questions per cell

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 500 | 500 | 500 | 500 | 500 | 500 | 500 | 500 | 500 |
| All RAGs | 500 | 500 | 500 | 500 | 500 | 500 | 500 | 500 | 500 |
