# Audit: why are mutated questions counted as hallucinations?

Questions that were fine in the original benchmark but hallucinated in a mutated condition, by cause (definitions in the header of `src/evalrun/audit.py`). `judge_artifact` rows are NOT counted as hallucinations in the main tables; they are shown so you can see what the strict score would have added.

| condition_label | behaviour_failure | unfaithful_and_wrong | unsupported_but_correct | judge_artifact | other | also_in_control |
|---|---|---|---|---|---|---|
| Benchmark + M2 only | 45 | 0 | 42 | 37 | 0 | 0 |
| Benchmark + M3 only | 152 | 0 | 59 | 46 | 0 | 0 |

## behaviour_failure (197)

**Benchmark + M2 only** | medrag/ares | ares-medrag-0101 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 1.0 | operators m2:synonyms,m2:first_person

- original: The preganglionic fiber synapses with a postganglionic neuron in the celiac ganglion.
- mutated: I was wondering about something. The preganglionic fiber synapses with a postganglionic neuron in the coeliac ganglion.
- response: The greater splanchnic nerve passes through the crura of the diaphragm and enters the celiac ganglion, where the preganglionic fiber synapses with a postganglionic neuron.

**Benchmark + M2 only** | medrag/ares | ares-medrag-0067 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 0.0 | operators m2:first_person,m2:typos

- original: What are two of the most widely recognized second messenger systems?
- mutated: I have a quick question. What are two of the most widely recognized second messenger ssytems?
- response: Based on the documents, two widely recognized second messenger systems are **cyclic AMP (cAMP)** and **Ca2+ (calcium)**. Document [9] states that second messengers include "cyclic AMP and Ca2+, [which] are water-soluble and diffuse in the cytosol," and Document [21] lists examples of second messengers as "cyclic AMP, cyclic GMP, IP3, Ca2+, and diacylglycerol."

**Benchmark + M2 only** | medrag/ares | ares-medrag-0018 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 1.0 | operators m2:imperative,m2:typos

- original: What are the two types of cell-matrix anchoring junctions that tether the basal surface of the cell to the basal lamina?
- mutated: Explain what are the two types of cell-matrix anchoring junctions that tether the basao surface of the cell to the basal laminna.
- response: The two types of cell–matrix anchoring junctions that tether the basal surface of the cell to the basal lamina are actin-linked cell–matrix junctions, which anchor actin filaments to the matrix, and hemidesmosomes, which anchor intermediate filaments to it.

**Benchmark + M2 only** | medrag/ares | ares-medrag-0169 | label `incorrect` | faithfulness 1.0 (strict 0.0) | retrieval_hit 1.0 | operators m2:synonyms,m2:first_person

- original: Other risk factors include maternal substance abuse, placenta previa, and multiple gestations. First step: Diagnose by confrming serial fundal height measurements with ultrasound. Second step: Ultrasound the fetus for EFW (although as pregnancy advances, ultrasound fetal weight estimates become increasingly unreliable). First step: Explore the underlying etiology and correct if possible. If near due date: Administer steroids (e.g., betamethasone) to accelerate fetal lung maturity. Then: Perform fetal monitoring with NST, CST, BPP, and umbilical artery Doppler velocimetry. A nonreassuring status near term may prompt delivery. ↑ perinatal morbidity and mortality. Defned as a birth weight > 90th percentile.
- mutated: I need some help with this. Other risk factors include maternal substance abuse, placenta previa, and multiple gestations. First step: Diagnose by confrming serial fundal height measurements with ultrasound. Second step: Ultrasound the fetus for EFW (although as pregnancy advances, ultrasound fetal weight estimates become increasingly unreliable). First step: Explore the underlying etiology and right if possible. If near due date: Administer steroids (e.g., betamethasone) to quicken fetal lung maturity. Then: Perform fetal monitoring with NST, CST, BPP, and umbilical artery Doppler velocimetry. A nonreassuring status near term may prompt delivery. ↑ perinatal morbidity and mortality. Defned as a birth weight > 90th percentile.
- response: Fetal macrosomia.

**Benchmark + M2 only** | medrag/ares | ares-medrag-0049 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 1.0 | operators m2:synonyms,m2:casual

- original: Pain from a low sensory output region is interpreted as coming from a high sensory output region.
- mutated: pain from a low sensory output region is interpreted as arriving from a high sensory output region...
- response: Referred pain.

**Benchmark + M2 only** | medrag/ares | ares-medrag-0364 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 0.0 | operators m2:synonyms,m2:casual

- original: What are the methods of monitoring the fetal heart rate?
- mutated: so what are the methods of monitoring the foetal heart rate?
- response: The documents describe the following methods of monitoring the fetal heart rate (FHR):

- **External Doppler monitoring:** FHR is monitored externally by Doppler along with a tocodynamometer to detect uterine contractions (used during the nonstress test, with the mother in the lateral tilt position).
- **Fetal heart tones by Doppler:** Can be heard at 10–12 weeks (as a means of determining gestational age).
- **Fetal heart tracing review:** FHR tracings are reviewed at defined intervals during labor — every 30 minutes in the first stage and every 15 minutes in the second stage for patients wit

**Benchmark + M2 only** | medrag/ares | ares-medrag-0432 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 1.0 | operators m2:synonyms,m2:casual

- original: In mice, locally produced signal proteins stimulate cells between developing fingers and toes to kill themselves (see Figure 18–2).
- mutated: in mice, locally made signal proteins stimulate cells between developing fingers and toes to kill themselves (see Figure 18–2).
- response: Apoptosis

**Benchmark + M2 only** | medrag/ares | ares-medrag-0167 | label `incorrect` | faithfulness 0.6666666666666666 (strict 0.6666666666666666) | retrieval_hit 0.0 | operators m2:casual,m2:typos

- original: If obstruction is noted on CT scan, where is it usually present?
- mutated: quick question - if obstruction is noted on CT scan, where's it usally present???
- response: If obstruction is noted on CT scan, it is usually present in the **small bowel** (small bowel obstruction). The documents note that the leading cause of SBO in adults is adhesions, and CT is more sensitive and specific than AXR for diagnosing obstruction.

## unsupported_but_correct (101)

**Benchmark + M2 only** | medrag/ares | ares-medrag-0480 | label `correct` | faithfulness 0.7142857142857143 (strict 0.5714285714285714) | retrieval_hit 0.0 | operators m2:synonyms,m2:first_person

- original: The notochord induces overlying ectoderm to differentiate into neuroectoderm and form the neural plate.
- mutated: The notochord induces overlying ectoderm to differentiate into neuroectoderm and form the neuronal plate. I'd really like to understand this.
- response: The notochord induces the overlying ectoderm to become neuroectoderm by secreting Chordin and Noggin, which antagonize BMP signaling. BMPs are secreted throughout the embryo and drive ectodermal cells toward epidermal fates; where Chordin and Noggin block BMP (dorsal side), cells experience little or no BMP signaling and remain neural, forming the neural plate. This dorsal-to-ventral gradient of BMP inhibition thus specifies the neuroectoderm (Documents [11], [31]).

**Benchmark + M2 only** | medrag/ares | ares-medrag-0155 | label `correct` | faithfulness 0.9 (strict 0.9) | retrieval_hit 1.0 | operators m2:synonyms,m2:typos

- original: Male gender, age greater than 45 years, psychiatric disorders, a history of admission to a psychiatric institution, a previous suicide attempt, a history of violent behavior, ethanol or substance abuse, recent severe stressors, and a family suicide history.
- mutated: Male gender, age greater than 45 years, psychiatrical disorders, a history of admission to a psychiatric institution, a previous suicide attemppt, a history of violent behavior, ethanol or substance abuse, rcent severe stressors, and a family suuicide history.
- response: These are risk factors for suicide (the SAD PERSONS mnemonic), indicating increased likelihood of suicide completion.

**Benchmark + M2 only** | medrag/ares | ares-medrag-0140 | label `correct` | faithfulness 0.8 (strict 0.8) | retrieval_hit 1.0 | operators m2:typos,m2:politeness

- original: In some carcinomas of the stomach and of the breast, E-cadherin has been identified as a tumor suppressor gene, and a loss of E-cadherin may promote cancer development by facilitating local invasiveness.
- mutated: Could you help with a question? In some carcinomas of the stomach and of the breast, E-cadherun has been identified as a tumor suppressor gene, and a loss of E-caherin may promote cancer development by facilitating local invasiveness.
- response: Yes. According to the documents, in some carcinomas of the stomach and breast, E-cadherin has been identified as a tumor suppressor gene, and loss of E-cadherin can promote cancer development by facilitating local invasiveness—consistent with its role in cell–cell adhesion and the epithelial–mesenchymal transition.

**Benchmark + M2 only** | medrag/ares | ares-medrag-0181 | label `correct` | faithfulness 0.6 (strict 0.8) | retrieval_hit 1.0 | operators m2:first_person,m2:typos

- original: The adaptive system uses unique genetic mechanisms to produce a virtually limitless diversity of related proteins—receptors on T and B cells and secreted antibodies—that, between them, can bind almost any foreign molecule.
- mutated: I have a quick question. The adaptive system uses unique genetic mecanisms to prroduce a virtually limitless diversity of related proteins—receptors on T and B cwlls and secreted antibodies—that, between them, can bind almost any foreign molecule.
- response: The adaptive immune system uses unique genetic mechanisms—V(D)J recombination of gene segments, combinatorial joining of light and heavy chains, and junctional gain/loss of nucleotides—to generate a virtually limitless diversity of B and T cell receptors and secreted antibodies that can bind almost any foreign molecule.

**Benchmark + M2 only** | medrag/ares | ares-medrag-0395 | label `correct` | faithfulness 0.5 (strict 0.5) | retrieval_hit 1.0 | operators m2:casual,m2:typos

- original: pH is defined as the negative logarithm of the hydrogen ion concentration in moles per liter (M).
- mutated: hey, pH is defined as the neggative logarithm of the hydrogen ion concentration in moles per liter (M)
- response: Yes. The documents define pH as the negative logarithm of the hydrogen ion concentration in moles per liter: pH = –log [H+] (Document [19]; also Document [1]).

**Benchmark + M2 only** | medrag/ares | ares-medrag-0315 | label `correct` | faithfulness 0.8571428571428571 (strict 0.8571428571428571) | retrieval_hit 1.0 | operators m2:casual,m2:politeness

- original: The high frequency of the βS mutation among black Africans, despite its damaging effects in the homozygous state, suggests that a selective advantage exists for heterozygous individuals.
- mutated: Can you help out with something? the high frequency of the βS mutation among black Africans, despite its damaging effects in the homozygous state, suggests that a selective advantage exists for heterozygous individuals
- response: Yes. According to the documents, the high frequency of the βS mutation among black Africans, despite its damaging effects in homozygotes, suggests a selective advantage for heterozygous individuals. Heterozygotes for the sickle cell gene are less susceptible to severe malaria caused by Plasmodium falciparum, because their red blood cells have a shorter lifespan and the parasite cannot complete its intracellular stage. This provides a selective advantage in regions where malaria is a major cause of death, and the geographic distribution of sickle cell anemia in Africa is similar to that of mala

**Benchmark + M2 only** | medrag/ares | ares-medrag-0209 | label `correct` | faithfulness 0.8 (strict 0.8) | retrieval_hit 1.0 | operators m2:first_person,m2:casual

- original: The technique described in Figure 22–5 can be used to create a genetic mark in a random subset of Lgr5-expressing cells—a mark that is inherited by the progeny of each cell.
- mutated: hi, I have a quick question. The technique described in Figure 22–5 can be used to create a genetic mark in a random subset of Lgr5-expressing cells—a mark that's inherited by the progeny of each cell
- response: The technique described in Figure 22–5 uses transgenic animals carrying two transgenes that together drive expression of a heritable marker protein in a small subset of stem cells. The first transgene carries GFP and CreERT2 under the control of the Lgr5 promoter (active only in stem cells); CreERT2 encodes a chimeric Cre recombinase linked to the estrogen receptor, which becomes active only when it binds tamoxifen. Thus, treatment with a low dose of tamoxifen activates the recombinase in occasional Lgr5-expressing stem cells, creating a genetic mark (e.g., LacZ expression) that is inherited b

**Benchmark + M2 only** | medrag/ares | ares-medrag-0076 | label `correct` | faithfulness 0.6666666666666666 (strict 0.6666666666666666) | retrieval_hit 1.0 | operators m2:first_person,m2:casual

- original: The lumen of the esophagus is normally closed because it has no skeletal support structures to hold it open.
- mutated: hey, I'm trying to understand something. The lumen of the esophagus is normally closed because it has no skeletal support structures to hold it open.
- response: Yes—the documents state that the lumen of the esophagus is normally closed because, unlike the airway, it has no skeletal support structures to hold it open (Document [2]).

## judge_artifact (83)

**Benchmark + M2 only** | medrag/ares | ares-medrag-0228 | label `correct` | faithfulness 1.0 (strict 0.9090909090909091) | retrieval_hit nan | operators m2:imperative,m2:casual

- original: What imaging modalities are discussed for ovarian tumors?
- mutated: tell me what imaging modalities are discussed for ovarian tumors.
- response: The documents discuss several imaging modalities for ovarian tumors: ultrasonography (including transabdominal, transvaginal, and color flow Doppler), computed tomography (CT), magnetic resonance imaging (MRI), positron emission tomography (PET, including PET/CT), abdominal flat-plate radiography, and nuclear medicine imaging (NP-59 scanning).

**Benchmark + M2 only** | medrag/ares | ares-medrag-0450 | label `correct` | faithfulness 1.0 (strict 0.9666666666666667) | retrieval_hit nan | operators m2:casual,m2:typos

- original: What are the features of sickle cell anemia?
- mutated: ok so what are the features of sickle cell annemia
- response: Sickle cell anemia is an autosomal-recessive disorder caused by a point mutation in the β-globin gene (glutamate replaced by valine at position 6), producing HbS. Key features based on the documents:

- **Pathogenesis:** Deoxygenated HbS polymerizes inside RBCs, forming insoluble fibrous polymers that stiffen and distort cells into rigid, sickled shapes. Low O2, high altitude, acidosis, cold, dehydration, and infection precipitate sickling/crises.
- **Hemolysis/anemia:** Chronic hemolytic anemia with hyperbilirubinemia and jaundice; reduced RBC lifespan (<20 days vs. 120 normal); cholelithiasi

**Benchmark + M2 only** | medrag/ares | ares-medrag-0180 | label `correct` | faithfulness 1.0 (strict 0.5) | retrieval_hit nan | operators m2:casual,m2:typos

- original: The sides and roof of the carpal tunnel are formed by the arch of the carpal bones.
- mutated: quick question - the sides and roof of the carpal tunnel are foormed by the arch of the carpal bones.
- response: Yes. According to the documents, the sides and roof of the carpal tunnel are formed by the arch of the carpal bones (with the flexor retinaculum forming the anterior wall/roof spanning the base of the arch).

**Benchmark + M2 only** | medrag/ares | ares-medrag-0281 | label `correct` | faithfulness 1.0 (strict 0.75) | retrieval_hit nan | operators m2:synonyms,m2:typos

- original: The body weight of most individuals tends to be relatively stable over time.
- mutated: The body weight of most individuals tends to be comparatively stble over time.
- response: Yes, the documents support this. Document [6] states: "The body weight of most individuals tends to be relatively stable over time," which prompted the hypothesis of a biologically predetermined "set point" for body weight that the body defends.

**Benchmark + M2 only** | medrag/ares | ares-medrag-0297 | label `correct` | faithfulness 1.0 (strict 0.2) | retrieval_hit nan | operators m2:casual,m2:politeness

- original: Normalizing PCO2, respiratory acidosis, and more severe hypoxia in an acute exacerbation warrant close observation, as they may indicate fatigue and impending respiratory failure.
- mutated: Normalizing PCO2, respiratory acidosis, and more severe hypoxia in an acute exacerbation warrant close observation, as they may indicate fatigue and impending respiratory failure Thank you!
- response: Normalizing PCO2, respiratory acidosis, and more severe hypoxia in an acute exacerbation warrant close observation, as they may indicate fatigue and impending respiratory failure.

**Benchmark + M2 only** | medrag/ares | ares-medrag-0222 | label `correct` | faithfulness 1.0 (strict 0.75) | retrieval_hit nan | operators m2:typos,m2:politeness

- original: Defects in the XP proteins needed for nucleotide excision repair of thymine dimers in humans result in what condition?
- mutated: Would you mind helping with a question? Defectts in the XP proteins needed for nucleotide excision repair of thymine dimefs in humans result in what condition?
- response: Xeroderma pigmentosum (XP) — individuals with defects in nucleotide excision repair of thymine dimers have extreme sensitivity to ultraviolet radiation, leading to serious skin lesions and increased susceptibility to skin cancers.

**Benchmark + M2 only** | medrag/ares | ares-medrag-0412 | label `correct` | faithfulness 1.0 (strict 0.5) | retrieval_hit nan | operators m2:first_person,m2:politeness

- original: What injuries in children are pathognomonic for abuse?
- mutated: I'm trying to understand something. What injuries in children are pathognomonic for abuse? Please let me know. Thanks!
- response: Retinal hemorrhages and specific fracture types are pathognomonic for abuse.

**Benchmark + M2 only** | medrag/ares | ares-medrag-0347 | label `correct` | faithfulness 1.0 (strict 0.0) | retrieval_hit nan | operators m2:casual,m2:typos

- original: What is sobering to note about the proteins identified through examining the human genome?
- mutated: What's sobering to note about the proteins identified through exanining the human genome
- response: We currently lack even the tiniest hint of what the function might be for more than 10,000 of the proteins identified through examining the human genome.
