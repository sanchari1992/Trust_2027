# Benchmark+ as a bigger benchmark (originals + mutated versions)

Benchmark+ contains the original questions and their mutated versions, so `questions` grows: N, 2N (one mutation added), 4N (all three added). Counts are sums over all questions in the set, rates are counts / questions; the interval resamples ORIGINAL questions with all their versions. `added_questions` / `hallucinated_in_added` count only the mutated rows that were added. The two `Reference` rows add a control instead of a mutation (same question again; off-topic filler).

## All RAGs and methods pooled

| benchmark_plus | questions | added_questions | correct | wrong | abstained | refused | accuracy | hallucinated | hallucination_rate | rate_ci_low | rate_ci_high | hallucinated_in_added | wrong_behavior | unsupported_but_correct | unfaithful_and_wrong |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Benchmark | 1500 | 0 | 1280 | 121 | 99 | 94 | 0.853 | 174 | 0.116 | 0.101 | 0.131 | 0 | 121 | 53 | 11 |
| Benchmark + M2 | 3000 | 1500 | 2501 | 225 | 274 | 260 | 0.834 | 340 | 0.113 | 0.100 | 0.128 | 166 | 225 | 115 | 37 |
| Benchmark + M3 | 3000 | 1500 | 2487 | 306 | 207 | 264 | 0.829 | 434 | 0.145 | 0.132 | 0.158 | 260 | 306 | 128 | 36 |
| Benchmark + M2 + M3 | 4500 | 3000 | 3708 | 410 | 382 | 430 | 0.824 | 600 | 0.133 | 0.121 | 0.145 | 426 | 410 | 190 | 62 |

## Per RAG and method

| rag | method | benchmark_plus | questions | added_questions | correct | wrong | abstained | refused | accuracy | hallucinated | hallucination_rate | rate_ci_low | rate_ci_high | hallucinated_in_added | wrong_behavior | unsupported_but_correct | unfaithful_and_wrong |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | ares | Benchmark | 500 | 0 | 402 | 65 | 33 | 31 | 0.804 | 72 | 0.144 | 0.114 | 0.178 | 0 | 65 | 7 | 0 |
| medrag | ares | Benchmark + M2 | 1000 | 500 | 827 | 96 | 77 | 73 | 0.827 | 126 | 0.126 | 0.102 | 0.150 | 54 | 96 | 30 | 4 |
| medrag | ares | Benchmark + M3 | 1000 | 500 | 814 | 109 | 77 | 103 | 0.814 | 140 | 0.140 | 0.119 | 0.162 | 68 | 109 | 31 | 4 |
| medrag | ares | Benchmark + M2 + M3 | 1500 | 1000 | 1239 | 140 | 121 | 145 | 0.826 | 194 | 0.129 | 0.111 | 0.149 | 122 | 140 | 54 | 8 |
| medrag | datamorgana | Benchmark | 500 | 0 | 410 | 35 | 55 | 53 | 0.820 | 65 | 0.130 | 0.102 | 0.162 | 0 | 35 | 30 | 6 |
| medrag | datamorgana | Benchmark + M2 | 1000 | 500 | 771 | 75 | 154 | 147 | 0.771 | 133 | 0.133 | 0.108 | 0.160 | 68 | 75 | 58 | 16 |
| medrag | datamorgana | Benchmark + M3 | 1000 | 500 | 794 | 102 | 104 | 130 | 0.794 | 154 | 0.154 | 0.132 | 0.178 | 89 | 102 | 52 | 18 |
| medrag | datamorgana | Benchmark + M2 + M3 | 1500 | 1000 | 1155 | 142 | 203 | 224 | 0.770 | 222 | 0.148 | 0.127 | 0.171 | 157 | 142 | 80 | 28 |
| medrag | ragas | Benchmark | 500 | 0 | 468 | 21 | 11 | 10 | 0.936 | 37 | 0.074 | 0.052 | 0.098 | 0 | 21 | 16 | 5 |
| medrag | ragas | Benchmark + M2 | 1000 | 500 | 903 | 54 | 43 | 40 | 0.903 | 81 | 0.081 | 0.061 | 0.101 | 44 | 54 | 27 | 17 |
| medrag | ragas | Benchmark + M3 | 1000 | 500 | 879 | 95 | 26 | 31 | 0.879 | 140 | 0.140 | 0.119 | 0.163 | 103 | 95 | 45 | 14 |
| medrag | ragas | Benchmark + M2 + M3 | 1500 | 1000 | 1314 | 128 | 58 | 61 | 0.876 | 184 | 0.123 | 0.104 | 0.143 | 147 | 128 | 56 | 26 |

# Counts and rates per condition (each condition on its own, paired with the benchmark)

Each mutated condition is the original benchmark question with ONLY that mutation applied; `Benchmark + M1+M2+M3 (all three)` is the only combined one. `wrong` = not correct and not declined; `abstained` = declined; wrong + abstained = all failures. `accuracy` = correct / total. `newly_failed` / `newly_fixed` / `failed_in_both` compare each question with its own unchanged version; `failed_in_both` are the questions that fail whatever you do to them. `refused` = the answer was exactly "Cannot be answered from given information." (a subset of `abstained`).

## All RAGs and methods pooled

| condition | total | correct | wrong | abstained | refused | accuracy | hallucinated | hallucination_rate | wrong_behavior | unsupported_but_correct | retrieval_hit_rate | newly_failed | newly_fixed | failed_in_both | net_failed |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Benchmark (unchanged) | 1500 | 1280 | 121 | 99 | 94 | 0.853 | 174 | 0.116 | 121 | 53 | 0.591 |  |  |  |  |
| Benchmark + M2 only | 1500 | 1221 | 104 | 175 | 166 | 0.814 | 166 | 0.111 | 104 | 62 | 0.539 | 127 | 68.000 | 152 | 59.000 |
| Benchmark + M3 only | 1500 | 1207 | 185 | 108 | 170 | 0.805 | 260 | 0.173 | 185 | 75 | 0.569 | 216 | 143 | 77.000 | 73.000 |

## Per RAG and method

| rag | method | condition | total | correct | wrong | abstained | refused | accuracy | hallucinated | hallucination_rate | wrong_behavior | unsupported_but_correct | retrieval_hit_rate | newly_failed | newly_fixed | failed_in_both | net_failed |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | ares | Benchmark (unchanged) | 500 | 402 | 65 | 33 | 31 | 0.804 | 72 | 0.144 | 65 | 7 | 0.940 |  |  |  |  |
| medrag | ares | Benchmark + M2 only | 500 | 425 | 31 | 44 | 42 | 0.850 | 54 | 0.108 | 31 | 23 | 0.876 | 30.000 | 53.000 | 45.000 | -23.000 |
| medrag | ares | Benchmark + M3 only | 500 | 412 | 44 | 44 | 72 | 0.824 | 68 | 0.136 | 44 | 24 | 0.916 | 63.000 | 73.000 | 25.000 | -10.000 |
| medrag | datamorgana | Benchmark (unchanged) | 500 | 410 | 35 | 55 | 53 | 0.820 | 65 | 0.130 | 35 | 30 | 0.260 |  |  |  |  |
| medrag | datamorgana | Benchmark + M2 only | 500 | 361 | 40 | 99 | 94 | 0.722 | 68 | 0.136 | 40 | 28 | 0.214 | 61.000 | 12.000 | 78.000 | 49.000 |
| medrag | datamorgana | Benchmark + M3 only | 500 | 384 | 67 | 49 | 77 | 0.768 | 89 | 0.178 | 67 | 22 | 0.260 | 80.000 | 54.000 | 36.000 | 26.000 |
| medrag | ragas | Benchmark (unchanged) | 500 | 468 | 21 | 11 | 10 | 0.936 | 37 | 0.074 | 21 | 16 | 0.574 |  |  |  |  |
| medrag | ragas | Benchmark + M2 only | 500 | 435 | 33 | 32 | 30 | 0.870 | 44 | 0.088 | 33 | 11 | 0.528 | 36.000 | 3.000 | 29.000 | 33.000 |
| medrag | ragas | Benchmark + M3 only | 500 | 411 | 74 | 15 | 21 | 0.822 | 103 | 0.206 | 74 | 29 | 0.532 | 73.000 | 16.000 | 16.000 | 57.000 |

## Combined count, step by step

`sum` = benchmark + new failures added by M1 + M2 + M3 (a question that newly fails under two mutations is counted twice); `union` = the same without double counting (never above the number of questions); `double_counted` = sum - union. This estimates the failures of a benchmark that uses all three mutations as separate variants; it does not measure ONE prompt that contains all three mutations (`evaluation.combined: run`).

| metric | questions | benchmark | new_by_M2 | new_by_M3 | sum | union | double_counted | sum_rate | union_rate |
|---|---|---|---|---|---|---|---|---|---|
| not correct (wrong + declined) | 1500 | 220 | 127 | 216 | 563 | 536 | 27 | 0.375 | 0.357 |
| hallucinated | 1500 | 174 | 87 | 211 | 472 | 448 | 24 | 0.315 | 0.299 |
| refused (Cannot be answered from given information.) | 1500 | 94 | 92 | 119 | 305 | 292 | 13 | 0.203 | 0.195 |

| rag | method | metric | questions | benchmark | new_by_M2 | new_by_M3 | sum | union | double_counted | sum_rate | union_rate |
|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | ares | not correct (wrong + declined) | 500 | 98 | 30 | 63 | 191 | 184 | 7 | 0.382 | 0.368 |
| medrag | ares | hallucinated | 500 | 72 | 30 | 56 | 158 | 152 | 6 | 0.316 | 0.304 |
| medrag | ares | refused (Cannot be answered from given information.) | 500 | 31 | 21 | 55 | 107 | 104 | 3 | 0.214 | 0.208 |
| medrag | datamorgana | not correct (wrong + declined) | 500 | 90 | 61 | 80 | 231 | 222 | 9 | 0.462 | 0.444 |
| medrag | datamorgana | hallucinated | 500 | 65 | 33 | 68 | 166 | 160 | 6 | 0.332 | 0.320 |
| medrag | datamorgana | refused (Cannot be answered from given information.) | 500 | 53 | 49 | 46 | 148 | 143 | 5 | 0.296 | 0.286 |
| medrag | ragas | not correct (wrong + declined) | 500 | 32 | 36 | 73 | 141 | 130 | 11 | 0.282 | 0.260 |
| medrag | ragas | hallucinated | 500 | 37 | 24 | 87 | 148 | 136 | 12 | 0.296 | 0.272 |
| medrag | ragas | refused (Cannot be answered from given information.) | 500 | 10 | 22 | 18 | 50 | 45 | 5 | 0.100 | 0.090 |

## Refusals ("Cannot be answered from given information.")

`refused` counts answers that are exactly the refusal phrase the RAG's system prompt asks for when the documents lack the information. `became_refused` = answered in the benchmark, refuses in this version (for M3: the added patient information makes the question unanswerable); `stopped_refusing` = the reverse; `refused_in_both` = the documents never held the answer. `abstained_by_judge` also counts declines in other words.

| condition | total | refused | refused_rate | abstained_by_judge | became_refused | stopped_refusing | refused_in_both |
|---|---|---|---|---|---|---|---|
| Benchmark (unchanged) | 1500 | 94 | 0.063 | 99 |  |  |  |
| Benchmark + M2 only | 1500 | 166 | 0.111 | 175 | 92.000 | 20.000 | 74.000 |
| Benchmark + M3 only | 1500 | 170 | 0.113 | 108 | 119 | 43.000 | 51.000 |

| rag | method | condition | total | refused | refused_rate | abstained_by_judge | became_refused | stopped_refusing | refused_in_both |
|---|---|---|---|---|---|---|---|---|---|
| medrag | ares | Benchmark (unchanged) | 500 | 31 | 0.062 | 33 |  |  |  |
| medrag | ares | Benchmark + M2 only | 500 | 42 | 0.084 | 44 | 21.000 | 10.000 | 21.000 |
| medrag | ares | Benchmark + M3 only | 500 | 72 | 0.144 | 44 | 55.000 | 14.000 | 17.000 |
| medrag | datamorgana | Benchmark (unchanged) | 500 | 53 | 0.106 | 55 |  |  |  |
| medrag | datamorgana | Benchmark + M2 only | 500 | 94 | 0.188 | 99 | 49.000 | 8.000 | 45.000 |
| medrag | datamorgana | Benchmark + M3 only | 500 | 77 | 0.154 | 49 | 46.000 | 22.000 | 31.000 |
| medrag | ragas | Benchmark (unchanged) | 500 | 10 | 0.020 | 11 |  |  |  |
| medrag | ragas | Benchmark + M2 only | 500 | 30 | 0.060 | 32 | 22.000 | 2.000 | 8.000 |
| medrag | ragas | Benchmark + M3 only | 500 | 21 | 0.042 | 15 | 18.000 | 7.000 | 3.000 |
