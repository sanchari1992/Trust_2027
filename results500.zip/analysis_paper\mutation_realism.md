# Do mutated questions look more like real queries?

AUC of a classifier separating the question set from real user queries (0.5 = indistinguishable, lower is more realistic).

| rag | method | baseline | m2 | m3 |
|---|---|---|---|---|
| medrag | ares | 0.914 | 0.828 | 0.945 |
| medrag | datamorgana | 0.883 | 0.918 | 0.944 |
| medrag | ragas | 0.979 | 0.926 | 0.990 |

## Mean over RAGs and methods

| condition | mean_auc | mean_n_sig_features | mean_words |
|---|---|---|---|
| Benchmark (unchanged) | 0.925 | 26.333 | 17.983 |
| Benchmark + M2 only | 0.891 | 30.000 | 21.814 |
| Benchmark + M3 only | 0.960 | 31.667 | 33.873 |
