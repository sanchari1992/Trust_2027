# Which questions change status between the benchmark and a mutated version?

Each question is in exactly one cell: `fine_to_fine`, `fine_to_FAIL` (newly failing: the mutation exposed it), `FAIL_to_fine` (fixed by the mutation), `FAIL_to_FAIL` (fails whatever you do). Outcomes: `not_correct` = wrong or declined; `hallucinated` = the main metric; `wrong_behavior` = asserted something wrong / adopted a false claim. `p_mcnemar` compares `fine_to_FAIL` with `FAIL_to_fine` (exact test), `q_value` is Benjamini-Hochberg corrected within each outcome. The two Control rows show how many questions change status with NO mutation: a mutation must change more than that.

## All RAGs and methods pooled

| outcome | condition | questions | fine_to_fine | fine_to_FAIL | FAIL_to_fine | FAIL_to_FAIL | benchmark_fails | condition_fails | net_change | p_mcnemar | q_value |
|---|---|---|---|---|---|---|---|---|---|---|---|
| not_correct | Benchmark + M2 only | 1500 | 1153 | 127 | 68 | 152 | 220 | 279 | 59 | 0.000 | 0.000 |
| not_correct | Benchmark + M3 only | 1500 | 1064 | 216 | 143 | 77 | 220 | 293 | 73 | 0.000 | 0.000 |
| hallucinated | Benchmark + M2 only | 1500 | 1239 | 87 | 95 | 79 | 174 | 166 | -8 | 0.604 | 0.604 |
| hallucinated | Benchmark + M3 only | 1500 | 1115 | 211 | 125 | 49 | 174 | 260 | 86 | 0.000 | 0.000 |
| wrong_behavior | Benchmark + M2 only | 1500 | 1330 | 49 | 66 | 55 | 121 | 104 | -17 | 0.135 | 0.135 |
| wrong_behavior | Benchmark + M3 only | 1500 | 1220 | 159 | 95 | 26 | 121 | 185 | 64 | 0.000 | 0.000 |

## The three mutations together

`at_least_one` = M1, M2 or M3; `all_three` = M1 and M2 and M3. `fails_somewhere` = fails in the benchmark or in any mutated version (the union).

|  |
|

## Per RAG and method

| rag | method | outcome | condition | questions | fine_to_fine | fine_to_FAIL | FAIL_to_fine | FAIL_to_FAIL | benchmark_fails | condition_fails | net_change | p_mcnemar | q_value |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | ares | not_correct | Benchmark + M2 only | 500 | 372 | 30 | 53 | 45 | 98 | 75 | -23 | 0.015 | 0.023 |
| medrag | ares | not_correct | Benchmark + M3 only | 500 | 339 | 63 | 73 | 25 | 98 | 88 | -10 | 0.440 | 0.440 |
| medrag | datamorgana | not_correct | Benchmark + M2 only | 500 | 349 | 61 | 12 | 78 | 90 | 139 | 49 | 0.000 | 0.000 |
| medrag | datamorgana | not_correct | Benchmark + M3 only | 500 | 330 | 80 | 54 | 36 | 90 | 116 | 26 | 0.030 | 0.036 |
| medrag | ragas | not_correct | Benchmark + M2 only | 500 | 432 | 36 | 3 | 29 | 32 | 65 | 33 | 0.000 | 0.000 |
| medrag | ragas | not_correct | Benchmark + M3 only | 500 | 395 | 73 | 16 | 16 | 32 | 89 | 57 | 0.000 | 0.000 |
| medrag | ares | hallucinated | Benchmark + M2 only | 500 | 398 | 30 | 48 | 24 | 72 | 54 | -18 | 0.054 | 0.107 |
| medrag | ares | hallucinated | Benchmark + M3 only | 500 | 372 | 56 | 60 | 12 | 72 | 68 | -4 | 0.781 | 0.801 |
| medrag | datamorgana | hallucinated | Benchmark + M2 only | 500 | 402 | 33 | 30 | 35 | 65 | 68 | 3 | 0.801 | 0.801 |
| medrag | datamorgana | hallucinated | Benchmark + M3 only | 500 | 367 | 68 | 44 | 21 | 65 | 89 | 24 | 0.029 | 0.088 |
| medrag | ragas | hallucinated | Benchmark + M2 only | 500 | 439 | 24 | 17 | 20 | 37 | 44 | 7 | 0.349 | 0.523 |
| medrag | ragas | hallucinated | Benchmark + M3 only | 500 | 376 | 87 | 21 | 16 | 37 | 103 | 66 | 0.000 | 0.000 |
| medrag | ares | wrong_behavior | Benchmark + M2 only | 500 | 420 | 15 | 49 | 16 | 65 | 31 | -34 | 0.000 | 0.000 |
| medrag | ares | wrong_behavior | Benchmark + M3 only | 500 | 396 | 39 | 60 | 5 | 65 | 44 | -21 | 0.044 | 0.053 |
| medrag | datamorgana | wrong_behavior | Benchmark + M2 only | 500 | 450 | 15 | 10 | 25 | 35 | 40 | 5 | 0.424 | 0.424 |
| medrag | datamorgana | wrong_behavior | Benchmark + M3 only | 500 | 409 | 56 | 24 | 11 | 35 | 67 | 32 | 0.000 | 0.001 |
| medrag | ragas | wrong_behavior | Benchmark + M2 only | 500 | 460 | 19 | 7 | 14 | 21 | 33 | 12 | 0.029 | 0.043 |
| medrag | ragas | wrong_behavior | Benchmark + M3 only | 500 | 415 | 64 | 11 | 10 | 21 | 74 | 53 | 0.000 | 0.000 |

|  |
|

Question-level file: `transitions_questions.csv` (columns `<outcome>__<condition>`, 1 = failing).
