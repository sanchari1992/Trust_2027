# Where generated prompts deviate from real prompts, and what each mutation does about it

Real prompts: 300 (medical_heldout.jsonl). Generated: 1500 benchmark prompts (ragas, ares, datamorgana). d = standardised difference (generated minus real, in pooled standard deviations; |d| about 0.2 small, 0.5 medium, 0.8 large). Positive d: generated prompts have more of it than real ones.

## A. Deviations of the benchmark from real prompts (largest first)

| rank | feature | description | family | built_for | real_mean | benchmark_mean | d | d_ci_low | d_ci_high | abs_d | single_feature_auc |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | fk_grade | Flesch-Kincaid grade | complexity | M2 + M3 | 7.282 | 12.930 | 1.125 | 0.986 | 1.272 | 1.125 | 0.795 |
| 2 | gunning_fog | Gunning Fog index | complexity | M2 + M3 | 10.727 | 16.620 | 0.963 | 0.838 | 1.122 | 0.963 | 0.760 |
| 3 | flesch_ease | Flesch reading ease | complexity | M2 + M3 | 61.430 | 33.301 | -0.906 | -1.033 | -0.769 | 0.906 | 0.753 |
| 4 | syll_per_word | syllables per word | complexity | M2 + M3 | 1.594 | 1.843 | 0.675 | 0.542 | 0.805 | 0.675 | 0.698 |
| 5 | long_word_ratio | share of long words (7+ letters) | complexity | M2 + M3 | 0.246 | 0.332 | 0.566 | 0.450 | 0.707 | 0.566 | 0.663 |
| 6 | has_first_person | first person (I, my, me) | user voice | M3 Premise | 0.307 | 0.093 | -0.553 | -0.683 | -0.426 | 0.553 | 0.607 |
| 7 | mean_dep_distance | mean dependency distance | complexity | M2 + M3 | 1.944 | 2.298 | 0.548 | 0.413 | 0.695 | 0.548 | 0.674 |
| 8 | max_depth | depth of the content-word graph | complexity | M2 + M3 | 2.583 | 3.439 | 0.459 | 0.267 | 0.672 | 0.459 | 0.676 |
| 9 | starts_with_verb | starts with a verb (imperative) | register | M2 Colloquial | 0.150 | 0.024 | -0.458 | -0.570 | -0.343 | 0.458 | 0.563 |
| 10 | starts_lowercase | starts with a lowercase letter | register | M2 Colloquial | 0.333 | 0.150 | -0.438 | -0.568 | -0.317 | 0.438 | 0.592 |
| 11 | tree_depth | dependency-tree depth | complexity | M2 + M3 | 4.347 | 5.393 | 0.422 | 0.262 | 0.593 | 0.422 | 0.648 |
| 12 | has_politeness_marker | politeness marker (please, thanks, could you) | register | M2 Colloquial | 0.093 | 0.021 | -0.317 | -0.435 | -0.209 | 0.317 | 0.536 |
| 13 | ends_with_question_mark | ends with a question mark | register | M2 Colloquial | 0.460 | 0.610 | 0.304 | 0.186 | 0.436 | 0.304 | 0.575 |
| 14 | has_wh_word | contains a wh-word | register | M2 Colloquial | 0.607 | 0.727 | 0.256 | 0.131 | 0.380 | 0.256 | 0.560 |
| 15 | n_clauses | subordinate/relative clauses | complexity | M2 + M3 | 1.220 | 0.919 | -0.170 | -0.267 | -0.045 | 0.170 | 0.502 |
| 16 | n_entities | named entities per prompt | user voice | M3 Premise | 0.763 | 0.569 | -0.117 | -0.214 | 0.027 | 0.117 | 0.506 |
| 17 | has_typo_like_repeat | typo-like repeated letters | register | M2 Colloquial | 0.020 | 0.011 | -0.070 | -0.185 | 0.082 | 0.070 | 0.504 |

## B. Does each mutation close the gap? (closure = 1 - |d after| / |d before|; negative = moved away)

| feature | family | real_mean | benchmark_mean | abs_d_benchmark | m2_mean | m2_abs_d | m2_closure | m3_mean | m3_abs_d | m3_closure |
|---|---|---|---|---|---|---|---|---|---|---|
| fk_grade | complexity | 7.282 | 12.930 | 1.125 | 10.537 | 0.682 | 0.393 | 11.581 | 1.009 | 0.103 |
| gunning_fog | complexity | 10.727 | 16.620 | 0.963 | 14.057 | 0.576 | 0.401 | 15.268 | 0.873 | 0.093 |
| flesch_ease | complexity | 61.430 | 33.301 | 0.906 | 45.937 | 0.553 | 0.390 | 42.504 | 0.719 | 0.207 |
| syll_per_word | complexity | 1.594 | 1.843 | 0.675 | 1.724 | 0.404 | 0.402 | 1.737 | 0.466 | 0.309 |
| long_word_ratio | complexity | 0.246 | 0.332 | 0.566 | 0.303 | 0.423 | 0.252 | 0.294 | 0.367 | 0.352 |
| has_first_person | user voice | 0.307 | 0.093 | 0.553 | 0.491 | 0.384 | 0.306 | 0.712 | 0.886 | -0.603 |
| mean_dep_distance | complexity | 1.944 | 2.298 | 0.548 | 2.265 | 0.507 | 0.075 | 2.476 | 0.957 | -0.745 |
| max_depth | complexity | 2.583 | 3.439 | 0.459 | 3.693 | 0.596 | -0.299 | 4.021 | 0.794 | -0.731 |
| starts_with_verb | register | 0.150 | 0.024 | 0.458 | 0.154 | 0.011 | 0.976 | 0.076 | 0.235 | 0.487 |
| starts_lowercase | register | 0.333 | 0.150 | 0.438 | 0.338 | 0.010 | 0.977 | 0.055 | 0.749 | -0.711 |
| tree_depth | complexity | 4.347 | 5.393 | 0.422 | 5.659 | 0.539 | -0.276 | 6.340 | 0.862 | -1.041 |
| has_politeness_marker | register | 0.093 | 0.021 | 0.317 | 0.223 | 0.362 | -0.141 | 0.034 | 0.245 | 0.228 |
| ends_with_question_mark | register | 0.460 | 0.610 | 0.304 | 0.184 | 0.618 | -1.032 | 0.764 | 0.656 | -1.158 |
| has_wh_word | register | 0.607 | 0.727 | 0.256 | 0.725 | 0.252 | 0.018 | 0.759 | 0.332 | -0.296 |
| n_clauses | complexity | 1.220 | 0.919 | 0.170 | 1.426 | 0.115 | 0.323 | 2.099 | 0.463 | -1.727 |
| n_entities | user voice | 0.763 | 0.569 | 0.117 | 0.584 | 0.107 | 0.081 | 1.457 | 0.371 | -2.178 |
| has_typo_like_repeat | register | 0.020 | 0.011 | 0.070 | 0.083 | 0.289 | -3.142 | 0.019 | 0.005 | 0.931 |

## C. By family

| family | built_for | benchmark_mean_abs_d | m2_mean_abs_d | m2_closure | m3_mean_abs_d | m3_closure |
|---|---|---|---|---|---|---|
| register | M2 Colloquial | 0.307 | 0.257 | 0.164 | 0.370 | -0.206 |
| user voice | M3 Premise | 0.335 | 0.246 | 0.267 | 0.629 | -0.878 |
| complexity | M2 + M3 | 0.648 | 0.488 | 0.247 | 0.723 | -0.116 |

## D. Is the deviation shared by all generators? (d per generator)

| feature | family | ragas_d | ares_d | datamorgana_d |
|---|---|---|---|---|
| fk_grade | complexity | 1.416 | 1.145 | 0.903 |
| gunning_fog | complexity | 1.193 | 1.035 | 0.732 |
| flesch_ease | complexity | -1.006 | -0.988 | -0.775 |
| syll_per_word | complexity | 0.660 | 0.777 | 0.618 |
| long_word_ratio | complexity | 0.520 | 0.630 | 0.558 |
| has_first_person | user voice | -0.918 | -0.859 | -0.104 |
| mean_dep_distance | complexity | 0.941 | 0.412 | 0.313 |
| max_depth | complexity | 0.557 | 0.444 | 0.381 |
| starts_with_verb | register | -0.581 | -0.400 | -0.409 |
| starts_lowercase | register | -0.998 | -0.890 | 0.196 |
| tree_depth | complexity | 0.723 | 0.470 | 0.115 |
| has_politeness_marker | register | -0.453 | -0.453 | -0.117 |
| ends_with_question_mark | register | 1.484 | -0.329 | 0.152 |
| has_wh_word | register | 1.137 | -0.334 | 0.282 |
| n_clauses | complexity | -0.243 | -0.203 | -0.075 |
| n_entities | user voice | -0.161 | 0.042 | -0.279 |
| has_typo_like_repeat | register | -0.102 | -0.046 | -0.064 |

## E. Overall: mean |d| over all realism features, how many are closer than the unchanged benchmark, and classifier AUC on all non-length features (0.5 = cannot tell apart)

| condition | n | mean_words_info_only | mean_abs_d | features_closer_than_benchmark | auc_vs_real | auc_ci_low | auc_ci_high |
|---|---|---|---|---|---|---|---|
| Benchmark (unchanged) | 1500 | 17.983 | 0.491 | - | 0.884 | 0.864 | 0.934 |
| Benchmark + M2 only | 1500 | 21.814 | 0.378 | 12/17 | 0.884 | 0.836 | 0.930 |
| Benchmark + M3 only | 1500 | 33.873 | 0.588 | 8/17 | 0.975 | 0.943 | 0.987 |
