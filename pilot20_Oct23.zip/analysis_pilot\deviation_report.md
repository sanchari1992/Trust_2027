# Where generated prompts deviate from real prompts, and what each mutation does about it

Real prompts: 1,165 (medical.jsonl). Generated: 60 benchmark prompts (ragas, ares, datamorgana). d = standardised difference (generated minus real, in pooled standard deviations; |d| about 0.2 small, 0.5 medium, 0.8 large). Positive d: generated prompts have more of it than real ones.

## A. Deviations of the benchmark from real prompts (largest first)

| rank | feature | description | family | built_for | real_mean | benchmark_mean | d | d_ci_low | d_ci_high | abs_d | single_feature_auc |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | fk_grade | Flesch-Kincaid grade | complexity | M2 + M3 | 7.386 | 12.442 | 1.083 | 0.831 | 1.350 | 1.083 | 0.794 |
| 2 | gunning_fog | Gunning Fog index | complexity | M2 + M3 | 10.832 | 15.794 | 0.899 | 0.651 | 1.175 | 0.899 | 0.742 |
| 3 | flesch_ease | Flesch reading ease | complexity | M2 + M3 | 60.916 | 40.321 | -0.766 | -1.019 | -0.557 | 0.766 | 0.725 |
| 4 | mean_dep_distance | mean dependency distance | complexity | M2 + M3 | 1.978 | 2.503 | 0.763 | 0.550 | 0.988 | 0.763 | 0.738 |
| 5 | starts_with_verb | starts with a verb (imperative) | register | M2 Colloquial | 0.150 | 0.000 | -0.594 | -0.641 | -0.549 | 0.594 | 0.575 |
| 6 | max_depth | depth of the content-word graph | complexity | M2 + M3 | 2.556 | 3.383 | 0.503 | 0.298 | 0.738 | 0.503 | 0.691 |
| 7 | starts_lowercase | starts with a lowercase letter | register | M2 Colloquial | 0.315 | 0.117 | -0.495 | -0.760 | -0.249 | 0.495 | 0.599 |
| 8 | syll_per_word | syllables per word | complexity | M2 + M3 | 1.598 | 1.736 | 0.445 | 0.246 | 0.632 | 0.445 | 0.648 |
| 9 | tree_depth | dependency-tree depth | complexity | M2 + M3 | 4.300 | 5.133 | 0.398 | 0.193 | 0.641 | 0.398 | 0.650 |
| 10 | has_first_person | first person (I, my, me) | user voice | M3 Premise | 0.287 | 0.133 | -0.382 | -0.700 | -0.135 | 0.382 | 0.577 |
| 11 | has_wh_word | contains a wh-word | register | M2 Colloquial | 0.600 | 0.750 | 0.323 | 0.087 | 0.602 | 0.323 | 0.575 |
| 12 | long_word_ratio | share of long words (7+ letters) | complexity | M2 + M3 | 0.247 | 0.290 | 0.304 | 0.103 | 0.496 | 0.304 | 0.592 |
| 13 | ends_with_question_mark | ends with a question mark | register | M2 Colloquial | 0.455 | 0.600 | 0.292 | 0.030 | 0.544 | 0.292 | 0.573 |
| 14 | has_politeness_marker | politeness marker (please, thanks, could you) | register | M2 Colloquial | 0.101 | 0.033 | -0.273 | -0.499 | -0.054 | 0.273 | 0.534 |
| 15 | n_entities | named entities per prompt | user voice | M3 Premise | 0.959 | 0.500 | -0.224 | -0.364 | -0.092 | 0.224 | 0.538 |
| 16 | has_typo_like_repeat | typo-like repeated letters | register | M2 Colloquial | 0.019 | 0.000 | -0.196 | -0.236 | -0.156 | 0.196 | 0.509 |
| 17 | n_clauses | subordinate/relative clauses | complexity | M2 + M3 | 1.104 | 1.150 | 0.028 | -0.142 | 0.219 | 0.028 | 0.585 |

## B. Does each mutation close the gap? (closure = 1 - |d after| / |d before|; negative = moved away)

| feature | family | real_mean | benchmark_mean | abs_d_benchmark | m2_mean | m2_abs_d | m2_closure | m3_mean | m3_abs_d | m3_closure |
|---|---|---|---|---|---|---|---|---|---|---|
| fk_grade | complexity | 7.386 | 12.442 | 1.083 | 10.185 | 0.617 | 0.430 | 11.300 | 0.935 | 0.136 |
| gunning_fog | complexity | 10.832 | 15.794 | 0.899 | 13.471 | 0.503 | 0.440 | 15.041 | 0.843 | 0.062 |
| flesch_ease | complexity | 60.916 | 40.321 | 0.766 | 51.401 | 0.369 | 0.518 | 46.500 | 0.572 | 0.252 |
| mean_dep_distance | complexity | 1.978 | 2.503 | 0.763 | 2.449 | 0.705 | 0.076 | 2.656 | 1.159 | -0.519 |
| starts_with_verb | register | 0.150 | 0.000 | 0.594 | 0.150 | 0.001 | 0.999 | 0.050 | 0.338 | 0.432 |
| max_depth | complexity | 2.556 | 3.383 | 0.503 | 3.533 | 0.595 | -0.184 | 3.950 | 0.855 | -0.699 |
| starts_lowercase | register | 0.315 | 0.117 | 0.495 | 0.383 | 0.143 | 0.711 | 0.050 | 0.729 | -0.472 |
| syll_per_word | complexity | 1.598 | 1.736 | 0.445 | 1.640 | 0.143 | 0.680 | 1.677 | 0.274 | 0.385 |
| tree_depth | complexity | 4.300 | 5.133 | 0.398 | 5.367 | 0.517 | -0.299 | 6.033 | 0.868 | -1.182 |
| has_first_person | user voice | 0.287 | 0.133 | 0.382 | 0.517 | 0.480 | -0.257 | 0.700 | 0.904 | -1.365 |
| has_wh_word | register | 0.600 | 0.750 | 0.323 | 0.750 | 0.323 | 0.000 | 0.783 | 0.404 | -0.249 |
| long_word_ratio | complexity | 0.247 | 0.290 | 0.304 | 0.265 | 0.138 | 0.546 | 0.274 | 0.213 | 0.300 |
| ends_with_question_mark | register | 0.455 | 0.600 | 0.292 | 0.217 | 0.519 | -0.777 | 0.683 | 0.472 | -0.614 |
| has_politeness_marker | register | 0.101 | 0.033 | 0.273 | 0.250 | 0.396 | -0.451 | 0.033 | 0.273 | 0.000 |
| n_entities | user voice | 0.959 | 0.500 | 0.224 | 0.550 | 0.199 | 0.109 | 1.350 | 0.177 | 0.211 |
| has_typo_like_repeat | register | 0.019 | 0.000 | 0.196 | 0.083 | 0.294 | -0.498 | 0.017 | 0.017 | 0.915 |
| n_clauses | complexity | 1.104 | 1.150 | 0.028 | 1.567 | 0.269 | -8.694 | 2.500 | 0.742 | -25.749 |

## C. By family

| family | built_for | benchmark_mean_abs_d | m2_mean_abs_d | m2_closure | m3_mean_abs_d | m3_closure |
|---|---|---|---|---|---|---|
| register | M2 Colloquial | 0.362 | 0.279 | 0.229 | 0.372 | -0.027 |
| user voice | M3 Premise | 0.303 | 0.340 | -0.122 | 0.540 | -0.783 |
| complexity | M2 + M3 | 0.577 | 0.429 | 0.257 | 0.718 | -0.245 |

## D. Is the deviation shared by all generators? (d per generator)

| feature | family | ragas_d | ares_d | datamorgana_d |
|---|---|---|---|---|
| fk_grade | complexity | 1.323 | 1.116 | 0.865 |
| gunning_fog | complexity | 1.175 | 0.980 | 0.619 |
| flesch_ease | complexity | -0.871 | -0.777 | -0.660 |
| mean_dep_distance | complexity | 1.159 | 0.637 | 0.496 |
| starts_with_verb | register | -0.594 | -0.594 | -0.594 |
| max_depth | complexity | 0.339 | 0.741 | 0.422 |
| starts_lowercase | register | -0.959 | -0.959 | 0.073 |
| syll_per_word | complexity | 0.475 | 0.458 | 0.404 |
| tree_depth | complexity | 0.384 | 0.690 | 0.155 |
| has_first_person | user voice | -0.896 | -0.896 | 0.237 |
| has_wh_word | register | 1.154 | -0.199 | 0.321 |
| long_word_ratio | complexity | 0.281 | 0.482 | 0.169 |
| ends_with_question_mark | register | 1.547 | -0.697 | 0.395 |
| has_politeness_marker | register | -0.475 | -0.475 | -0.004 |
| n_entities | user voice | -0.384 | 0.043 | -0.356 |
| has_typo_like_repeat | register | -0.196 | -0.196 | -0.196 |
| n_clauses | complexity | -0.067 | -0.126 | 0.249 |

## E. Overall: mean |d| over all realism features, how many are closer than the unchanged benchmark, and classifier AUC on all non-length features (0.5 = cannot tell apart)

| condition | n | mean_words_info_only | mean_abs_d | features_closer_than_benchmark | auc_vs_real | auc_ci_low | auc_ci_high |
|---|---|---|---|---|---|---|---|
| Benchmark (unchanged) | 60 | 19.350 | 0.469 | - | 0.925 | 0.834 | 0.969 |
| Benchmark + M2 only | 60 | 23.033 | 0.365 | 9/17 | 0.902 | 0.796 | 0.941 |
| Benchmark + M3 only | 60 | 35.983 | 0.575 | 8/17 | 0.961 | 0.931 | 0.993 |
