# Benchmark vs Benchmark+ : one table per metric

Columns: the three benchmark-generation methods side by side under each condition. **M1** = length, **M2** = linguistic (typos, person, register, request form), **M3** = user-provided information (correct or incorrect), **M1,2,3** = all three. Every column covers the same questions as its benchmark column (only questions answered and judged in every condition are used).

## Hallucination rate

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 15.0% | 10.0% | 20.0% | 20.0% | 10.0% | 20.0% | 5.0% | 10.0% | 10.0% |
| All RAGs | 15.0% | 10.0% | 20.0% | 20.0% | 10.0% | 20.0% | 5.0% | 10.0% | 10.0% |

### Change in hallucination rate versus the same method's benchmark

| RAG | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|
| MedRAG | +5.0 pp | +0.0 pp | +0.0 pp | -10.0 pp | +0.0 pp | -10.0 pp |
| All RAGs | +5.0 pp | +0.0 pp | +0.0 pp | -10.0 pp | +0.0 pp | -10.0 pp |

## Wrong-behaviour rate (asserted wrong / adopted a false claim)

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 15.0% | 10.0% | 5.0% | 20.0% | 5.0% | 15.0% | 5.0% | 10.0% | 5.0% |
| All RAGs | 15.0% | 10.0% | 5.0% | 20.0% | 5.0% | 15.0% | 5.0% | 10.0% | 5.0% |

## Unfaithful and wrong

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 0.0% | 0.0% | 0.0% | 5.0% | 5.0% | 5.0% | 0.0% | 0.0% | 0.0% |
| All RAGs | 0.0% | 0.0% | 0.0% | 5.0% | 5.0% | 5.0% | 0.0% | 0.0% | 0.0% |

## Retrieval miss rate (original source passage not retrieved)

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 50.0% | 0.0% | 90.0% | 55.0% | 0.0% | 90.0% | 55.0% | 10.0% | 80.0% |
| All RAGs | 50.0% | 0.0% | 90.0% | 55.0% | 0.0% | 90.0% | 55.0% | 10.0% | 80.0% |

## Accuracy

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 85.0% | 90.0% | 90.0% | 80.0% | 95.0% | 75.0% | 95.0% | 70.0% | 90.0% |
| All RAGs | 85.0% | 90.0% | 90.0% | 80.0% | 95.0% | 75.0% | 95.0% | 70.0% | 90.0% |

## Accuracy on questions whose correct behaviour is to answer

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 85.0% | 90.0% | 90.0% | 80.0% | 95.0% | 75.0% | 90.0% | 66.7% | 92.3% |
| All RAGs | 85.0% | 90.0% | 90.0% | 80.0% | 95.0% | 75.0% | 90.0% | 66.7% | 92.3% |

## Questions per cell

| RAG | Benchmark (RAGAS) | Benchmark (ARES) | Benchmark (DataMorgana) | Benchmark (RAGAS) + M2 | Benchmark (ARES) + M2 | Benchmark (DataMorgana) + M2 | Benchmark (RAGAS) + M3 | Benchmark (ARES) + M3 | Benchmark (DataMorgana) + M3 |
|---|---|---|---|---|---|---|---|---|---|
| MedRAG | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 |
| All RAGs | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 | 20 |
