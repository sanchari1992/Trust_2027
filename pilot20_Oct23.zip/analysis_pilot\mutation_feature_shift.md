# Feature means: real queries vs each condition

Mutations should move the generated questions toward the real-query values (first row of each table). Conditions are pooled over RAGs and methods (weighted by number of questions).

## general

| condition | n | starts_with_verb | starts_lowercase | has_first_person | has_politeness_marker | has_typo_like_repeat | ends_with_question_mark | has_wh_word | n_entities | tree_depth | mean_dep_distance | n_clauses | fk_grade | flesch_ease | gunning_fog | word_len |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| REAL QUERIES | 4000 | 0.366 | 0.273 | 0.306 | 0.112 | 0.122 | 0.174 | 0.530 | 3.014 | 5.888 | 2.577 | 2.839 | 8.934 | 58.683 | 11.976 | 42.297 |

## medical

| condition | n | starts_with_verb | starts_lowercase | has_first_person | has_politeness_marker | has_typo_like_repeat | ends_with_question_mark | has_wh_word | n_entities | tree_depth | mean_dep_distance | n_clauses | fk_grade | flesch_ease | gunning_fog | word_len |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| REAL QUERIES | 1165 | 0.150 | 0.315 | 0.287 | 0.101 | 0.019 | 0.455 | 0.600 | 0.959 | 4.300 | 1.978 | 1.104 | 7.386 | 60.916 | 10.832 | 18.585 |
| Benchmark (unchanged) | 60 | 0.000 | 0.117 | 0.133 | 0.033 | 0.000 | 0.600 | 0.750 | 0.500 | 5.133 | 2.503 | 1.150 | 12.442 | 40.321 | 15.794 | 19.350 |
| Benchmark + M2 only | 60 | 0.150 | 0.383 | 0.517 | 0.250 | 0.083 | 0.217 | 0.750 | 0.550 | 5.367 | 2.449 | 1.567 | 10.185 | 51.401 | 13.471 | 23.033 |
| Benchmark + M3 only | 60 | 0.050 | 0.050 | 0.700 | 0.033 | 0.017 | 0.683 | 0.783 | 1.350 | 6.033 | 2.656 | 2.500 | 11.300 | 46.500 | 15.041 | 35.983 |
