# Benchmark before vs after mutation

Every number compares the SAME questions: the original benchmark question and its mutated version. `*` marks a change whose 95% paired-bootstrap interval excludes 0 (intervals are in `before_after_deltas.csv`). `pp` = percentage points.

**Accuracy** = share of answers judged correct. For mutations 3 and 1+2+3 the correct behaviour can be to reject a false claim or flag an unsupported detail, so `accuracy (answer items)` restricts to questions whose correct behaviour is to answer; that column is comparable with the baseline. **Hallucination** = unfaithful answer or an answer that asserts a wrong / adopted-false claim (declining to answer is not counted).

## 1. Accuracy and hallucination, all RAGs and methods pooled

| condition | n | accuracy | Δ accuracy | accuracy (answer items) | hallucination | Δ hallucination | unfaithful | abstained | refused | mean faithfulness |
|---|---|---|---|---|---|---|---|---|---|---|
| Benchmark (unchanged) | 60 | 88.3% |  | 88.3% | 15.0% |  | 5.0% | 1.7% | 1.7% | 0.974 |
| Benchmark + M2 only | 60 | 83.3% | -5.0 pp | 83.3% | 16.7% | +1.7 pp | 8.3% | 3.3% | 3.3% | 0.979 |
| Benchmark + M3 only | 60 | 85.0% | -3.3 pp | 84.4% | 8.3% | -6.7 pp | 1.7% | 8.3% | 11.7% | 0.996 |

## 2a. Accuracy per RAG and method

| rag | method | Benchmark (unchanged) | Benchmark + M2 only | Benchmark + M3 only |
|---|---|---|---|---|
| medrag | ares | 90.0% | 95.0% | 70.0% |
| medrag | datamorgana | 90.0% | 75.0% | 90.0% |
| medrag | ragas | 85.0% | 80.0% | 95.0% |

## 2b. Hallucination per RAG and method

| rag | method | Benchmark (unchanged) | Benchmark + M2 only | Benchmark + M3 only |
|---|---|---|---|---|
| medrag | ares | 10.0% | 10.0% | 10.0% |
| medrag | datamorgana | 20.0% | 20.0% | 10.0% |
| medrag | ragas | 15.0% | 20.0% | 5.0% |

## 3. Structural metrics (all 25, averaged over the questions)

Means of each feature over the evaluated questions, for the benchmark and each mutated version. `Real` = the real user queries of that domain (if `data/real_queries/` exists). 'general' = LightRAG and RAPTOR; 'medical' = MedRAG. Feature definitions: `src/analysis/graph_features.py` and `lexical_features.py`.

### medical: mean of each feature (60 distinct questions)

| feature | Real | Benchmark (unchanged) | Benchmark + M2 only | Benchmark + M3 only |
|---|---|---|---|---|
| n_tokens | 22.325 | 21.583 | 26.067 | 41.283 |
| n_sentences | 1.630 | 1.000 | 1.550 | 2.000 |
| n_nodes | 9.855 | 10.350 | 11.683 | 19.133 |
| n_edges | 7.808 | 8.833 | 9.667 | 15.900 |
| graph_density | 0.181 | 0.111 | 0.093 | 0.048 |
| avg_degree | 1.363 | 1.662 | 1.623 | 1.638 |
| max_depth | 2.556 | 3.383 | 3.533 | 3.950 |
| n_components | 2.047 | 1.517 | 2.017 | 3.233 |
| largest_component_frac | 0.831 | 0.871 | 0.813 | 0.533 |
| n_entities | 0.959 | 0.500 | 0.550 | 1.350 |
| n_entity_types | 0.610 | 0.383 | 0.450 | 0.933 |
| has_wh_word | 0.600 | 0.750 | 0.750 | 0.783 |
| starts_with_verb | 0.150 | 0.000 | 0.150 | 0.050 |
| char_len | 112 | 119 | 140 | 219 |
| word_len | 18.585 | 19.350 | 23.033 | 35.983 |
| lexical_diversity | 0.940 | 0.908 | 0.915 | 0.800 |
| avg_word_len | 4.786 | 5.118 | 4.947 | 4.946 |
| n_question_marks | 0.536 | 0.600 | 0.583 | 1.000 |
| n_sentences_punct | 1.630 | 1.000 | 1.433 | 1.967 |
| starts_lowercase | 0.315 | 0.117 | 0.383 | 0.050 |
| has_typo_like_repeat | 0.019 | 0.000 | 0.083 | 0.017 |
| has_hedge | 0.009 | 0.000 | 0.067 | 0.050 |
| has_first_person | 0.287 | 0.133 | 0.517 | 0.700 |
| has_politeness_marker | 0.101 | 0.033 | 0.250 | 0.033 |
| ends_with_question_mark | 0.455 | 0.600 | 0.217 | 0.683 |
| tree_depth | 4.300 | 5.133 | 5.367 | 6.033 |
| mean_dep_distance | 1.978 | 2.503 | 2.449 | 2.656 |
| n_clauses | 1.104 | 1.150 | 1.567 | 2.500 |
| fk_grade | 7.386 | 12.442 | 10.185 | 11.300 |
| flesch_ease | 60.916 | 40.321 | 51.401 | 46.500 |
| gunning_fog | 10.832 | 15.794 | 13.471 | 15.041 |
| syll_per_word | 1.598 | 1.736 | 1.640 | 1.677 |
| long_word_ratio | 0.247 | 0.290 | 0.265 | 0.274 |

### medical: change from the benchmark (mutated minus original)

| feature | Benchmark + M2 only vs Benchmark | Benchmark + M3 only vs Benchmark |
|---|---|---|
| n_tokens | +4.48* | +19.70* |
| n_sentences | +0.55* | +1.00* |
| n_nodes | +1.33* | +8.78* |
| n_edges | +0.83* | +7.07* |
| graph_density | -0.02* | -0.06* |
| avg_degree | -0.04 | -0.02 |
| max_depth | +0.15 | +0.57* |
| n_components | +0.50* | +1.72* |
| largest_component_frac | -0.06* | -0.34* |
| n_entities | +0.05 | +0.85* |
| n_entity_types | +0.07* | +0.55* |
| has_wh_word | +0.00 | +0.03 |
| starts_with_verb | +0.15* | +0.05 |
| char_len | +20.65* | +99.87* |
| word_len | +3.68* | +16.63* |
| lexical_diversity | +0.01 | -0.11* |
| avg_word_len | -0.17* | -0.17* |
| n_question_marks | -0.02 | +0.40* |
| n_sentences_punct | +0.43* | +0.97* |
| starts_lowercase | +0.27* | -0.07* |
| has_typo_like_repeat | +0.08* | +0.02 |
| has_hedge | +0.07* | +0.05 |
| has_first_person | +0.38* | +0.57* |
| has_politeness_marker | +0.22* | +0.00 |
| ends_with_question_mark | -0.38* | +0.08* |
| tree_depth | +0.23* | +0.90* |
| mean_dep_distance | -0.05 | +0.15* |
| n_clauses | +0.42* | +1.35* |
| fk_grade | -2.26* | -1.14* |
| flesch_ease | +11.08* | +6.18* |
| gunning_fog | -2.32* | -0.75 |
| syll_per_word | -0.10* | -0.06* |
| long_word_ratio | -0.02* | -0.02 |
