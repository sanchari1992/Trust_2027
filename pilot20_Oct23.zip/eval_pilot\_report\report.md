# Benchmark vs Benchmark+ : hallucination results

Profile: `pilot`. Faithfulness threshold: 1.0. All mutated results are compared with the original benchmark question by question (paired).

## All RAGs and methods pooled

| condition | n | hallucination_rate | hall_ci_low | hall_ci_high | failure_rate | unfaithful_rate | unsupported_but_correct_rate | unfaithful_and_wrong_rate | retrieval_hit_rate | abstain_rate | mean_faithfulness |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Benchmark (unchanged) | 60 | 0.150 | 0.081 | 0.261 | 0.117 | 0.050 | 0.050 | 0.000 | 0.533 | 0.017 | 0.974 |
| Benchmark + M2 only | 60 | 0.167 | 0.093 | 0.280 | 0.167 | 0.083 | 0.033 | 0.050 | 0.517 | 0.033 | 0.979 |
| Benchmark + M3 only | 60 | 0.083 | 0.036 | 0.181 | 0.150 | 0.017 | 0.017 | 0.000 | 0.517 | 0.083 | 0.996 |

## Paired change in hallucination rate vs the original benchmark (pooled)

`diff` is condition minus baseline with a 95% paired-bootstrap interval; `newly_failing` = questions the RAG handled in the benchmark but hallucinated on in the mutated version; `newly_passing` = the reverse; `q_value` = McNemar exact test, Benjamini-Hochberg corrected.

| condition | n_pairs | baseline_rate | condition_rate | diff | diff_ci_low | diff_ci_high | newly_failing | newly_passing | q_value |
|---|---|---|---|---|---|---|---|---|---|
| Benchmark + M2 only | 60 | 0.150 | 0.167 | 0.017 | -0.100 | 0.117 | 6 | 5 | 1.000 |
| Benchmark + M3 only | 60 | 0.150 | 0.083 | -0.067 | -0.167 | 0.033 | 3 | 7 | 1.000 |

## Hallucinations found: benchmark alone vs benchmark + mutations

A question counts as a hallucination found by the mutations if it was fine in the original benchmark but a mutated version made the RAG hallucinate.

| level | rag | n_questions | found_by_benchmark | found_by_benchmark_plus_mutations | extra_found_by_mutations | extra_found_by_controls | extra_found_by_mutations_beyond_controls | benchmark_rate | union_rate | fold_increase |
|---|---|---|---|---|---|---|---|---|---|---|
| rag | medrag | 60 | 9 | 17 | 8 |  |  | 0.150 | 0.283 | 1.889 |
| overall | ALL | 60 | 9 | 17 | 8 |  |  | 0.150 | 0.283 | 1.889 |

`extra_found_by_controls`: the same count for the control conditions (no useful change: a re-run, and filler padding). `extra_found_by_mutations_beyond_controls`: questions that only a mutation exposed, that neither control did. Only this last column is evidence that the mutations themselves help.

## The same change measured two other ways (pooled)

`wrong_behavior`: only answers that assert something wrong or adopt a false / unsupported claim (no faithfulness involved). `hallucinated_strict`: unfaithfulness against the retrieved context ALONE, i.e. a statement repeating what the user said is not accepted as supported. If a mutation shows a change in `hallucinated` but not in these, check it with scripts/audit_hallucinations.py.

| metric | condition | n_pairs | baseline_rate | condition_rate | diff | diff_ci_low | diff_ci_high | newly_failing | newly_passing | q_value |
|---|---|---|---|---|---|---|---|---|---|---|
| wrong_behavior | Benchmark + M2 only | 60 | 0.100 | 0.133 | 0.033 | -0.067 | 0.133 | 5 | 3 | 1.000 |
| wrong_behavior | Benchmark + M3 only | 60 | 0.100 | 0.067 | -0.033 | -0.117 | 0.050 | 3 | 5 | 1.000 |
| hallucinated_strict | Benchmark + M2 only | 60 | 0.200 | 0.217 | 0.017 | -0.100 | 0.133 | 7 | 6 | 1.000 |
| hallucinated_strict | Benchmark + M3 only | 60 | 0.200 | 0.100 | -0.100 | -0.217 | 0.000 | 4 | 10 | 0.599 |
| unsupported_but_correct | Benchmark + M2 only | 60 | 0.050 | 0.033 | -0.017 | -0.100 | 0.050 | 2 | 3 | 1.000 |
| unsupported_but_correct | Benchmark + M3 only | 60 | 0.050 | 0.017 | -0.033 | -0.083 | 0.000 | 0 | 2 | 1.000 |
| unfaithful_and_wrong | Benchmark + M2 only | 60 | 0.000 | 0.050 | 0.050 | 0.000 | 0.117 | 3 | 0 | 1.000 |
| unfaithful_and_wrong | Benchmark + M3 only | 60 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0 | 0 | 1.000 |

## Retrieval: do mutated prompts retrieve the original source passage?

`retrieval_hit_rate`: share of answers whose retrieved passages include an original source passage of the question. `hallucination_rate_when_miss` vs `_when_hit`: whether hallucination goes with a retrieval miss. If a condition retrieves worse, its extra hallucinations are a retrieval effect (the query got diluted), not the model being fooled.

| condition | n | retrieval_hit_rate | mean_gold_recall | hallucination_rate_when_hit | hallucination_rate_when_miss | n_miss |
|---|---|---|---|---|---|---|
| Benchmark (unchanged) | 60 | 0.533 | 0.533 | 0.094 | 0.214 | 28 |
| Benchmark + M2 only | 60 | 0.517 | 0.517 | 0.097 | 0.241 | 29 |
| Benchmark + M3 only | 60 | 0.517 | 0.517 | 0.065 | 0.103 | 29 |

## Hallucination rate per RAG and method

| rag | method | baseline | m2 | m3 |
|---|---|---|---|---|
| medrag | ares | 0.100 | 0.100 | 0.100 |
| medrag | datamorgana | 0.200 | 0.200 | 0.100 |
| medrag | ragas | 0.150 | 0.200 | 0.050 |

## By operator (hallucination rate; a question with two operators counts for both)

| condition | operator | n | hallucination_rate | baseline_rate_same_questions | failure_rate | mean_faithfulness |
|---|---|---|---|---|---|---|
| m2 | m2:casual | 29 | 0.103 | 0.069 | 0.138 | 1.000 |
| m2 | m2:first_person | 19 | 0.053 | 0.263 | 0.105 | 1.000 |
| m2 | m2:imperative | 10 | 0.300 | 0.200 | 0.300 | 0.992 |
| m2 | m2:politeness | 16 | 0.188 | 0.250 | 0.188 | 0.932 |
| m2 | m2:synonyms | 10 | 0.200 | 0.000 | 0.100 | 0.922 |
| m2 | m2:typos | 36 | 0.222 | 0.139 | 0.194 | 0.983 |
| m3 | m3:correct_candidate | 16 | 0.000 | 0.188 | 0.000 | 1.000 |
| m3 | m3:false_premise | 6 | 0.000 | 0.000 | 0.000 | 1.000 |
| m3 | m3:patient_conflict | 5 | 0.000 | 0.200 | 0.000 | 1.000 |
| m3 | m3:patient_consistent | 9 | 0.222 | 0.222 | 0.556 | 0.972 |
| m3 | m3:true_premise | 7 | 0.000 | 0.286 | 0.000 | 1.000 |
| m3 | m3:unsupported_assumption | 10 | 0.300 | 0.100 | 0.300 | 1.000 |
| m3 | m3:wrong_candidate | 7 | 0.000 | 0.000 | 0.143 | 1.000 |

## Mutation 3 (user information) by kind and operator

| condition | kind | m3_operator | n | hallucination_rate | failure_rate | unfaithful_rate | refusal_rate |
|---|---|---|---|---|---|---|---|
| m3 | correct | m3:correct_candidate | 16 | 0.000 | 0.000 | 0.000 | 0.000 |
| m3 | correct | m3:patient_consistent | 9 | 0.222 | 0.556 | 0.111 | 0.444 |
| m3 | correct | m3:true_premise | 7 | 0.000 | 0.000 | 0.000 | 0.000 |
| m3 | incorrect | m3:false_premise | 6 | 0.000 | 0.000 | 0.000 | 0.000 |
| m3 | incorrect | m3:patient_conflict | 5 | 0.000 | 0.000 | 0.000 | 0.200 |
| m3 | incorrect | m3:unsupported_assumption | 10 | 0.300 | 0.300 | 0.000 | 0.100 |
| m3 | incorrect | m3:wrong_candidate | 7 | 0.000 | 0.143 | 0.000 | 0.143 |
