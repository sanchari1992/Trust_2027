# Do mutated questions look more like real queries?

AUC of a classifier separating the question set from real user queries (0.5 = indistinguishable, lower is more realistic).

| rag | method | baseline | m2 | m3 |
|---|---|---|---|---|
| medrag | ares | 0.905 | 0.792 | 0.983 |
| medrag | datamorgana | 0.762 | 0.731 | 0.969 |
| medrag | ragas | 0.988 | 0.970 | 0.995 |

## Mean over RAGs and methods

| condition | mean_auc | mean_n_sig_features | mean_words |
|---|---|---|---|
| Benchmark (unchanged) | 0.885 | 17.000 | 19.350 |
| Benchmark + M2 only | 0.831 | 16.000 | 23.033 |
| Benchmark + M3 only | 0.982 | 23.667 | 35.983 |
