# Judge agreement: llm:gpt-6-luna (under test)  vs  llm:deepseek-flash (reference)

55 answers judged twice (refusals excluded: both judges skip them). Disagreements: `label_disagreements.csv`.

| behaviour | n | label agreement | Cohen's kappa |
|---|---|---|---|
| abstain | 3 | 1.000 | 1.000 |
| answer | 48 | 0.979 | 0.897 |
| reject_premise | 4 | 1.000 | 1.000 |
| ALL | 55 | 0.982 | 0.953 |

Faithfulness (needs stored contexts):

| measure | n | agreement | kappa | rate (reference) | rate (judge under test) |
|---|---|---|---|---|---|
| unfaithful | 55 | 0.964 | 0.650 | 0.036 | 0.073 |
| hallucinated | 55 | 0.945 | 0.770 | 0.109 | 0.164 |
| correct | 55 | 0.982 | 0.899 | 0.909 | 0.891 |

Confusion (rows: reference judge, columns: judge under test):

- answer: correct->correct: 42, correct->incorrect: 1, incorrect->incorrect: 5
- abstain: answered_core->answered_core: 3
- reject_premise: consistent->consistent: 1, corrected->corrected: 3
