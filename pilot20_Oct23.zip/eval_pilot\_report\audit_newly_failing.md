# Audit: why are mutated questions counted as hallucinations?

Questions that were fine in the original benchmark but hallucinated in a mutated condition, by cause (definitions in the header of `src/evalrun/audit.py`). `judge_artifact` rows are NOT counted as hallucinations in the main tables; they are shown so you can see what the strict score would have added.

| condition_label | behaviour_failure | unfaithful_and_wrong | unsupported_but_correct | judge_artifact | other | also_in_control |
|---|---|---|---|---|---|---|
| Benchmark + M2 only | 4 | 0 | 2 | 1 | 0 | 0 |
| Benchmark + M3 only | 3 | 0 | 0 | 1 | 0 | 0 |

## behaviour_failure (7)

**Benchmark + M2 only** | medrag/ares | ares-medrag-0004 | label `incorrect` | faithfulness 0.3333333333333333 (strict 0.3333333333333333) | retrieval_hit 1.0 | operators m2:synonyms,m2:politeness

- original: The bonds that hold the molecules in their proper places on the template and join them together must be strong enough to resist the disordering effect of thermal motion.
- mutated: The bonds that hold the molecules in their proper places on the template and join them together must be potent enough to resist the disordering effect of thermal motion. Thank you!
- response: Covalent bonds.

**Benchmark + M3 only** | medrag/ares | ares-medrag-0005 | label `accepted_detail` | faithfulness 1.0 (strict 1.0) | retrieval_hit 1.0 | operators m3:unsupported_assumption

- original: The protein, or globin, portion of myoglobin creates a special microenvironment for the heme that permits the reversible binding of one oxygen molecule (oxygenation).
- mutated: Oh, and one more thing: in sperm whale myoglobin, the distal histidine sits at position E7. The protein, or globin, portion of myoglobin creates a special microenvironment for the heme that permits the reversible binding of one oxygen molecule (oxygenation).
- response: Yes. According to the documents, the distal histidine (E7) does not directly interact with the heme group but helps stabilize the binding of O2 to Fe2+, and the globin portion of myoglobin creates a special microenvironment for the heme that permits the reversible binding of one oxygen molecule (oxygenation).

**Benchmark + M3 only** | medrag/ares | ares-medrag-0010 | label `accepted_detail` | faithfulness 1.0 (strict 1.0) | retrieval_hit 1.0 | operators m3:unsupported_assumption

- original: One rotation of the c ring produces three ATP.
- mutated: Just so you know, in mammalian mitochondria the c ring of ATP synthase usually has eight subunits. One rotation of the c ring produces three ATP.
- response: One complete rotation of the c ring (8 subunits) produces three ATP, so approximately 8/3 ≈ 2.7 protons are required per ATP synthesized in mammalian mitochondria.

**Benchmark + M2 only** | medrag/datamorgana | datamorgana-medrag-0005 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 0.0 | operators m2:casual,m2:typos

- original: I do public health messaging; why are thymine dimers bad?
- mutated: hi, I do public health messaging; why are thymmine dimers bad?
- response: Thymine dimers are bad because, if left uncorrected when DNA is replicated, they would be expected to lead either to the deletion of one or more base pairs or to a base-pair substitution in the daughter DNA chain; the mutations would then be propagated throughout subsequent cell generations, and such a high rate of random changes in the DNA sequence would have disastrous consequences (Document [8]).

**Benchmark + M2 only** | medrag/datamorgana | datamorgana-medrag-0013 | label `incorrect` | faithfulness 1.0 (strict 1.0) | retrieval_hit 0.0 | operators m2:casual,m2:typos

- original: How does the body naturally put the brakes on the clotting process so that clots don't keep growing beyond what's needed?
- mutated: how does the body naturally put the brakes on the clotting process so that clots don't keep growing beyond what's neded???
- response: The body limits clotting to the area of damage through anticoagulation and fibrinolysis: proteins synthesized by the liver and blood vessels inactivate clotting factors (by binding and removing them or degrading them), and other proteins degrade the fibrin meshwork, removing the clot once vessel repair is underway. Intact endothelium also helps prevent unnecessary platelet activation by separating platelets from collagen, producing prostacyclin (PGI2) and nitric oxide, and converting ADP to AMP via cell-surface ADPase.

**Benchmark + M3 only** | medrag/datamorgana | datamorgana-medrag-0002 | label `accepted_detail` | faithfulness 1.0 (strict 1.0) | retrieval_hit 0.0 | operators m3:unsupported_assumption

- original: as a clinician researching secretory pathway what is the delicate balance between forward and backward retrieval transport pathways when proteins move from ER through Golgi apparatus to cell surface with sorting steps selecting membrane and soluble lumenal proteins
- mutated: Keep in mind that the delicate balance is maintained by COPI and COPII coat proteins in mammalian cells. as a clinician researching secretory pathway what is the delicate balance between forward and backward retrieval transport pathways when proteins move from ER through Golgi apparatus to cell surface with sorting steps selecting membrane and soluble lumenal proteins
- response: The delicate balance is between forward (outward) transport and backward (retrieval) transport. Forward-moving vesicles select cargo molecules and carry them to the next compartment along the pathway (ER → Golgi → cell surface), while retrieval vesicles carry escaped proteins back to a previous compartment where they normally function. Transfer from one compartment to the next involves this delicate balance between forward and backward (retrieval) transport pathways, and the pathway from the ER to the cell surface consists of many sorting steps that continuously select membrane and soluble lum

**Benchmark + M2 only** | medrag/ragas | ragas-medrag-0006 | label `incorrect` | faithfulness 0.9166666666666666 (strict 0.9166666666666666) | retrieval_hit 0.0 | operators m2:imperative,m2:typos

- original: What must be defined about any tumor in relation to the facial nerve, and why is this important?
- mutated: Explain what must be defined about any tmuor in relation to the facial nerve, and why is this important.
- response: The documents state that the facial nerve [VII] follows a complex course—emerging at the pons-medulla junction, entering the internal acoustic meatus, passing to the geniculate ganglion, traveling within the temporal bone, exiting through the stylomastoid foramen, and entering the parotid gland before dividing into terminal branches. Because a series of lesions may affect the nerve along this course, it is possible "with good clinical expertise, to determine the exact site of the lesion in relation to the course of the nerve" (Document [0]). This is important because the clinical deficits depe

## unsupported_but_correct (2)

**Benchmark + M2 only** | medrag/ares | ares-medrag-0017 | label `correct` | faithfulness 0.8888888888888888 (strict 0.8888888888888888) | retrieval_hit 1.0 | operators m2:synonyms,m2:typos

- original: How can this small number of signaling pathways generate the huge diversity of cells and patterns?
- mutated: How can this little number of signaling pathwaays generate the huge diversity of cells and patterns?
- response: Three mechanisms are responsible: (1) through gene duplication, pathway components are often encoded by small families of closely related homologous genes, allowing diversity according to which family member is employed (e.g., Notch1 vs. Notch4); (2) a cell's response to a signal depends on other signals it receives concurrently, so different combinations of signals generate a large variety of responses; and (3) most fundamentally, the effect of activating a pathway depends on the previous experiences of the responding cell, which leave a lasting mark registered in the state of the cell's chro

**Benchmark + M2 only** | medrag/datamorgana | datamorgana-medrag-0002 | label `correct` | faithfulness 0.8333333333333334 (strict 0.8333333333333334) | retrieval_hit 0.0 | operators m2:typos,m2:politeness

- original: as a clinician researching secretory pathway what is the delicate balance between forward and backward retrieval transport pathways when proteins move from ER through Golgi apparatus to cell surface with sorting steps selecting membrane and soluble lumenal proteins
- mutated: Would you mind helping with a question? as a clinician researching secretory pathway what is the delicate balance between forward and backward retrieval tranpsort pathways when proteins move from ER through Golgi apparatsu to cell surface with sorting steps selecting membrane and soluble lumenal proteisn
- response: The balance is between forward transport vesicles that select cargo molecules and move them to the next compartment, and backward (retrieval) transport pathways that return escaped proteins to a previous compartment where they normally function. The pathway from the ER to the cell surface consists of many such sorting steps, continuously selecting membrane and soluble lumenal proteins for packaging and transport, while retrieval pathways (e.g., COPI-coated vesicles carrying back ER resident proteins, cargo receptors, and SNAREs) match the outward flow.

## judge_artifact (2)

**Benchmark + M2 only** | medrag/ragas | ragas-medrag-0013 | label `correct` | faithfulness 1.0 (strict 0.75) | retrieval_hit nan | operators m2:first_person,m2:politeness

- original: How are dietary purine bases processed after being taken into enterocytes, and what happens to the resulting uric acid?
- mutated: Can you help out with something? I was wondering about something. How are dietary purine bases processed after being taken into enterocytes, and what happens to the resulting uric acid?
- response: Dietary purine bases are not used to any appreciable extent for synthesis of tissue nucleic acids; instead, they are degraded to uric acid in the enterocytes. Most of the uric acid then enters the blood and is eventually excreted in the urine.

**Benchmark + M3 only** | medrag/ragas | ragas-medrag-0005 | label `correct` | faithfulness 1.0 (strict 0.8333333333333334) | retrieval_hit nan | operators m3:correct_candidate

- original: What are the two categories into which cancer-critical mutations fall, and how do oncogenes and tumor suppressor genes differ in the manner in which their mutations act?
- mutated: What are the two categories into which cancer-critical mutations fall, and how do oncogenes and tumor suppressor genes differ in the manner in which their mutations act? So dominant oncogenes versus recessive tumor suppressor genes, is that right?
- response: Yes. Cancer-critical mutations fall into two categories: dominant (activating) mutations and recessive (inactivating) mutations. Oncogenes act dominantly—a gain-of-function mutation in a single copy can drive a cell toward cancer. Tumor suppressor gene mutations generally act recessively—often both copies must be lost or inactivated before an effect is seen (though some tumor suppressors can have effects with only one copy damaged).
