# Benchmark+ : evaluation report

Generated 2026-10-21 16:14 | profile `pilot` | LLM `deepseek-flash` | embeddings `BAAI/bge-small-en-v1.5` | seed 42

Definitions: README sections 13 (mutations), 14.2 (metrics), 29-32 (databases, union, this report). `AUC` = how well a classifier tells the set from real queries (0.5 = cannot; lower = more realistic). `*_js` = Jensen-Shannon divergence in bits of the distribution of graph shapes / fine templates / entity types against the real queries (0 = identical, 1 = disjoint). `entropy` = spread of shapes (1 = even). The **union** is the three methods' questions with near-duplicates removed; its mutated versions and evaluation results are those of the method each question came from.

## medrag (medical)

### 1. Real user queries

1,165 real medical queries. Mean 18.6 words, 1.63 sentences, 4.62 entities per query; 335 distinct graph shapes (entropy 0.86). Commonest shapes: `what|S1|N1-3|D0-1|E0` 5.9%, `what|S1|N4-6|D2|E0` 5.3%, `how|S1|N1-3|D0-1|E0` 3.9%, `AUX|S1|N1-3|D0-1|E0` 2.7%, `what|S1|N1-3|D0-1|E1` 2.6%.

### 2. Benchmarks: how realistic and how varied

| scope | n | mean_words | n_sentences | auc_vs_real | shape_js | template_js | entity_type_js | distinct_templates | template_entropy | distinct_shapes | shape_entropy | ents_per_query | real_shape_coverage | shape_in_real |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ragas | 20 | 20.350 | 1.000 | 0.988 | 0.857 | 1.000 | 0.064 | 20 | 1.000 | 14 | 0.951 | 4.850 | 0.063 | 0.800 |
| ares | 20 | 19.600 | 1.000 | 0.905 | 0.904 | 1.000 | 0.045 | 20 | 1.000 | 18 | 0.988 | 5.200 | 0.037 | 0.600 |
| datamorgana | 20 | 18.100 | 1.000 | 0.762 | 0.819 | 1.000 | 0.065 | 20 | 1.000 | 16 | 0.971 | 3.900 | 0.112 | 0.800 |
| union | 60 | 19.350 | 1.000 | 0.925 | 0.762 | 1.000 | 0.039 | 60 | 1.000 | 39 | 0.967 | 4.650 | 0.165 | 0.733 |

Entity overlap: distinct real entities 3,607; distinct benchmark entities 259; benchmark entities also in real 0.185; real entities found in corpus 0.060; benchmark entities found in corpus 0.703.

Union: 60 questions from {'ragas': 20, 'ares': 20, 'datamorgana': 20} -> 60 after removing 0 near-duplicates (cosine >= 0.9); kept by method {'ragas': 20, 'ares': 20, 'datamorgana': 20}.

### 3. Mutations (applied to the union)

Checks passed (kept) and rejected. `by_fallback` = how many of the kept ones come from a fallback instead of the full operator (`mutation.fill_all`, README 13.12; they are included in `kept`):

| rag | method | mutation | kept | rejected | kept_rate | by_fallback | commonest_rejection |
|---|---|---|---|---|---|---|---|
| medrag | ragas | m1 | 0 | 0 |  | 0 |  |
| medrag | ragas | m2 | 20 | 0 | 1.000 | 0 |  |
| medrag | ragas | m3 | 20 | 0 | 1.000 | 0 |  |
| medrag | ares | m1 | 0 | 0 |  | 0 |  |
| medrag | ares | m2 | 20 | 0 | 1.000 | 0 |  |
| medrag | ares | m3 | 20 | 0 | 1.000 | 0 |  |
| medrag | datamorgana | m1 | 0 | 0 |  | 0 |  |
| medrag | datamorgana | m2 | 20 | 0 | 1.000 | 0 |  |
| medrag | datamorgana | m3 | 20 | 0 | 1.000 | 0 |  |

Realism of the mutated versions alone and pooled with the originals (Benchmark+):

| set | n | mean_words | n_sentences | auc_vs_real | shape_js | template_js | entity_type_js | template_entropy | shape_entropy | starts_lowercase | has_first_person | starts_with_verb |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Benchmark | 60 | 19.350 | 1.000 | 0.925 | 0.762 | 1.000 | 0.039 | 1.000 | 0.967 | 0.117 | 0.133 | 0.000 |
| M2 Colloquial (versions alone) | 60 | 23.033 | 1.550 | 0.902 | 0.818 | 1.000 | 0.040 | 1.000 | 0.980 | 0.383 | 0.517 | 0.150 |
| M3 Premise (versions alone) | 60 | 35.983 | 2.000 | 0.961 | 0.899 | 1.000 | 0.017 | 1.000 | 0.956 | 0.050 | 0.700 | 0.050 |
| Benchmark + M2 | 120 | 21.192 | 1.275 | 0.821 | 0.739 | 1.000 | 0.038 | 0.996 | 0.958 | 0.250 | 0.325 | 0.075 |
| Benchmark + M3 | 120 | 27.667 | 1.500 | 0.838 | 0.739 | 1.000 | 0.019 | 1.000 | 0.967 | 0.083 | 0.417 | 0.025 |


## 4. Hallucinations and accuracy

Benchmark+ = the questions plus their mutated versions (N, 2N, 4N questions; README 14.7). `hallucination_rate` is the main metric (README 14.2); the interval resamples original questions. Rows for `union` pool the questions of the three methods that are in the union.

| rag | method | benchmark_plus | questions | added_questions | correct | wrong | abstained | refused | accuracy | hallucinated | hallucination_rate | rate_ci_low | rate_ci_high | hallucinated_in_added |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | ares | Benchmark | 20 | 0 | 18 | 2 | 0 | 0 | 0.900 | 2 | 0.100 | 0.000 | 0.250 | 0 |
| medrag | ares | Benchmark + M2 | 40 | 20 | 37 | 3 | 0 | 0 | 0.925 | 4 | 0.100 | 0.025 | 0.175 | 2 |
| medrag | ares | Benchmark + M3 | 40 | 20 | 32 | 4 | 4 | 6 | 0.800 | 4 | 0.100 | 0.025 | 0.200 | 2 |
| medrag | ares | Benchmark + M2 + M3 | 60 | 40 | 51 | 5 | 4 | 6 | 0.850 | 6 | 0.100 | 0.033 | 0.167 | 4 |
| medrag | datamorgana | Benchmark | 20 | 0 | 18 | 1 | 1 | 1 | 0.900 | 4 | 0.200 | 0.050 | 0.400 | 0 |
| medrag | datamorgana | Benchmark + M2 | 40 | 20 | 33 | 4 | 3 | 3 | 0.825 | 8 | 0.200 | 0.075 | 0.350 | 4 |
| medrag | datamorgana | Benchmark + M3 | 40 | 20 | 36 | 2 | 2 | 2 | 0.900 | 6 | 0.150 | 0.050 | 0.275 | 2 |
| medrag | datamorgana | Benchmark + M2 + M3 | 60 | 40 | 51 | 5 | 4 | 4 | 0.850 | 10 | 0.167 | 0.067 | 0.283 | 6 |
| medrag | ragas | Benchmark | 20 | 0 | 17 | 3 | 0 | 0 | 0.850 | 3 | 0.150 | 0.000 | 0.300 | 0 |
| medrag | ragas | Benchmark + M2 | 40 | 20 | 33 | 7 | 0 | 0 | 0.825 | 7 | 0.175 | 0.025 | 0.350 | 4 |
| medrag | ragas | Benchmark + M3 | 40 | 20 | 36 | 4 | 0 | 0 | 0.900 | 4 | 0.100 | 0.000 | 0.225 | 1 |
| medrag | ragas | Benchmark + M2 + M3 | 60 | 40 | 52 | 8 | 0 | 0 | 0.867 | 8 | 0.133 | 0.033 | 0.267 | 5 |
| medrag | union | Benchmark | 60 | 0 | 53 | 6 | 1 | 1 | 0.883 | 9 | 0.150 | 0.067 | 0.250 | 0 |
| medrag | union | Benchmark + M2 | 120 | 60 | 103 | 14 | 3 | 3 | 0.858 | 19 | 0.158 | 0.083 | 0.242 | 10 |
| medrag | union | Benchmark + M3 | 120 | 60 | 104 | 10 | 6 | 8 | 0.867 | 14 | 0.117 | 0.058 | 0.183 | 5 |
| medrag | union | Benchmark + M2 + M3 | 180 | 120 | 154 | 18 | 8 | 10 | 0.856 | 24 | 0.133 | 0.078 | 0.194 | 15 |

### Does each mutation expose more? (paired against the unchanged question)

`diff` = condition rate - benchmark rate on the SAME questions; the two Control rows are the noise floor and the off-topic-filler reference (README 14.1, 16).

(Union only here; all methods are in `hallucination_paired.csv`. `m_union` is the derived condition: a question fails if it fails in the benchmark or in any of M1, M2, M3.)

| rag | metric | condition | n_pairs | baseline_rate | condition_rate | diff | diff_ci_low | diff_ci_high | newly_failing | newly_passing | q_value |
|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | hallucinated | m2 | 60 | 0.150 | 0.167 | 0.017 | -0.083 | 0.117 | 6 | 5 | 1.000 |
| medrag | hallucinated | m3 | 60 | 0.150 | 0.083 | -0.067 | -0.167 | 0.033 | 3 | 7 | 1.000 |
| medrag | failed | m2 | 60 | 0.117 | 0.167 | 0.050 | -0.050 | 0.150 | 6 | 3 | 0.857 |
| medrag | failed | m3 | 60 | 0.117 | 0.150 | 0.033 | -0.083 | 0.167 | 8 | 6 | 1.000 |
| medrag | refused | m2 | 60 | 0.017 | 0.033 | 0.017 | 0.000 | 0.050 | 1 | 0 | 1.000 |
| medrag | refused | m3 | 60 | 0.017 | 0.117 | 0.100 | 0.017 | 0.200 | 7 | 1 | 0.211 |

### Which questions change status? (hallucinated)

| rag | method | outcome | condition | questions | fine_to_fine | fine_to_FAIL | FAIL_to_fine | FAIL_to_FAIL | benchmark_fails | condition_fails | net_change | p_mcnemar | q_value |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| medrag | union | hallucinated | Benchmark + M2 only | 60 | 45 | 6 | 5 | 4 | 9 | 10 | 1 | 1.000 | 1.000 |
| medrag | union | hallucinated | Benchmark + M3 only | 60 | 48 | 3 | 7 | 2 | 9 | 5 | -4 | 0.344 | 1.000 |

### The three mutations together (union, hallucinated)



### Refusals: "Cannot be answered from given information." (README 14.10)

The RAG is told to give exactly this answer when its documents lack the information. `refused` counts such answers per condition. `became_refused` = answered the original question but refuses this version (for M3: the patient information added to the question makes it unanswerable from the documents); `stopped_refusing` = the reverse; `refused_in_both` = the documents never held the answer. `abstained_by_judge` also counts declines in other words (refused <= abstained_by_judge). A refusal is a failure to answer, never a hallucination.

| rag | method | condition | total | refused | refused_rate | abstained_by_judge | became_refused | stopped_refusing | refused_in_both |
|---|---|---|---|---|---|---|---|---|---|
| medrag | union | Benchmark (unchanged) | 60 | 1 | 0.017 | 1 |  |  |  |
| medrag | union | Benchmark + M2 only | 60 | 2 | 0.033 | 2 | 1.000 | 0.000 | 1.000 |
| medrag | union | Benchmark + M3 only | 60 | 7 | 0.117 | 5 | 7.000 | 1.000 | 0.000 |

(All methods: `refusals.csv`.)

## 5. The story table

One row per question set. Realism columns: lower AUC / JS is closer to real queries. Hallucination columns: from the pooled Benchmark+ definition (the `+M` rows contain the originals AND the mutated versions).

### medrag

| row | n | mean_words | n_sentences | ents_per_query | distinct_shapes | shape_entropy | auc_vs_real | shape_js | template_js | entity_type_js | questions | accuracy | hallucination_rate | ci_low | ci_high |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Real queries | 1165 | 18.585 | 1.630 | 4.620 | 335 | 0.862 |  |  |  |  |  |  |  |  |  |
| RAGAS | 20 | 20.350 | 1.000 | 4.850 | 14 | 0.951 | 0.988 | 0.857 | 1.000 | 0.064 | 20 | 0.850 | 0.150 | 0.000 | 0.300 |
| ARES | 20 | 19.600 | 1.000 | 5.200 | 18 | 0.988 | 0.905 | 0.904 | 1.000 | 0.045 | 20 | 0.900 | 0.100 | 0.000 | 0.250 |
| DataMorgana | 20 | 18.100 | 1.000 | 3.900 | 16 | 0.971 | 0.762 | 0.819 | 1.000 | 0.065 | 20 | 0.900 | 0.200 | 0.050 | 0.400 |
| Union | 60 | 19.350 | 1.000 | 4.650 | 39 | 0.967 | 0.925 | 0.762 | 1.000 | 0.039 | 60 | 0.883 | 0.150 | 0.067 | 0.250 |
| Union + M2 | 120 | 21.192 | 1.275 | 4.800 | 70 | 0.958 | 0.821 | 0.739 | 1.000 | 0.038 | 120 | 0.858 | 0.158 | 0.083 | 0.242 |
| Union + M3 | 120 | 27.667 | 1.500 | 6.392 | 79 | 0.967 | 0.838 | 0.739 | 1.000 | 0.019 | 120 | 0.867 | 0.117 | 0.058 | 0.183 |

## 6. Cost and provenance

LLM calls and tokens of the LAST run of each stage (a resumed run only counts its own part):

| rag | stage | method | accepted | attempts | acceptance_rate | llm_calls_last_run | prompt_tokens | completion_tokens | model |
|---|---|---|---|---|---|---|---|---|---|
| medrag | generation | ragas | 20 | 20.000 | 1.000 | 0 | 0 | 0 | deepseek-flash |
| medrag | generation | ares | 20 | 43.000 | 0.465 | 0 | 0 | 0 | deepseek-flash |
| medrag | generation | datamorgana | 20 | 30.000 | 0.667 | 0 | 0 | 0 | deepseek-flash |
| medrag | mutation | ragas | 20 |  |  | 49 | 16533 | 1191 | deepseek-flash |
| medrag | mutation | ares | 20 |  |  | 45 | 12152 | 1095 | deepseek-flash |
| medrag | mutation | datamorgana | 20 |  |  | 51 | 17432 | 1171 | deepseek-flash |

Hand-audit sheet for assumption A4 (README 13.2): `audit_sheet_mutations.csv` (120 mutated questions; fill the last five columns and report the shares).

## Files

All in `C:\Users\tuo94543\Documents\GitHub\Trust_2027\results\paper_pilot`: `audit_sheet_mutations.csv`, `hallucination_any_of_three.csv`, `hallucination_benchmark_plus.csv`, `hallucination_paired.csv`, `hallucination_per_condition.csv`, `hallucination_transitions.csv`, `mutation_validity.csv`, `paper_tables.tex`, `provenance.csv`, `realism_all.csv`, `refusals.csv`, `story_medrag.csv`, `templates_top.csv`
