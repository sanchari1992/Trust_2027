# Examples for the paper

## medrag

### A. Simple benchmark queries (one method each)

- **ragas** `ragas-medrag-0013`: How are dietary purine bases processed after being taken into enterocytes, and what happens to the resulting uric acid?
  - reference answer: Dietary purine bases are taken into enterocytes and degraded to uric acid within those cells (they are not used to any appreciable extent for tissue nucleic acid synthesis). Most of the resulting uric acid then enters the blood and is eventually excreted in t…
- **ragas** `ragas-medrag-0006`: What must be defined about any tumor in relation to the facial nerve, and why is this important?
  - reference answer: The relationship of any tumor to the branches of the facial nerve [VII] must be defined. This is important because resection of the tumor may damage the nerve.
- **ragas** `ragas-medrag-0010`: What is the role of UCP1, also known as thermogenin, in the mitochondria-rich brown adipocytes of mammals?
  - reference answer: Based on the context, UCP1 (thermogenin) is responsible for heat production in the mitochondria-rich brown adipocytes of mammals. It forms a channel in the inner mitochondrial membrane that allows H+ to reenter the mitochondrial matrix without energy being ca…
- **ares** `ares-medrag-0016`: Nerves that carry conscious sensations from peripheral regions back to the CNS, and nerves that innervate voluntary muscles.
  - reference answer: The somatic part of the nervous system consists of nerves that carry conscious sensations from peripheral regions back to the CNS, and nerves that innervate voluntary muscles.
- **ares** `ares-medrag-0013`: They are efficiently taken up from blood by the hepatocytes via an isoform of the cotransporter and reused.
  - reference answer: Bile salts are efficiently taken up from blood by the hepatocytes via an isoform of the cotransporter and reused.
- **ares** `ares-medrag-0018`: Bariatric surgery in morbidly obese individuals with T2D has been shown to result in disease remission in most patients.
  - reference answer: Remission may not be permanent.
- **datamorgana** `datamorgana-medrag-0010`: pulmonary sinuses recoil of blood forces cusps closed prevents refilling right ventricle mechanism
  - reference answer: After ventricular contraction, the recoil of blood fills the pulmonary sinuses and forces the cusps closed, which prevents blood in the pulmonary trunk from refilling the right ventricle.
- **datamorgana** `datamorgana-medrag-0015`: I study birth defects—how does a flat sheet roll into a tube?
  - reference answer: Converting an epithelial sheet into a tube depends on contraction of specific bundles of actin filaments. With the help of myosin motor proteins, these actin bundles shorten, causing the epithelial cells to narrow at their apex, which bends the sheet into a t…
- **datamorgana** `datamorgana-medrag-0003`: which spinal vertebra marks the upper boundary of the bony canal housing the cord
  - reference answer: the first cervical vertebra (CI)

### B. Realistic queries (real users)

- Are low carbs diets goof for weight loss?
- Give brief bullet points of why supermarkets are gateways to pharmaceutical drugs, due to many/most foods in super markets leading to bad health.
- Let's discuss the topic of plastic surgery. What are the risks and benefits?

### C. Named entities and graph templates

**benchmark** `ragas-medrag-0005`: What are the two categories into which cancer-critical mutations fall, and how do oncogenes and tumor suppressor genes differ in the manner in which their mutations act?

- entities: two <CARDINAL>, cancer-critical mutations <CONCEPT>, oncogenes <CONCEPT>, tumor suppressor genes <CONCEPT>, manner <CONCEPT>, mutations <CONCEPT>
- text template: `What are the {CARDINAL} categories into which {CONCEPT} fall, and how do {CONCEPT} and {CONCEPT} differ in the {CONCEPT} in which their {CONCEPT} act?`
- graph template (`d92727b89f`): `WH:what ; NOUN[relcl>VERB[pobj>NOUN[amod>ADJ[npadvmod>NOUN]]]] | VERB[npadvmod>NOUN[nsubj>NOUN],nsubj>NOUN[conj>NOUN[compound>NOUN,compound>NOUN]],pobj>NOUN]`
- shape: `what|S1|N11+|D4+|E1`
- reference answer: Cancer-critical mutations fall into two categories: dominant and recessive. Oncogenes act in a dominant manner—a gain-of-function mutation in a single copy of the gene can drive a cell toward cancer.…
- answer entities: Cancer-critical mutations <CONCEPT>, two <CARDINAL>, Oncogenes act <CONCEPT>, dominant manner <CONCEPT>, function <CONCEPT>, single copy <CONCEPT>, gene <CONCEPT>, cell <CONCEPT>
- answer template (first sentence): `VERB[nsubj>NOUN[amod>ADJ[npadvmod>NOUN]],pobj>NOUN[amod>ADJ[conj>ADJ]]]`; shape `when|S3+|N11+|D4+|E3+`

```
|-- category (NOUN)
|   `-- [relcl] fall (VERB)
|       `-- [pobj] mutation (NOUN)
|           `-- [amod] critical (ADJ)
|               `-- [npadvmod] cancer (NOUN)
`-- differ (VERB)
    |-- [nsubj] oncogene (NOUN)
    |   `-- [conj] gene (NOUN)
    |       |-- [compound] tumor (NOUN)
    |       `-- [compound] suppressor (NOUN)
    |-- [pobj] manner (NOUN)
    `-- [npadvmod] act (NOUN)
        `-- [nsubj] mutation (NOUN)
```

**benchmark** `ares-medrag-0008`: Allopurinol is oxidized to oxypurinol, a long-lived inhibitor of XO.

- entities: Allopurinol <ORG>, oxypurinol <CONCEPT>, long-lived inhibitor <CONCEPT>, XO <ORG>
- text template: `{ORG} is oxidized to {CONCEPT}, a {CONCEPT} of {ORG}.`
- graph template (`57005587d0`): `VERB[nsubjpass>ENT:ORG,pobj>NOUN[appos>NOUN[amod>VERB[advmod>ADV],pobj>ENT:ORG]]]`
- shape: `OTHER|S1|N7-10|D4+|E2`
- reference answer: Allopurinol is oxidized to oxypurinol, a long-lived inhibitor of XO.
- answer entities: Allopurinol <ORG>, oxypurinol <CONCEPT>, long-lived inhibitor <CONCEPT>, XO <ORG>
- answer template (first sentence): `VERB[nsubjpass>ENT:ORG,pobj>NOUN[appos>NOUN[amod>VERB[advmod>ADV],pobj>ENT:ORG]]]`; shape `OTHER|S1|N7-10|D4+|E2`

```
`-- oxidize (VERB)
    |-- [nsubjpass] allopurinol <ORG>
    `-- [pobj] oxypurinol (NOUN)
        `-- [appos] inhibitor (NOUN)
            |-- [amod] live (VERB)
            |   `-- [advmod] long (ADV)
            `-- [pobj] xo <ORG>
```

**benchmark** `ares-medrag-0015`: What are the symptoms of Wernicke-Korsakoff syndrome?

- entities: symptoms <CONCEPT>, Wernicke-Korsakoff <PERSON>
- text template: `What are the {CONCEPT} of {PERSON} syndrome?`
- graph template (`e6b626e986`): `WH:what ; NOUN[pobj>NOUN[compound>ENT:PERSON]]`
- shape: `what|S1|N4-6|D3|E1`
- reference answer: The symptoms include mental confusion, gait ataxia, nystagmus, ophthalmoplegia, memory problems, and hallucinations.
- answer entities: symptoms <CONCEPT>, mental confusion <CONCEPT>, gait ataxia <PERSON>
- answer template (first sentence): `VERB[dobj>NOUN[amod>ADJ],npadvmod>ENT:PERSON[conj>NOUN[compound>NOUN,conj>NOUN],conj>PROPN[conj>PROPN]],nsubj>NOUN]`; shape `OTHER|S1|N11+|D3|E1`

```
`-- symptom (NOUN)
    `-- [pobj] syndrome (NOUN)
        `-- [compound] korsakoff <PERSON>
```

**real** `real-medical-lmsys-e5c35599b8e2443fbf0bd08c6d8e8de8`: Are low carbs diets goof for weight loss?

- entities: goof <CONCEPT>, weight loss <CONCEPT>
- text template: `Are low carbs diets {CONCEPT} for {CONCEPT}?`
- graph template (`233596151a`): `VERB[amod>ADJ[amod>ADJ],dobj>NOUN[pobj>NOUN[compound>NOUN]]]`
- shape: `AUX|S1|N4-6|D3|E0`

```
`-- diet (VERB)
    |-- [amod] carbs (ADJ)
    |   `-- [amod] low (ADJ)
    `-- [dobj] goof (NOUN)
        `-- [pobj] loss (NOUN)
            `-- [compound] weight (NOUN)
```

### D. Mutated queries

### E. Refusals ("Cannot be answered from given information.")

Answers that are exactly the refusal phrase, per method and for the questions of that method that are in the union:

| scope | condition | evaluated | refused | % |
|---|---|---:|---:|---:|
| ragas | baseline | 20 | 0 | 0.0 |
| ragas | m2 | 20 | 0 | 0.0 |
| ragas | m3 | 20 | 0 | 0.0 |
| ares | baseline | 20 | 0 | 0.0 |
| ares | m2 | 20 | 0 | 0.0 |
| ares | m3 | 20 | 6 | 30.0 |
| datamorgana | baseline | 20 | 1 | 5.0 |
| datamorgana | m2 | 20 | 2 | 10.0 |
| datamorgana | m3 | 20 | 1 | 5.0 |
| union | baseline | 60 | 1 | 1.7 |
| union | m2 | 60 | 2 | 3.3 |
| union | m3 | 60 | 7 | 11.7 |

- **ares, Premise (m3) made it refuse** `ares-medrag-0019`
  - original: The α subunit's GTPase domain contains two major subdomains: the "Ras" domain, which is related to other GTPases and provides one face of the nucleotide-binding pocket, and the alpha-helical or "AH" domain, which clamps the nucleotide in place.
    - RAG answered: The α subunit's GTPase domain contains two major subdomains: the "Ras" domain, which is related to other GTPases and provides one face of the nucleotide-binding pocket, and the alpha-helical or "AH" …
  - mutated (m3:patient_consistent; correct claim): I am a 45-year-old man with high blood pressure. The α subunit's GTPase domain contains two major subdomains: the "Ras" domain, which is related to other GTPases and provides one face of the nucleotide-binding pocket, and the alpha-helical or "AH" domain, which clamps the nucleotide in place.
    - RAG: Cannot be answered from given information.
- **ares, Premise (m3) made it refuse** `ares-medrag-0006`
  - original: The Eve stripe 2 unit contains cis-regulatory sequences for four transcription regulators, and genetic experiments show that these four regulatory proteins are responsible for the proper expression of Eve in stripe 2.
    - RAG answered: The Eve stripe 2 unit contains cis-regulatory sequences for four transcription regulators: two activators (Bicoid and Hunchback) and two repressors (Giant and Krüppel). Both activators must bind for …
  - mutated (m3:wrong_candidate; incorrect claim): The Eve stripe 2 unit contains cis-regulatory sequences for four transcription regulators, and genetic experiments show that these four regulatory proteins are responsible for the proper expression of Eve in stripe 2. Am I right that the Eve stripe 2 unit has cis-regulatory sequences for more than 20 transcription regulators?
    - RAG: Cannot be answered from given information.
- **ares, Premise (m3) made it refuse** `ares-medrag-0013`
  - original: They are efficiently taken up from blood by the hepatocytes via an isoform of the cotransporter and reused.
    - RAG answered: Bile salts
  - mutated (m3:patient_consistent; correct claim): A bit about me: I am a 45-year-old man with a history of gallstones. They are efficiently taken up from blood by the hepatocytes via an isoform of the cotransporter and reused.
    - RAG: Cannot be answered from given information.
- **datamorgana, original question refused** `datamorgana-medrag-0001`: How does the body break down a specific type of fat found in cell membranes, and what happens when the enzyme responsible for this process is missing, leading to a disease that affects multiple organs?
  - reference answer: Sphingomyelin is degraded to a ceramide plus phosphorylcholine by the lysosomal enzyme sphingomyelinase; a deficiency of this enzyme causes Niemann-Pick (A and B) disease.; RAG: Cannot be answered from given information.
- **datamorgana, Colloquial (m2) made it refuse** `datamorgana-medrag-0012`
  - original: I'm mapping nerve pathways for a study on chest organ signaling, so can you tell me whether the wandering nerve carries any pain signals at all?
    - RAG answered: The vagus (wandering) nerve does not carry pain signals. According to the documents, visceral afferents in the vagus nerves relay information about normal physiological processes and reflex activitie…
  - mutated (m2:casual, m2:typos): I'm mapping nsrve pathways for a study on chest organ signaling, so can you tell me whether the wandering neerve carries any pain signals at all
    - RAG: Cannot be answered from given information.
- **datamorgana, Premise (m3) made it refuse** `datamorgana-medrag-0015`
  - original: I study birth defects—how does a flat sheet roll into a tube?
    - RAG answered: A flat epithelial sheet rolls into a tube through the oriented contraction of actin-myosin filament bundles running along the adhesion belts (adherens junctions) that link cells together. When these …
  - mutated (m3:patient_consistent; correct claim): I am a 32-year-old pregnant woman carrying a baby with a suspected heart defect. I study birth defects—how does a flat sheet roll into a tube?
    - RAG: Cannot be answered from given information.
